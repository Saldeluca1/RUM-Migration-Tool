import { describe, it, expect } from "vitest";
import { reconstructRumHistory } from "./rum-history.js";

describe("reconstructRumHistory", () => {
  it("returns empty result for no events", () => {
    const r = reconstructRumHistory([], "2026-06-15");
    expect(r.dailyPeaks).toEqual([]);
    expect(r.monthlyPeaks).toEqual([]);
    expect(r.annualAverage).toBe(0);
    expect(r.fullMonths).toBe(0);
    expect(r.derivedAnnualGrowthPct).toBeNull();
    expect(r.historyStart).toBeNull();
  });

  it("sums counts across workspaces as a step function", () => {
    const r = reconstructRumHistory([
      { workspaceId: "a", createdAt: "2026-01-10T00:00:00Z", count: 100 },
      { workspaceId: "b", createdAt: "2026-01-20T00:00:00Z", count: 50 },
    ], "2026-01-31");
    // After Jan 20 total = 150; that is January's high-water mark
    const jan = r.monthlyPeaks.find((m) => m.month === "2026-01");
    expect(jan?.rum).toBe(150);
  });

  it("carries a workspace count forward into later months with no events", () => {
    const r = reconstructRumHistory([
      { workspaceId: "a", createdAt: "2026-01-10T00:00:00Z", count: 200 },
    ], "2026-03-31");
    expect(r.monthlyPeaks.find((m) => m.month === "2026-02")?.rum).toBe(200);
    expect(r.monthlyPeaks.find((m) => m.month === "2026-03")?.rum).toBe(200);
  });

  it("captures the intra-month peak even when a later apply shrinks the count", () => {
    const r = reconstructRumHistory([
      { workspaceId: "a", createdAt: "2026-05-05T00:00:00Z", count: 500 },
      { workspaceId: "a", createdAt: "2026-05-25T00:00:00Z", count: 300 },
    ], "2026-05-31");
    expect(r.monthlyPeaks.find((m) => m.month === "2026-05")?.rum).toBe(500);
  });

  it("flags first and current month partial, middle months full", () => {
    const r = reconstructRumHistory([
      { workspaceId: "a", createdAt: "2026-01-10T00:00:00Z", count: 100 },
    ], "2026-03-15");
    expect(r.monthlyPeaks.find((m) => m.month === "2026-01")?.coverage).toBe("partial");
    expect(r.monthlyPeaks.find((m) => m.month === "2026-02")?.coverage).toBe("full");
    expect(r.monthlyPeaks.find((m) => m.month === "2026-03")?.coverage).toBe("partial");
  });

  it("averages only full months for annualAverage", () => {
    const r = reconstructRumHistory([
      { workspaceId: "a", createdAt: "2026-01-10T00:00:00Z", count: 100 }, // Jan partial
      { workspaceId: "a", createdAt: "2026-02-10T00:00:00Z", count: 200 }, // Feb full=200
      { workspaceId: "a", createdAt: "2026-03-10T00:00:00Z", count: 400 }, // Mar full=400
    ], "2026-04-15"); // Apr partial (=400 carried)
    // full months: Feb=200, Mar=400 → avg 300
    expect(r.annualAverage).toBe(300);
    expect(r.fullMonths).toBe(2);
  });

  it("derives CAGR from first to last full month", () => {
    const r = reconstructRumHistory([
      { workspaceId: "a", createdAt: "2026-01-01T00:00:00Z", count: 100 },
      { workspaceId: "a", createdAt: "2026-02-10T00:00:00Z", count: 100 }, // Feb full=100
      { workspaceId: "a", createdAt: "2026-08-10T00:00:00Z", count: 200 }, // Aug full=200
    ], "2026-09-15");
    // Feb(100) → Aug(200): 6 months, ratio 2 → annualized ((2)^(12/6)-1)*100 = 300
    expect(Math.round(r.derivedAnnualGrowthPct!)).toBe(300);
  });

  it("trailing12Average averages only the last 12 full months when more exist", () => {
    // 14 full months total (Feb..Mar next year), plus partial first/last.
    // Early months (Feb-Mar year1) are low; recent 12 months are high.
    const events = [
      { workspaceId: "a", createdAt: "2025-01-10T00:00:00Z", count: 10 }, // Jan 2025 partial
    ];
    // Feb 2025, Mar 2025 = low full months (10 each, no change)
    // Apr 2025 - Mar 2026 = 12 full months, ramp up via one event per month
    let count = 10;
    let month = 4; // April
    let year = 2025;
    for (let i = 0; i < 12; i += 1) {
      count += 100; // recent months much higher than early months
      events.push({
        workspaceId: "a",
        createdAt: `${year}-${String(month).padStart(2, "0")}-10T00:00:00Z`,
        count,
      });
      month += 1;
      if (month > 12) {
        month = 1;
        year += 1;
      }
    }
    // today falls in the month after the last event's month, making that month partial
    const r = reconstructRumHistory(events, "2026-04-15");
    const full = r.monthlyPeaks.filter((m) => m.coverage === "full");
    expect(full.length).toBeGreaterThan(12);
    const last12 = full.slice(-12);
    const expected = Math.round(last12.reduce((s, m) => s + m.rum, 0) / 12);
    expect(r.trailing12Average).toBe(expected);
    expect(r.trailing12Average).not.toBe(r.annualAverage);
  });

  it("trailing12Average equals annualAverage when 12 or fewer full months exist", () => {
    const r = reconstructRumHistory([
      { workspaceId: "a", createdAt: "2026-01-10T00:00:00Z", count: 100 }, // Jan partial
      { workspaceId: "a", createdAt: "2026-02-10T00:00:00Z", count: 200 }, // Feb full=200
      { workspaceId: "a", createdAt: "2026-03-10T00:00:00Z", count: 400 }, // Mar full=400
    ], "2026-04-15"); // Apr partial
    expect(r.trailing12Average).toBe(r.annualAverage);
    expect(r.trailing12Average).toBe(300);
  });

  it("trailing12Average is 0 when there are no full months", () => {
    const r = reconstructRumHistory([], "2026-06-15");
    expect(r.trailing12Average).toBe(0);
  });

  it("emits one daily peak per calendar day in range", () => {
    const r = reconstructRumHistory([
      { workspaceId: "a", createdAt: "2026-06-01T00:00:00Z", count: 10 },
    ], "2026-06-05");
    expect(r.dailyPeaks.map((d) => d.date)).toEqual([
      "2026-06-01", "2026-06-02", "2026-06-03", "2026-06-04", "2026-06-05",
    ]);
    expect(r.dailyPeaks.every((d) => d.rum === 10)).toBe(true);
    expect(r.historyStart).toBe("2026-06-01");
    expect(r.historyEnd).toBe("2026-06-05");
  });

  describe("dailyWorkspaces", () => {
    it("returns an empty array for no events", () => {
      const r = reconstructRumHistory([], "2026-06-15");
      expect(r.dailyWorkspaces).toEqual([]);
    });

    it("counts a workspace starting on its first-event day and carries it forward", () => {
      const r = reconstructRumHistory([
        { workspaceId: "a", createdAt: "2026-06-01T00:00:00Z", count: 10 },
      ], "2026-06-03");
      expect(r.dailyWorkspaces).toEqual([
        { date: "2026-06-01", count: 1 },
        { date: "2026-06-02", count: 1 },
        { date: "2026-06-03", count: 1 },
      ]);
    });

    it("increments when a second workspace's first event appears, and never decrements (no delete visibility)", () => {
      const r = reconstructRumHistory([
        { workspaceId: "a", createdAt: "2026-06-01T00:00:00Z", count: 10 },
        { workspaceId: "b", createdAt: "2026-06-03T00:00:00Z", count: 5 },
      ], "2026-06-04");
      expect(r.dailyWorkspaces).toEqual([
        { date: "2026-06-01", count: 1 },
        { date: "2026-06-02", count: 1 },
        { date: "2026-06-03", count: 2 },
        { date: "2026-06-04", count: 2 },
      ]);
    });
  });

  describe("dailyByProvider", () => {
    it("returns an empty array for no events", () => {
      const r = reconstructRumHistory([], "2026-06-15");
      expect(r.dailyByProvider).toEqual([]);
    });

    it("carries provider sums forward and stacks to the daily total when every event has byProvider", () => {
      const r = reconstructRumHistory([
        { workspaceId: "a", createdAt: "2026-06-01T00:00:00Z", count: 10, byProvider: { aws: 7, google: 3 } },
        { workspaceId: "b", createdAt: "2026-06-03T00:00:00Z", count: 5, byProvider: { aws: 5 } },
      ], "2026-06-04");

      const day1 = r.dailyByProvider.find((d) => d.date === "2026-06-01")!;
      expect(day1.aws).toBe(7);
      expect(day1.google).toBe(3);

      const day3 = r.dailyByProvider.find((d) => d.date === "2026-06-03")!;
      expect(day3.aws).toBe(12);
      expect(day3.google).toBe(3);

      // Providers stack to the same total the RUM step function reports for that day.
      for (const day of r.dailyByProvider) {
        const peak = r.dailyPeaks.find((p) => p.date === day.date)!;
        const providerSum = Object.entries(day)
          .filter(([key]) => key !== "date")
          .reduce((sum, [, v]) => sum + (typeof v === "number" ? v : 0), 0);
        expect(providerSum).toBe(peak.rum);
      }
    });

    it("events without byProvider contribute to total RUM but not to the provider series (documented limitation)", () => {
      const r = reconstructRumHistory([
        { workspaceId: "a", createdAt: "2026-06-01T00:00:00Z", count: 10, byProvider: { aws: 10 } },
        // No byProvider — legacy/older accumulated event. Total RUM should
        // still include it, but the provider breakdown cannot attribute it.
        { workspaceId: "b", createdAt: "2026-06-02T00:00:00Z", count: 20 },
      ], "2026-06-02");

      const totalDay2 = r.dailyPeaks.find((d) => d.date === "2026-06-02")!;
      expect(totalDay2.rum).toBe(30);

      const providerDay2 = r.dailyByProvider.find((d) => d.date === "2026-06-02")!;
      const providerSum = Object.entries(providerDay2)
        .filter(([key]) => key !== "date")
        .reduce((sum, [, v]) => sum + (typeof v === "number" ? v : 0), 0);
      // Only the 10 attributable to "aws" shows up; the 20 from the
      // byProvider-less event is invisible to the provider series.
      expect(providerSum).toBe(10);
    });

    it("on a net-decrease day, uses the carried-in (higher) provider breakdown to match the daily peak", () => {
      const r = reconstructRumHistory([
        { workspaceId: "a", createdAt: "2026-06-01T00:00:00Z", count: 100, byProvider: { aws: 100 } },
        { workspaceId: "a", createdAt: "2026-06-02T00:00:00Z", count: 80, byProvider: { aws: 80 } },
      ], "2026-06-03");

      const day2Peak = r.dailyPeaks.find((d) => d.date === "2026-06-02")!;
      expect(day2Peak.rum).toBe(100);

      const day2Provider = r.dailyByProvider.find((d) => d.date === "2026-06-02")!;
      expect(day2Provider.aws).toBe(100);

      // Day 3 has no events; carries forward the actual end-of-day-2 value.
      const day3Provider = r.dailyByProvider.find((d) => d.date === "2026-06-03")!;
      expect(day3Provider.aws).toBe(80);
    });

    it("prunes provider keys once their running value nets to zero", () => {
      // Workspace "a" moves entirely off aws onto google. Total RUM
      // increases (10 -> 15), so day 2 is a normal increase day and the
      // event-time snapshot is used — but that snapshot should no longer
      // carry a stale "aws: 0" entry.
      const r = reconstructRumHistory([
        { workspaceId: "a", createdAt: "2026-06-01T00:00:00Z", count: 10, byProvider: { aws: 10 } },
        { workspaceId: "a", createdAt: "2026-06-02T00:00:00Z", count: 15, byProvider: { google: 15 } },
      ], "2026-06-02");

      const day2 = r.dailyByProvider.find((d) => d.date === "2026-06-02")!;
      expect(day2.google).toBe(15);
      expect("aws" in day2).toBe(false);
    });
  });
});
