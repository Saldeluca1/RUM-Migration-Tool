export type StateVersionEvent = {
  workspaceId: string;
  createdAt: string;
  count: number;
  /**
   * Billable RUM count per provider (keyed by the provider short name, e.g.
   * "aws", "google", "grafana") for this state version. Optional: older
   * accumulated events persisted before this field existed, or events that
   * came from the raw-state download fallback, may omit it. See
   * `dailyByProvider` below for how omission is handled.
   */
  byProvider?: Record<string, number>;
};
export type DailyPeak = { date: string; rum: number };
export type MonthlyPeak = { month: string; rum: number; coverage: "full" | "partial" };
export type DailyWorkspaceCount = { date: string; count: number };
export type DailyProviderBreakdown = { date: string; [provider: string]: number | string };
export type RumHistoryResult = {
  dailyPeaks: DailyPeak[];
  monthlyPeaks: MonthlyPeak[];
  annualAverage: number;
  trailing12Average: number;
  fullMonths: number;
  derivedAnnualGrowthPct: number | null;
  historyStart: string | null;
  historyEnd: string | null;
  /**
   * Count of distinct workspaces that have had at least one state-version
   * event on-or-before that day. This is monotonic non-decreasing: TFE/TFC's
   * state-version history has no "workspace deleted" event, so a deleted
   * workspace's earlier events still count here. Callers should present this
   * with a footnote that deletions are not visible.
   */
  dailyWorkspaces: DailyWorkspaceCount[];
  /**
   * Per-provider billable RUM, carried forward the same way dailyPeaks is
   * (step function per workspace). On a day where the running total's
   * day-local peak (from that day's events) is at least as high as the
   * carried-in total, this uses that day's event-time provider snapshot;
   * otherwise (a net-decrease day) the carried-in-from-the-prior-day
   * provider breakdown is used instead, so this always agrees with the
   * `rum` value in the matching `dailyPeaks` entry. Only events that
   * include `byProvider` contribute to these sums — an event without it
   * still counts toward dailyPeaks[].rum (total RUM) but its count is
   * invisible here, so on days with a mix of tagged/untagged events the
   * provider sums can be less than the matching dailyPeaks total for that
   * day.
   */
  dailyByProvider: DailyProviderBreakdown[];
};

function dayKey(iso: string): string {
  return iso.slice(0, 10); // "YYYY-MM-DD"
}
function monthKey(day: string): string {
  return day.slice(0, 7); // "YYYY-MM"
}
function addDay(day: string): string {
  const d = new Date(`${day}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + 1);
  return d.toISOString().slice(0, 10);
}

export function reconstructRumHistory(
  events: StateVersionEvent[],
  today: string
): RumHistoryResult {
  if (events.length === 0) {
    return {
      dailyPeaks: [], monthlyPeaks: [], annualAverage: 0, trailing12Average: 0, fullMonths: 0,
      derivedAnnualGrowthPct: null, historyStart: null, historyEnd: null,
      dailyWorkspaces: [], dailyByProvider: [],
    };
  }

  const sorted = [...events].sort((a, b) => a.createdAt.localeCompare(b.createdAt));
  const historyStart = dayKey(sorted[0].createdAt);
  const historyEnd = today >= historyStart ? today : historyStart;

  // Sweep events, tracking per-workspace latest count and the running total.
  // Record, per day, the maximum running total observed at any event that day.
  const latest = new Map<string, number>();
  const latestByProvider = new Map<string, Record<string, number>>();
  const seenWorkspaces = new Set<string>();
  let runningTotal = 0;
  const runningTotalByProvider = new Map<string, number>();
  const eventDayMax = new Map<string, number>(); // day -> max total after events that day
  const totalAtEndOfDay = new Map<string, number>(); // day -> running total after last event that day
  // day -> provider totals snapshotted at the moment that day's running total peaked
  const eventDayProviderSnapshot = new Map<string, Record<string, number>>();
  // day -> provider totals after the last event that day (end-of-day, for carry-forward)
  const providerAtEndOfDay = new Map<string, Record<string, number>>();
  // day -> distinct workspace count after events that day
  const workspaceCountAtEndOfDay = new Map<string, number>();

  for (const ev of sorted) {
    runningTotal += ev.count - (latest.get(ev.workspaceId) ?? 0);
    latest.set(ev.workspaceId, ev.count);
    seenWorkspaces.add(ev.workspaceId);

    // Only events carrying byProvider update the provider totals. An event
    // without it still moves runningTotal (above) but leaves the workspace's
    // last-known provider split untouched — see RumHistoryResult.dailyByProvider doc.
    if (ev.byProvider) {
      const prevProviders = latestByProvider.get(ev.workspaceId) ?? {};
      for (const [provider, value] of Object.entries(prevProviders)) {
        runningTotalByProvider.set(provider, (runningTotalByProvider.get(provider) ?? 0) - value);
      }
      for (const [provider, value] of Object.entries(ev.byProvider)) {
        runningTotalByProvider.set(provider, (runningTotalByProvider.get(provider) ?? 0) + value);
      }
      // Drop zeroed-out providers so they don't linger forever in
      // dailyByProvider rows / the UI legend once a provider nets to 0.
      for (const [provider, value] of [...runningTotalByProvider]) {
        if (value === 0) runningTotalByProvider.delete(provider);
      }
      latestByProvider.set(ev.workspaceId, ev.byProvider);
    }

    const day = dayKey(ev.createdAt);
    const priorMax = eventDayMax.get(day) ?? 0;
    if (runningTotal >= priorMax) {
      eventDayMax.set(day, runningTotal);
      eventDayProviderSnapshot.set(day, Object.fromEntries(runningTotalByProvider));
    }
    totalAtEndOfDay.set(day, runningTotal);
    providerAtEndOfDay.set(day, Object.fromEntries(runningTotalByProvider));
    workspaceCountAtEndOfDay.set(day, seenWorkspaces.size);
  }

  // Walk every calendar day, carrying the total forward between event days.
  const dailyPeaks: DailyPeak[] = [];
  const dailyWorkspaces: DailyWorkspaceCount[] = [];
  const dailyByProvider: DailyProviderBreakdown[] = [];
  let carried = 0; // total entering the current day
  let carriedProviders: Record<string, number> = {};
  let carriedWorkspaces = 0;
  for (let day = historyStart; day <= historyEnd; day = addDay(day)) {
    const peak = Math.max(carried, eventDayMax.get(day) ?? carried);
    dailyPeaks.push({ date: day, rum: peak });

    // Only trust the day's own event-time snapshot when that day's local
    // event peak actually equals the overall peak — otherwise the peak was
    // set by the carried-in value, and the day's events (e.g. a
    // net-decrease apply) do not reflect the breakdown at the peak moment.
    const providerSnapshot =
      eventDayMax.get(day) === peak
        ? eventDayProviderSnapshot.get(day) ?? carriedProviders
        : carriedProviders;
    dailyByProvider.push({ date: day, ...providerSnapshot });

    const workspaceCount = workspaceCountAtEndOfDay.get(day) ?? carriedWorkspaces;
    dailyWorkspaces.push({ date: day, count: workspaceCount });

    carried = totalAtEndOfDay.get(day) ?? carried;
    carriedProviders = providerAtEndOfDay.get(day) ?? carriedProviders;
    carriedWorkspaces = workspaceCount;
  }

  // Monthly high-water marks from daily peaks.
  const monthMax = new Map<string, number>();
  for (const d of dailyPeaks) {
    const m = monthKey(d.date);
    monthMax.set(m, Math.max(monthMax.get(m) ?? 0, d.rum));
  }
  const firstMonth = monthKey(historyStart);
  const currentMonth = monthKey(historyEnd);
  const monthlyPeaks: MonthlyPeak[] = [...monthMax.entries()]
    .sort((a, b) => a[0].localeCompare(b[0]))
    .map(([month, rum]) => ({
      month,
      rum,
      coverage: month === firstMonth || month === currentMonth ? "partial" : "full",
    }));

  const full = monthlyPeaks.filter((m) => m.coverage === "full");
  const annualAverage = full.length
    ? Math.round(full.reduce((s, m) => s + m.rum, 0) / full.length)
    : 0;
  const trailing12 = full.slice(-12);
  const trailing12Average = trailing12.length
    ? Math.round(trailing12.reduce((s, m) => s + m.rum, 0) / trailing12.length)
    : 0;

  let derivedAnnualGrowthPct: number | null = null;
  if (full.length >= 2 && full[0].rum > 0) {
    const first = full[0];
    const last = full[full.length - 1];
    const [fy, fm] = first.month.split("-").map(Number);
    const [ly, lm] = last.month.split("-").map(Number);
    const monthsBetween = (ly - fy) * 12 + (lm - fm);
    if (monthsBetween > 0) {
      const ratio = last.rum / first.rum;
      derivedAnnualGrowthPct = (Math.pow(ratio, 12 / monthsBetween) - 1) * 100;
    }
  }

  return {
    dailyPeaks, monthlyPeaks, annualAverage, trailing12Average, fullMonths: full.length,
    derivedAnnualGrowthPct, historyStart, historyEnd, dailyWorkspaces, dailyByProvider,
  };
}
