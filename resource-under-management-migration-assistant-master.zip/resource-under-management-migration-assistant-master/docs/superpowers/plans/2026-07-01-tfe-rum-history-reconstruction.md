# TFE/TFC RUM History Reconstruction — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Reconstruct a customer's real historical daily-peak RUM curve from TFE/TFC state versions, prove the day→month→year billing math, derive a growth trend, and offer it as an additive input source to the existing Pack Sizing forecast.

**Architecture:** A pure, zero-dependency reconstruction engine in `packages/rum-engine` turns per-workspace state-version events into daily/monthly high-water marks + annual average + derived CAGR. A new `tfe-client` call lists historical state versions and extracts per-version resource counts from metadata (download+count only as fallback). A fire-and-forget API job (existing POST→202→poll pattern) wires client→engine, persists the record, and accumulates events across runs. The frontend adds a TFE/TFC-only proof view (daily chart, monthly table, billable total with math, CSV) plus an opt-in "load into Pack Sizing" handoff.

**Tech Stack:** TypeScript, Vitest, Express, Zod, React 18 + Carbon + recharts, npm workspaces.

## Global Constraints

- Node.js 24; ESM with `.js` import specifiers in source (e.g. `./tfe-store.js`).
- `packages/rum-engine` MUST stay zero runtime dependencies.
- Never persist raw credentials; redact TFE token before storing any record (token passed to job from original request only).
- Filenames `kebab-case.ts`; React components `PascalCase.tsx`; functions/vars `camelCase`; types `PascalCase`; API routes `kebab-case`.
- Additive only: do NOT modify the unmanaged/managed `getSummary` paths or Pack Sizing's manual input machinery except to add one optional prefill prop.
- Persistence via `atomicWriteFileSync` to `data/*.json`, loaded on startup (copy `tfe-store.ts` exactly).
- Tests colocated as `*.test.ts` and run with Vitest (`npm run test`).

## Dependency graph (for the swarm)

```
Task 1 (rum-engine)  ──┐
Task 2 (tfe-client)  ──┼─→ Task 3 (types+store) ─→ Task 4 (job) ─→ Task 5 (routes) ─→ Task 6 (api.ts) ─→ Task 7 (proof UI) ─→ Task 8 (Pack Sizing handoff)
                        │
Tasks 1 & 2 are fully independent → run in parallel first.
Task 6 types may begin against the locked Task 3/5 interfaces once those are defined.
```

---

## File Structure

- Create: `packages/rum-engine/src/rum-history.ts` — pure reconstruction engine
- Create: `packages/rum-engine/src/rum-history.test.ts`
- Modify: `packages/rum-engine/src/index.ts` — re-export the engine
- Modify: `apps/api/src/tfe-client.ts` — add `listStateVersions` + `extractStateVersionCount`
- Modify: `apps/api/src/tfe-client.test.ts` — cover the new client code
- Create: `apps/api/src/tfe-rum-history-types.ts` — request/record/summary types
- Create: `apps/api/src/tfe-rum-history-store.ts` — Map + JSON persistence + accumulation
- Create: `apps/api/src/tfe-rum-history-store.test.ts`
- Create: `apps/api/src/tfe-rum-history-job.ts` — async job orchestration
- Create: `apps/api/src/tfe-rum-history-job.test.ts`
- Modify: `apps/api/src/server.ts` — Zod schema + routes
- Modify: `apps/web/src/lib/api.ts` — client calls + types
- Create: `apps/web/src/components/RumHistoryTab.tsx` — proof view
- Modify: `apps/web/src/App.tsx` — new tab + Pack Sizing prefill glue
- Modify: `apps/web/src/components/PackSizingTab.tsx` — accept optional prefill prop

---

## Task 1: rum-engine reconstruction (Lane A — no dependencies)

**Files:**
- Create: `packages/rum-engine/src/rum-history.ts`
- Test: `packages/rum-engine/src/rum-history.test.ts`
- Modify: `packages/rum-engine/src/index.ts` (add re-export at end)

**Interfaces:**
- Consumes: nothing (pure).
- Produces:
```ts
export type StateVersionEvent = { workspaceId: string; createdAt: string; count: number };
export type DailyPeak = { date: string; rum: number };            // date = "YYYY-MM-DD"
export type MonthlyPeak = { month: string; rum: number; coverage: "full" | "partial" }; // month = "YYYY-MM"
export type RumHistoryResult = {
  dailyPeaks: DailyPeak[];
  monthlyPeaks: MonthlyPeak[];
  annualAverage: number;                 // mean of full-coverage monthly peaks (0 if none)
  fullMonths: number;
  derivedAnnualGrowthPct: number | null; // CAGR first→last full month; null if <2 full months or first peak 0
  historyStart: string | null;           // "YYYY-MM-DD" of earliest event, or null
  historyEnd: string | null;             // the "as of" date used ("YYYY-MM-DD")
};
export function reconstructRumHistory(events: StateVersionEvent[], today: string): RumHistoryResult;
```

**Algorithm (implement exactly this semantics):**
Total RUM is a step function `T(t) = Σ_workspace latestCount(ws, t)`, where `latestCount` is the count of the most recent event for that workspace with `createdAt ≤ t` (0 before first). The high-water mark over any window = `max(T(carried into window), T just after each event in window)`. Compute per calendar day for `dailyPeaks`, then per month for `monthlyPeaks`. `coverage` = "partial" for the first month (retention blind spot before earliest event) and the current month of `today` (not yet complete); every month strictly between is "full". Iterate day-by-day from `historyStart` to `historyEnd` using UTC dates.

- [ ] **Step 1: Write the failing tests**

```ts
import { describe, it, expect } from "vitest";
import { reconstructRumHistory } from "./rum-history.js";

describe("reconstructRumHistory", () => {
  it("returns empty result for no events", () => {
    const r = reconstructRumHistory([], "2026-06-15");
    expect(r.dailyPeaks).toEqual([]);
    expect(r.monthlyPeaks).toEqual([]);
    expect(r.annualAverage).toBe(0);
    expect(r.fullMonths).toBe(0);
    expect(r.derivedAnnualGrowthPct).toBeNull();
    expect(r.historyStart).toBeNull();
  });

  it("sums counts across workspaces as a step function", () => {
    const r = reconstructRumHistory([
      { workspaceId: "a", createdAt: "2026-01-10T00:00:00Z", count: 100 },
      { workspaceId: "b", createdAt: "2026-01-20T00:00:00Z", count: 50 },
    ], "2026-01-31");
    // After Jan 20 total = 150; that is January's high-water mark
    const jan = r.monthlyPeaks.find((m) => m.month === "2026-01");
    expect(jan?.rum).toBe(150);
  });

  it("carries a workspace count forward into later months with no events", () => {
    const r = reconstructRumHistory([
      { workspaceId: "a", createdAt: "2026-01-10T00:00:00Z", count: 200 },
    ], "2026-03-31");
    expect(r.monthlyPeaks.find((m) => m.month === "2026-02")?.rum).toBe(200);
    expect(r.monthlyPeaks.find((m) => m.month === "2026-03")?.rum).toBe(200);
  });

  it("captures the intra-month peak even when a later apply shrinks the count", () => {
    const r = reconstructRumHistory([
      { workspaceId: "a", createdAt: "2026-05-05T00:00:00Z", count: 500 },
      { workspaceId: "a", createdAt: "2026-05-25T00:00:00Z", count: 300 },
    ], "2026-05-31");
    expect(r.monthlyPeaks.find((m) => m.month === "2026-05")?.rum).toBe(500);
  });

  it("flags first and current month partial, middle months full", () => {
    const r = reconstructRumHistory([
      { workspaceId: "a", createdAt: "2026-01-10T00:00:00Z", count: 100 },
    ], "2026-03-15");
    expect(r.monthlyPeaks.find((m) => m.month === "2026-01")?.coverage).toBe("partial");
    expect(r.monthlyPeaks.find((m) => m.month === "2026-02")?.coverage).toBe("full");
    expect(r.monthlyPeaks.find((m) => m.month === "2026-03")?.coverage).toBe("partial");
  });

  it("averages only full months for annualAverage", () => {
    const r = reconstructRumHistory([
      { workspaceId: "a", createdAt: "2026-01-10T00:00:00Z", count: 100 }, // Jan partial
      { workspaceId: "a", createdAt: "2026-02-10T00:00:00Z", count: 200 }, // Feb full=200
      { workspaceId: "a", createdAt: "2026-03-10T00:00:00Z", count: 400 }, // Mar full=400
    ], "2026-04-15"); // Apr partial (=400 carried)
    // full months: Feb=200, Mar=400 → avg 300
    expect(r.annualAverage).toBe(300);
    expect(r.fullMonths).toBe(2);
  });

  it("derives CAGR from first to last full month", () => {
    const r = reconstructRumHistory([
      { workspaceId: "a", createdAt: "2026-01-01T00:00:00Z", count: 100 },
      { workspaceId: "a", createdAt: "2026-02-10T00:00:00Z", count: 100 }, // Feb full=100
      { workspaceId: "a", createdAt: "2026-08-10T00:00:00Z", count: 200 }, // Aug full=200
    ], "2026-09-15");
    // Feb(100) → Aug(200): 6 months, ratio 2 → annualized ((2)^(12/6)-1)*100 = 300
    expect(Math.round(r.derivedAnnualGrowthPct!)).toBe(300);
  });

  it("emits one daily peak per calendar day in range", () => {
    const r = reconstructRumHistory([
      { workspaceId: "a", createdAt: "2026-06-01T00:00:00Z", count: 10 },
    ], "2026-06-05");
    expect(r.dailyPeaks.map((d) => d.date)).toEqual([
      "2026-06-01", "2026-06-02", "2026-06-03", "2026-06-04", "2026-06-05",
    ]);
    expect(r.dailyPeaks.every((d) => d.rum === 10)).toBe(true);
    expect(r.historyStart).toBe("2026-06-01");
    expect(r.historyEnd).toBe("2026-06-05");
  });
});
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `npm run test -w @rum-tool/rum-engine -- rum-history`
Expected: FAIL — `reconstructRumHistory is not a function` / module not found.

- [ ] **Step 3: Implement `rum-history.ts`**

```ts
export type StateVersionEvent = { workspaceId: string; createdAt: string; count: number };
export type DailyPeak = { date: string; rum: number };
export type MonthlyPeak = { month: string; rum: number; coverage: "full" | "partial" };
export type RumHistoryResult = {
  dailyPeaks: DailyPeak[];
  monthlyPeaks: MonthlyPeak[];
  annualAverage: number;
  fullMonths: number;
  derivedAnnualGrowthPct: number | null;
  historyStart: string | null;
  historyEnd: string | null;
};

function dayKey(iso: string): string {
  return iso.slice(0, 10); // "YYYY-MM-DD"
}
function monthKey(day: string): string {
  return day.slice(0, 7); // "YYYY-MM"
}
function addDay(day: string): string {
  const d = new Date(`${day}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + 1);
  return d.toISOString().slice(0, 10);
}

export function reconstructRumHistory(
  events: StateVersionEvent[],
  today: string
): RumHistoryResult {
  if (events.length === 0) {
    return {
      dailyPeaks: [], monthlyPeaks: [], annualAverage: 0, fullMonths: 0,
      derivedAnnualGrowthPct: null, historyStart: null, historyEnd: null,
    };
  }

  const sorted = [...events].sort((a, b) => a.createdAt.localeCompare(b.createdAt));
  const historyStart = dayKey(sorted[0].createdAt);
  const historyEnd = today >= historyStart ? today : historyStart;

  // Sweep events, tracking per-workspace latest count and the running total.
  // Record, per day, the maximum running total observed at any event that day.
  const latest = new Map<string, number>();
  let runningTotal = 0;
  const eventDayMax = new Map<string, number>(); // day -> max total after events that day
  const totalAtEndOfDay = new Map<string, number>(); // day -> running total after last event that day
  for (const ev of sorted) {
    runningTotal += ev.count - (latest.get(ev.workspaceId) ?? 0);
    latest.set(ev.workspaceId, ev.count);
    const day = dayKey(ev.createdAt);
    eventDayMax.set(day, Math.max(eventDayMax.get(day) ?? 0, runningTotal));
    totalAtEndOfDay.set(day, runningTotal);
  }

  // Walk every calendar day, carrying the total forward between event days.
  const dailyPeaks: DailyPeak[] = [];
  let carried = 0; // total entering the current day
  for (let day = historyStart; day <= historyEnd; day = addDay(day)) {
    const peak = Math.max(carried, eventDayMax.get(day) ?? carried);
    dailyPeaks.push({ date: day, rum: peak });
    carried = totalAtEndOfDay.get(day) ?? carried;
  }

  // Monthly high-water marks from daily peaks.
  const monthMax = new Map<string, number>();
  for (const d of dailyPeaks) {
    const m = monthKey(d.date);
    monthMax.set(m, Math.max(monthMax.get(m) ?? 0, d.rum));
  }
  const firstMonth = monthKey(historyStart);
  const currentMonth = monthKey(historyEnd);
  const monthlyPeaks: MonthlyPeak[] = [...monthMax.entries()]
    .sort((a, b) => a[0].localeCompare(b[0]))
    .map(([month, rum]) => ({
      month,
      rum,
      coverage: month === firstMonth || month === currentMonth ? "partial" : "full",
    }));

  const full = monthlyPeaks.filter((m) => m.coverage === "full");
  const annualAverage = full.length
    ? Math.round(full.reduce((s, m) => s + m.rum, 0) / full.length)
    : 0;

  let derivedAnnualGrowthPct: number | null = null;
  if (full.length >= 2 && full[0].rum > 0) {
    const first = full[0];
    const last = full[full.length - 1];
    const [fy, fm] = first.month.split("-").map(Number);
    const [ly, lm] = last.month.split("-").map(Number);
    const monthsBetween = (ly - fy) * 12 + (lm - fm);
    if (monthsBetween > 0) {
      const ratio = last.rum / first.rum;
      derivedAnnualGrowthPct = (Math.pow(ratio, 12 / monthsBetween) - 1) * 100;
    }
  }

  return { dailyPeaks, monthlyPeaks, annualAverage, fullMonths: full.length, derivedAnnualGrowthPct, historyStart, historyEnd };
}
```

- [ ] **Step 4: Re-export from index**

Add to the end of `packages/rum-engine/src/index.ts`:
```ts
export * from "./rum-history.js";
```

- [ ] **Step 5: Run tests to verify they pass**

Run: `npm run test -w @rum-tool/rum-engine -- rum-history`
Expected: PASS (all 8 tests).

- [ ] **Step 6: Commit**

```bash
git add packages/rum-engine/src/rum-history.ts packages/rum-engine/src/rum-history.test.ts packages/rum-engine/src/index.ts
git commit -m "feat(rum-engine): reconstruct daily/monthly peak RUM history"
```

---

## Task 2: tfe-client historical state versions (Lane B — no dependencies)

**Files:**
- Modify: `apps/api/src/tfe-client.ts` (add types + two functions)
- Test: `apps/api/src/tfe-client.test.ts` (append tests)

**Interfaces:**
- Consumes: existing module-private `tfeApiFetch`, `downloadState`, `TfeClientOptions`.
- Produces:
```ts
export type TfeHistoricalStateVersion = {
  id: string;
  attributes: {
    serial: number;
    "created-at": string;
    "resources-processed"?: boolean;
    "resource-count"?: number;
    resources?: unknown[];
    "hosted-state-download-url"?: string;
  };
};
// Returns count from metadata, or null when the state must be downloaded to count.
export function extractStateVersionCount(sv: TfeHistoricalStateVersion): number | null;
// Lists ALL state versions for a workspace (by name), newest-first, paginated.
export function listStateVersions(
  options: TfeClientOptions,
  orgName: string,
  workspaceName: string
): Promise<TfeHistoricalStateVersion[]>;
```

**Notes:** The list endpoint is `GET /api/v2/state-versions?filter[workspace][name]=<ws>&filter[organization][name]=<org>&page[size]=100&page[number]=N` (paginate via `meta.pagination["next-page"]`, exactly like `listAllWorkspaces`). `extractStateVersionCount` prefers `attributes["resource-count"]`, else `attributes.resources.length`, else returns `null` when `resources-processed === false` or no count is derivable.

- [ ] **Step 1: Write failing tests** (append to `tfe-client.test.ts`)

```ts
import { describe, it, expect, vi, afterEach } from "vitest";
import { extractStateVersionCount, listStateVersions } from "./tfe-client.js";

describe("extractStateVersionCount", () => {
  it("prefers the resource-count attribute", () => {
    expect(extractStateVersionCount({ id: "sv-1", attributes: { serial: 1, "created-at": "x", "resource-count": 42 } })).toBe(42);
  });
  it("falls back to resources array length", () => {
    expect(extractStateVersionCount({ id: "sv-1", attributes: { serial: 1, "created-at": "x", resources: [{}, {}, {}] } })).toBe(3);
  });
  it("returns null when not yet processed", () => {
    expect(extractStateVersionCount({ id: "sv-1", attributes: { serial: 1, "created-at": "x", "resources-processed": false } })).toBeNull();
  });
});

describe("listStateVersions", () => {
  afterEach(() => vi.restoreAllMocks());
  it("paginates and accumulates all versions", async () => {
    const page1 = { data: [{ id: "sv-2", attributes: { serial: 2, "created-at": "2026-02-01T00:00:00Z" } }], meta: { pagination: { "next-page": 2 } } };
    const page2 = { data: [{ id: "sv-1", attributes: { serial: 1, "created-at": "2026-01-01T00:00:00Z" } }], meta: { pagination: { "next-page": null } } };
    const fetchMock = vi.spyOn(global, "fetch")
      .mockResolvedValueOnce({ ok: true, status: 200, json: async () => page1 } as Response)
      .mockResolvedValueOnce({ ok: true, status: 200, json: async () => page2 } as Response);
    const result = await listStateVersions({ hostname: "https://tfe.example.com", token: "t" }, "acme", "prod");
    expect(result.map((v) => v.id)).toEqual(["sv-2", "sv-1"]);
    expect(fetchMock).toHaveBeenCalledTimes(2);
    expect((fetchMock.mock.calls[0][0] as string)).toContain("/api/v2/state-versions?filter%5Bworkspace%5D%5Bname%5D=prod".slice(0, 24));
  });
});
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `npm run test -w @rum-tool/api -- tfe-client`
Expected: FAIL — `extractStateVersionCount`/`listStateVersions` are not exported.

- [ ] **Step 3: Implement in `tfe-client.ts`**

Add the `TfeHistoricalStateVersion` type near `TfeStateVersion`, then append these functions (they reuse the existing private `tfeApiFetch` and `TfeApiResponse`):
```ts
export type TfeHistoricalStateVersion = {
  id: string;
  attributes: {
    serial: number;
    "created-at": string;
    "resources-processed"?: boolean;
    "resource-count"?: number;
    resources?: unknown[];
    "hosted-state-download-url"?: string;
  };
};

export function extractStateVersionCount(sv: TfeHistoricalStateVersion): number | null {
  const attr = sv.attributes;
  if (typeof attr["resource-count"] === "number") return attr["resource-count"];
  if (Array.isArray(attr.resources)) return attr.resources.length;
  return null; // caller must download the state and count
}

export async function listStateVersions(
  options: TfeClientOptions,
  orgName: string,
  workspaceName: string
): Promise<TfeHistoricalStateVersion[]> {
  const versions: TfeHistoricalStateVersion[] = [];
  let page = 1;
  const pageSize = 100;
  // eslint-disable-next-line no-constant-condition
  while (true) {
    const url =
      `${options.hostname}/api/v2/state-versions` +
      `?filter[workspace][name]=${encodeURIComponent(workspaceName)}` +
      `&filter[organization][name]=${encodeURIComponent(orgName)}` +
      `&page[size]=${pageSize}&page[number]=${page}`;
    const result = await tfeApiFetch<TfeApiResponse<TfeHistoricalStateVersion[]>>(
      url, options.token, options.tlsInsecure
    );
    versions.push(...result.data);
    const nextPage = result.meta?.pagination?.["next-page"];
    if (!nextPage) break;
    page = nextPage;
  }
  return versions;
}
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `npm run test -w @rum-tool/api -- tfe-client`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add apps/api/src/tfe-client.ts apps/api/src/tfe-client.test.ts
git commit -m "feat(tfe-client): list historical state versions + count extraction"
```

---

## Task 3: RUM history types + store (depends on Task 1)

**Files:**
- Create: `apps/api/src/tfe-rum-history-types.ts`
- Create: `apps/api/src/tfe-rum-history-store.ts`
- Test: `apps/api/src/tfe-rum-history-store.test.ts`

**Interfaces:**
- Consumes: `RumHistoryResult`, `StateVersionEvent` from `@rum-tool/rum-engine`.
- Produces:
```ts
// tfe-rum-history-types.ts
export type RumHistoryStatus = "queued" | "running" | "completed" | "failed";
export type RumHistoryRequest = {
  tfeHostname: string; tfeToken: string; organization: string;
  workspaceFilter?: string; tlsInsecure?: boolean;
};
export type RumHistoryRecord = {
  id: string; status: RumHistoryStatus; createdAt: string; updatedAt: string;
  request: Omit<RumHistoryRequest, "tfeToken"> & { tfeToken: string };
  errorMessage?: string;
  progress?: { phase: "connecting" | "listing_workspaces" | "listing_versions" | "reconstructing"; workspacesFound?: number; workspacesProcessed?: number };
  events?: StateVersionEvent[]; // accumulated, deduped by workspaceId+createdAt
  result?: RumHistoryResult;
};
// tfe-rum-history-store.ts
export function redactRumHistoryRequest(r: RumHistoryRequest): RumHistoryRecord["request"];
export function createRumHistoryRun(request: RumHistoryRequest): RumHistoryRecord;
export function updateRumHistoryRun(id: string, updater: (c: RumHistoryRecord) => RumHistoryRecord): RumHistoryRecord | null;
export function getRumHistoryRun(id: string): RumHistoryRecord | null;
export function listRumHistoryRuns(): RumHistoryRecord[];
export function getPriorEventsForOrg(hostname: string, organization: string): StateVersionEvent[];
```

- [ ] **Step 1: Write failing store tests**

```ts
import { describe, it, expect } from "vitest";
import { createRumHistoryRun, updateRumHistoryRun, getRumHistoryRun, getPriorEventsForOrg } from "./tfe-rum-history-store.js";

describe("tfe-rum-history-store", () => {
  const req = { tfeHostname: "https://tfe.x", tfeToken: "secret", organization: "acme" };
  it("redacts the token on create", () => {
    const rec = createRumHistoryRun(req);
    expect(rec.request.tfeToken).toBe("***redacted***");
    expect(rec.status).toBe("queued");
  });
  it("updates and reads back", () => {
    const rec = createRumHistoryRun(req);
    updateRumHistoryRun(rec.id, (c) => ({ ...c, status: "completed", events: [{ workspaceId: "w", createdAt: "2026-01-01T00:00:00Z", count: 5 }] }));
    expect(getRumHistoryRun(rec.id)?.status).toBe("completed");
  });
  it("returns prior events for the same org for accumulation", () => {
    const rec = createRumHistoryRun(req);
    updateRumHistoryRun(rec.id, (c) => ({ ...c, status: "completed", events: [{ workspaceId: "w", createdAt: "2026-01-01T00:00:00Z", count: 5 }] }));
    const prior = getPriorEventsForOrg("https://tfe.x", "acme");
    expect(prior).toContainEqual({ workspaceId: "w", createdAt: "2026-01-01T00:00:00Z", count: 5 });
  });
});
```

- [ ] **Step 2: Run to verify fail**

Run: `npm run test -w @rum-tool/api -- tfe-rum-history-store`
Expected: FAIL — module not found.

- [ ] **Step 3: Create `tfe-rum-history-types.ts`** — paste the Produces block above (types only).

- [ ] **Step 4: Create `tfe-rum-history-store.ts`** — copy `tfe-store.ts` verbatim, then adapt: rename map to `runs`, `STORE_PATH` to `data/tfe-rum-history.json`, types to the new ones, and add `getPriorEventsForOrg`:
```ts
export function getPriorEventsForOrg(hostname: string, organization: string): StateVersionEvent[] {
  const matches = [...runs.values()]
    .filter((r) => r.status === "completed" && r.request.tfeHostname === hostname && r.request.organization === organization)
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  return matches[0]?.events ?? [];
}
```
Redaction mirrors `redactTfeRequest`: `{ ...request, tfeToken: request.tfeToken ? "***redacted***" : "" }`.

- [ ] **Step 5: Run to verify pass**

Run: `npm run test -w @rum-tool/api -- tfe-rum-history-store`
Expected: PASS.

- [ ] **Step 6: Commit**

```bash
git add apps/api/src/tfe-rum-history-types.ts apps/api/src/tfe-rum-history-store.ts apps/api/src/tfe-rum-history-store.test.ts
git commit -m "feat(api): RUM history record types + persistent store with org accumulation"
```

---

## Task 4: RUM history job (depends on Tasks 1, 2, 3)

**Files:**
- Create: `apps/api/src/tfe-rum-history-job.ts`
- Test: `apps/api/src/tfe-rum-history-job.test.ts`

**Interfaces:**
- Consumes: `listAllWorkspaces`, `listStateVersions`, `extractStateVersionCount`, `downloadState` (tfe-client); `reconstructRumHistory`, `parseTerraformState`, `calculateRumFromState` (rum-engine); store fns; `getPriorEventsForOrg`.
- Produces: `export async function runRumHistoryJob(runId: string, request: RumHistoryRequest): Promise<void>;`

**Behavior:** connecting → listing_workspaces (`listAllWorkspaces`) → for each workspace `listStateVersions`, and for each version derive a count: `extractStateVersionCount(sv)`; if `null` and a download URL exists, `downloadState` + `calculateRumFromState(parseTerraformState(raw)).totalRum`; skip versions with no count. Build `StateVersionEvent[]` `{ workspaceId, createdAt: sv.attributes["created-at"], count }`. Union with `getPriorEventsForOrg(...)`, dedupe by `workspaceId + createdAt` (fresh wins). Call `reconstructRumHistory(events, new Date().toISOString().slice(0,10))`. Persist `events` + `result`, status `completed`. On throw: status `failed`, `errorMessage`. Follow `runTfeMigrationJob`'s progress/try-catch shape exactly.

- [ ] **Step 1: Write failing test** (mock tfe-client + rum-engine)

```ts
import { describe, it, expect, vi, beforeEach } from "vitest";

vi.mock("./tfe-client.js", () => ({
  listAllWorkspaces: vi.fn(async () => [{ id: "ws-1", attributes: { name: "prod" } }]),
  listStateVersions: vi.fn(async () => [
    { id: "sv-1", attributes: { serial: 1, "created-at": "2026-01-10T00:00:00Z", "resource-count": 100 } },
    { id: "sv-2", attributes: { serial: 2, "created-at": "2026-02-10T00:00:00Z", "resource-count": 200 } },
  ]),
  extractStateVersionCount: (sv: any) => sv.attributes["resource-count"] ?? null,
  downloadState: vi.fn(),
}));

import { runRumHistoryJob } from "./tfe-rum-history-job.js";
import { createRumHistoryRun, getRumHistoryRun } from "./tfe-rum-history-store.js";

describe("runRumHistoryJob", () => {
  it("reconstructs and completes", async () => {
    const rec = createRumHistoryRun({ tfeHostname: "https://tfe.x", tfeToken: "t", organization: "acme" });
    await runRumHistoryJob(rec.id, { tfeHostname: "https://tfe.x", tfeToken: "t", organization: "acme" });
    const done = getRumHistoryRun(rec.id);
    expect(done?.status).toBe("completed");
    expect(done?.result?.monthlyPeaks.length).toBeGreaterThan(0);
    expect(done?.events?.length).toBe(2);
  });
});
```

- [ ] **Step 2: Run to verify fail** — `npm run test -w @rum-tool/api -- tfe-rum-history-job` → FAIL (module not found).

- [ ] **Step 3: Implement `tfe-rum-history-job.ts`** per the Behavior block, mirroring `tfe-job.ts` structure (import list from Interfaces; use `updateRumHistoryRun` for each phase; wrap body in try/catch setting `failed`).

- [ ] **Step 4: Run to verify pass** — same command → PASS.

- [ ] **Step 5: Commit**

```bash
git add apps/api/src/tfe-rum-history-job.ts apps/api/src/tfe-rum-history-job.test.ts
git commit -m "feat(api): RUM history reconstruction job wiring client to engine"
```

---

## Task 5: API routes (depends on Task 4)

**Files:**
- Modify: `apps/api/src/server.ts`

**Interfaces:**
- Consumes: store fns + `runRumHistoryJob`.
- Produces routes: `POST /tfe/rum-history/runs` (202 + record), `GET /tfe/rum-history/runs`, `GET /tfe/rum-history/runs/:id`.

- [ ] **Step 1: Add imports** near the existing tfe imports:
```ts
import { createRumHistoryRun, getRumHistoryRun, listRumHistoryRuns } from "./tfe-rum-history-store.js";
import { runRumHistoryJob } from "./tfe-rum-history-job.js";
```

- [ ] **Step 2: Add Zod schema** after `tfeMigrationRequestSchema`:
```ts
const rumHistoryRequestSchema = tfeConnectionSchema.extend({
  workspaceFilter: z.string().optional(),
});
```

- [ ] **Step 3: Add routes** after the `/tfe/migration/runs` block:
```ts
app.post("/tfe/rum-history/runs", (req, res) => {
  const parsed = rumHistoryRequestSchema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.flatten() }); return; }
  const record = createRumHistoryRun(parsed.data);
  void runRumHistoryJob(record.id, parsed.data);
  res.status(202).json(record);
});
app.get("/tfe/rum-history/runs", (_req, res) => {
  res.json({ runs: listRumHistoryRuns() });
});
app.get("/tfe/rum-history/runs/:id", (req, res) => {
  const record = getRumHistoryRun(req.params.id);
  if (!record) { res.status(404).json({ error: "RUM history run not found" }); return; }
  res.json(record);
});
```

- [ ] **Step 4: Verify build + existing tests still pass**

Run: `npm run build -w @rum-tool/api && npm run test -w @rum-tool/api`
Expected: build succeeds; all API tests PASS.

- [ ] **Step 5: Commit**

```bash
git add apps/api/src/server.ts
git commit -m "feat(api): POST/GET routes for TFE RUM history runs"
```

---

## Task 6: Frontend API client (depends on Task 5)

**Files:**
- Modify: `apps/web/src/lib/api.ts`

**Interfaces:**
- Produces:
```ts
export type RumHistoryRunStatus = "queued" | "running" | "completed" | "failed";
export type RumMonthlyPeak = { month: string; rum: number; coverage: "full" | "partial" };
export type RumDailyPeak = { date: string; rum: number };
export type RumHistoryResultDto = {
  dailyPeaks: RumDailyPeak[]; monthlyPeaks: RumMonthlyPeak[];
  annualAverage: number; fullMonths: number; derivedAnnualGrowthPct: number | null;
  historyStart: string | null; historyEnd: string | null;
};
export type RumHistoryRun = {
  id: string; status: RumHistoryRunStatus; errorMessage?: string;
  progress?: { phase: string; workspacesFound?: number; workspacesProcessed?: number };
  result?: RumHistoryResultDto;
};
export function startRumHistoryRun(payload: { tfeHostname: string; tfeToken: string; organization: string; workspaceFilter?: string; tlsInsecure?: boolean; }): Promise<RumHistoryRun>;
export function getRumHistoryRun(id: string): Promise<RumHistoryRun>;
```

- [ ] **Step 1: Add the types + two fetchers**, matching the existing `startScan`/`getScan` style (POST to `${API_BASE}/tfe/rum-history/runs`, GET `${API_BASE}/tfe/rum-history/runs/${id}`; throw on `!response.ok`).

- [ ] **Step 2: Typecheck** — `npm run build -w @rum-tool/web` → succeeds.

- [ ] **Step 3: Commit**

```bash
git add apps/web/src/lib/api.ts
git commit -m "feat(web): API client for TFE RUM history runs"
```

---

## Task 7: Proof view UI (depends on Task 6)

**Files:**
- Create: `apps/web/src/components/RumHistoryTab.tsx`
- Modify: `apps/web/src/App.tsx`

**Interfaces:**
- Consumes: `startRumHistoryRun`, `getRumHistoryRun`, `RumHistoryRun` from `../lib/api`.
- Produces: `export function RumHistoryTab({ onLoadIntoPackSizing }: { onLoadIntoPackSizing: (p: { monthlyValues: number[]; annualAverage: number; growthPct: number | null }) => void }): JSX.Element;`

**Content:** a TFE connection form (hostname/token/org/workspaceFilter — mirror `TfeMigrationTab` fields), a Start button that POSTs then polls `getRumHistoryRun` every 1s until `status` is `completed`/`failed`, then renders:
- Recharts `LineChart` of `result.dailyPeaks` (x=date, y=rum) — the proof.
- Carbon `DataTable`/`Table` of `result.monthlyPeaks` with a "partial" tag on partial months.
- A `Tile` showing the billable total = `annualAverage`, with the inline sentence: "Average of N full-month high-water marks" and the derived growth `%`.
- A CSV download button building a data URL from `monthlyPeaks` (reuse the `managedRowsToCsv` string-join style).
- A "Load into Pack Sizing" button → `onLoadIntoPackSizing({ monthlyValues: last12MonthlyPeakRums, annualAverage, growthPct: derivedAnnualGrowthPct })`.

- [ ] **Step 1: Create `RumHistoryTab.tsx`** implementing the above (Carbon + recharts, both already dependencies; copy polling pattern from an existing tab that polls, e.g. `UnmanagedEstimatorTab`).

- [ ] **Step 2: Wire the tab in `App.tsx`** — extend `TabId` to include `"rum-history"`, add the import, a tab `Button`, and a `<div style={{ display: activeTab === "rum-history" ? "block" : "none" }}>` block rendering `<RumHistoryTab onLoadIntoPackSizing={...} />` (glue completed in Task 8).

- [ ] **Step 3: Manual smoke** — `npm run dev`, open the tab, confirm it renders the form (no runtime errors in console).

- [ ] **Step 4: Commit**

```bash
git add apps/web/src/components/RumHistoryTab.tsx apps/web/src/App.tsx
git commit -m "feat(web): TFE RUM history proof view (daily chart, monthly table, billable total)"
```

---

## Task 8: Pack Sizing handoff (depends on Task 7)

**Files:**
- Modify: `apps/web/src/components/PackSizingTab.tsx`
- Modify: `apps/web/src/App.tsx`

**Interfaces:**
- Consumes: nothing new.
- Produces: `PackSizingTab` accepts an optional `prefill?: { monthlyValues: number[]; annualAverage: number; growthPct: number | null }` prop.

**Behavior (additive — must not change default/manual behavior):** when `prefill` changes to a defined value, `PackSizingTab` sets `useMonthlyMode = true`, `monthlyValues = prefill.monthlyValues`, and if `prefill.growthPct != null` sets `forecastGrowthPct = Math.round(prefill.growthPct)`. When `prefill` is undefined (the default), every input behaves exactly as today.

- [ ] **Step 1: Write a failing component test** `apps/web/src/components/PackSizingTab.test.tsx` (Vitest + @testing-library/react if present; otherwise assert the pure `buildChartData` path). Assert that rendering with `prefill={{ monthlyValues: [10,20,...], annualAverage: 15, growthPct: 30 }}` populates the monthly inputs. If no RTL harness exists, instead unit-test a new pure helper `applyPrefill(state, prefill)` extracted from the effect and cover it directly.

- [ ] **Step 2: Run to verify fail** — `npm run test -w @rum-tool/web -- PackSizingTab` → FAIL.

- [ ] **Step 3: Implement the optional `prefill` prop + `useEffect`** in `PackSizingTab.tsx` per Behavior.

- [ ] **Step 4: Complete the App glue** — in `App.tsx`, add `const [packPrefill, setPackPrefill] = useState<...>();`, pass `onLoadIntoPackSizing={(p) => { setPackPrefill(p); setActiveTab("pack"); }}` to `RumHistoryTab`, and `prefill={packPrefill}` to `<PackSizingTab />`.

- [ ] **Step 5: Run to verify pass + build** — `npm run test -w @rum-tool/web -- PackSizingTab && npm run build -w @rum-tool/web` → PASS + build succeeds.

- [ ] **Step 6: Manual end-to-end smoke** — reconstruct a run, click "Load into Pack Sizing", confirm the tab switches and the chart reflects real monthly peaks.

- [ ] **Step 7: Commit**

```bash
git add apps/web/src/components/PackSizingTab.tsx apps/web/src/components/PackSizingTab.test.tsx apps/web/src/App.tsx
git commit -m "feat(web): load reconstructed RUM history into Pack Sizing as an additive source"
```

---

## Self-Review

**Spec coverage:** Billing math + daily proof → Task 1. Cheap metadata counts + download fallback → Tasks 2, 4. Fire-and-forget job + redaction + accumulation → Tasks 3, 4, 5. Backward "reconstruct all available" + partial flags → Task 1. Forward CAGR feeding Pack Sizing → Tasks 1, 8. Additive (no path replaced) → Task 8 optional prop. Proof surfaces (chart/table/total/CSV) → Task 7. Out-of-scope (multi-org, sub-daily, fabricated months) → not implemented, by construction.

**Placeholder scan:** No TBD/TODO; every code step shows code; test steps show assertions with concrete expected numbers.

**Type consistency:** `StateVersionEvent`, `RumHistoryResult`, `MonthlyPeak.coverage: "full"|"partial"`, `derivedAnnualGrowthPct: number|null` are used identically across Tasks 1, 3, 4, 6. Store fn names (`createRumHistoryRun`/`updateRumHistoryRun`/`getRumHistoryRun`/`listRumHistoryRuns`/`getPriorEventsForOrg`) match between Tasks 3, 4, 5. `runRumHistoryJob` signature matches between Tasks 4 and 5. `onLoadIntoPackSizing` payload shape matches between Tasks 7 and 8.
