# Customer-Zip Hardening — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make the RUM History reconstruction defensible and self-serve-able so a workspace-licensed customer (no RUM visibility in their own TFE/TFC UI) can run the tool themselves against their TFE/TFC and produce a trustworthy RUM estimate.

**Architecture:** Fix the metadata count path to respect RUM billing exclusions (data sources, `null_resource`, `terraform_data`); add a trailing-12-full-months billable figure to the engine + UI; add a shareable summary export with a version stamp + estimate disclaimer; validate the docker-compose cold-start path a customer would use.

**Tech Stack:** unchanged (TypeScript, Vitest, Express, React/Carbon/recharts, Docker Compose).

**Context:** RUM billing counts only managed resources; excluded are `mode: "data"` resources and types `null_resource` / `terraform_data` (see `EXCLUDED_TYPES` + `calculateRumFromState` in `packages/rum-engine/src/index.ts`). Today `extractStateVersionCount` (apps/api/src/tfe-client.ts) returns `resource-count` or `resources.length` — the RAW count — so historical numbers can OVERSTATE billable RUM. Overstating is the one direction a customer-facing estimate cannot do.

## Global Constraints

- `packages/rum-engine` stays zero runtime dependencies; ESM `.js` import specifiers in apps/api and source-relative imports.
- Never persist or log raw tokens.
- Staging discipline: `apps/api/src/tfe-client.test.ts` carries an uncommitted user WIP (`describe("listOrganizations", ...)`) — stage ONLY task files, never `git add -A`/`.`. If a task must edit that file, stash the WIP, edit/commit, pop the stash, verify `grep -c 'describe("listOrganizations"' apps/api/src/tfe-client.test.ts` = 1.
- Tests: Vitest, colocated `*.test.ts`. TDD for logic changes.
- All numbers shown to customers are labeled estimates, never quotes.

## Dependency graph

```
Task A (billing-aware counts)  ─→ Task C (trailing-12) ─→ Task B (export + disclaimer)
Task D (compose cold-start)    ── independent, run any time
```

---

## Task A: Billing-aware historical counts

**Files:**
- Modify: `apps/api/src/tfe-client.ts` (`extractStateVersionCount` + type)
- Modify: `apps/api/src/tfe-client.test.ts` (⚠️ WIP stash protocol above)
- Possibly modify: `apps/api/src/tfe-rum-history-job.ts` (fallback wiring)

**Step 0 — empirical API check (required before coding):** Read the TFC token via `jq -r '.credentials["app.terraform.io"].token' ~/.terraform.d/credentials.tfrc.json` into a shell variable (never echo it). Curl one real state version list for your test org (any org your token can read) (`GET https://app.terraform.io/api/v2/state-versions?filter[organization][name]=<your-org>&filter[workspace][name]=<pick one via the workspaces API>&page[size]=1`) and inspect `data[0].attributes.resources` — record in your report EXACTLY which fields each entry has (looking for `type`, `count`, and ideally `mode` or a data-source marker) and whether `resource-count` includes data sources (compare against `resources` entries).

**Branch 1 — metadata is sufficient** (entries expose `type` + `count` + a way to identify data sources, e.g. `mode` field or `data.` prefix): rewrite `extractStateVersionCount` to sum only billable entries: exclude data-source entries and types `null_resource`/`terraform_data`. Keep returning `null` when `resources-processed === false` (first check, unchanged) or when the array is absent — do NOT fall back to raw `resource-count` when a billable sum is computable.

**Branch 2 — metadata cannot identify data sources:** keep raw metadata counts BUT add a per-workspace correction: the job already can download the CURRENT state (existing `getCurrentStateVersion` + `downloadState` + `calculateRumFromState`); compute `ratio = billableRum / totalResources` from the current state once per workspace and multiply historical raw counts by it (round). Record `countMethod: "metadata-billable" | "metadata-adjusted" | "state-download"` per workspace in the record so the UI/export can disclose it. If a workspace has no current state, use ratio 1 and mark it.

Whichever branch: excluded-type filtering (`null_resource`, `terraform_data`) MUST happen when type info exists.

- [ ] Step 0 empirical check; paste the field list in the report
- [ ] Failing tests for the chosen branch (fixtures mirroring the real response shape you observed)
- [ ] Implement; tests green (`npm run test -w @rum-tool/api -- tfe-client` and `-- tfe-rum-history`)
- [ ] Commit `fix(api): billing-aware historical RUM counts (exclude data sources + excluded types)`

**Produces (for later tasks):** unchanged function signatures; if Branch 2, `RumHistoryRecord` gains optional per-workspace `countMethod` metadata.

---

## Task C: Trailing-12-months billable figure

**Files:**
- Modify: `packages/rum-engine/src/rum-history.ts` + `rum-history.test.ts`
- Modify: `apps/web/src/components/RumHistoryTab.tsx`, `apps/web/src/lib/api.ts`

Add to `RumHistoryResult`: `trailing12Average: number` — mean of the LAST up-to-12 full-coverage monthly peaks (fewer if fewer exist; 0 if none), `Math.round`ed like `annualAverage`. Pure engine change + tests: (a) >12 full months → only last 12 averaged; (b) exactly matches `annualAverage` when ≤12 full months exist; (c) empty → 0. UI: Billable tile shows BOTH figures — label `annualAverage` "All-history average" and `trailing12Average` "Trailing 12 months (billable run-rate)" with the trailing figure visually primary; Pack Sizing handoff payload unchanged (zeros rule per owner decision). api.ts DTO gains the field.

- [ ] Failing engine tests → implement → green (`npm run test -w @rum-tool/rum-engine`)
- [ ] DTO + UI tile update; `npm run build -w @rum-tool/web` clean (delete any `.js` artifacts under `apps/web/src/`, restore `tsconfig.tsbuildinfo` if touched)
- [ ] Commit `feat: trailing-12-month billable RUM figure (engine + proof view)`

**Produces:** `RumHistoryResult.trailing12Average: number` (engine + DTO).

---

## Task B: Shareable summary export + disclaimer + version stamp

**Files:**
- Modify: `apps/web/src/components/RumHistoryTab.tsx`
- Modify: `apps/api/src/server.ts` (only if reading version needs an endpoint — prefer frontend-only)

Add an "Export Summary (JSON)" button next to the existing CSV export, downloading `rum-history-summary-<org>-<date>.json` built client-side from the completed run: `{ organization, generatedAt, toolVersion, disclaimer, historyStart, historyEnd, fullMonths, annualAverage, trailing12Average, derivedAnnualGrowthPct, monthlyPeaks, workspacesFound, workspaceErrors, countMethodBreakdown? }`. NO credentials, NO hostname-internal details beyond org name. `toolVersion`: import version from root `package.json` via Vite (`import pkg from "../../package.json"` or define via `vite.config.ts`) — pick the idiomatic Vite way. `disclaimer` fixed string: `"Reconstruction estimate derived from Terraform state-version history. Not a quote or invoice figure."` Also render that same sentence as a small caption under the Billable tile.

- [ ] Implement; verify a downloaded file's shape manually via dev server (curl the record + replicate mapping in a node -e check is acceptable)
- [ ] `npm run build -w @rum-tool/web` clean (artifact hygiene as in Task C)
- [ ] Commit `feat(web): shareable RUM summary export with version stamp + estimate disclaimer`

---

## Task D: Docker Compose cold-start validation (independent)

**Files:**
- Modify only if broken: `docker-compose.yml`, `apps/*/Dockerfile*`, web API-base config

Simulate the customer: from a clean state, `docker compose build --no-cache && docker compose up -d`; verify web serves on :80, API on :8080, `POST /tfe/rum-history/runs` reachable from the web origin (CORS allows `http://localhost:80`), and the web bundle's API base points at the right place in the compose topology (check `VITE_API_BASE` handling — a customer opens `http://localhost` and the browser must reach the API at a host-reachable URL, not a docker-internal name). Fix what's broken, minimally. Tear down (`docker compose down`) after. Report exact commands a customer would run (3 lines max — goes in the Engineer Guide tab later, NOT a README).

- [ ] Build + up + verified end-to-end (a real `POST /tfe/rum-history/runs` 202 against app.terraform.io your test org (any org your token can read) using the local token — read it via jq, never echo)
- [ ] Fixes committed if needed: `fix(deploy): docker compose cold-start for self-serve customers` (or no commit if nothing broken — report that)

---

## Self-Review

Coverage: overcount fix → A; trailing-12 → C; export+disclaimer+version → B; compose validation → D; README intentionally EXCLUDED (owner decision); SE Guide rename already committed (6e12409). Types: `trailing12Average` named identically in engine/DTO/UI/export; `countMethod` optional and only if Branch 2. No placeholders; Task A's two branches are both fully specified with the empirical check deciding.

---

## Task E: customer-zip packaging script (after D)

**Files:** Create: `scripts/package_customer_zip.sh`; Modify: root `package.json` (add `"package:customer"` script).

One command producing a clean, customer-safe artifact: `git archive HEAD --format=zip -o dist/rum-assistant-customer.zip -- . ':!docs/superpowers' ':!.claude'` plus a post-build verification step that unzips to a temp dir and greps it for forbidden terms (`roadkill`, `stoffee`, `cdunlap`, `atlasv1`, `dunlap`) — script exits nonzero and deletes the zip on any hit. Print zip path + SHA256 on success.

- [ ] Script + npm alias; run it; verification grep clean on the produced zip
- [ ] Commit `feat(build): customer-safe zip packaging with leak check`

---

## Task F: daily workspace count + provider breakdowns (after C, before B)

**Files:** Modify: `packages/rum-engine/src/rum-history.ts` + tests; `apps/api/src/tfe-client.ts` (+tests, WIP stash protocol); `apps/api/src/tfe-rum-history-job.ts` (+tests); `apps/web/src/lib/api.ts`; `apps/web/src/components/RumHistoryTab.tsx`.

**Data:** extend `StateVersionEvent` with optional `byProvider?: Record<string, number>` (billable count per provider, same exclusion rules as Task A — derive in `extractStateVersionCount`'s sweep by returning `{ count, byProvider }` from a new sibling fn `extractStateVersionBreakdown` so the existing signature stays). Job populates it; accumulation/dedupe unchanged (payload rides the event).

**Engine:** `RumHistoryResult` gains `dailyWorkspaces: { date: string; count: number }[]` (workspaces with ≥1 event on-or-before that day — same sweep, no extra pass) and `dailyByProvider: { date: string; [provider: string]: number | string }[]` (carry-forward per workspace like the RUM step function, summed per provider; omit days identical to previous only if trivial — keep simple: one entry per day). Tests: workspace appears on first-event day and persists; provider sums carry forward and stack to the daily total when every event has byProvider; events WITHOUT byProvider (older accumulated data) contribute to total RUM but not to provider series — document this in a code comment and test it.

**UI:** second Y-axis or small separate chart for workspaces/day; stacked AreaChart for provider series (recharts); totals tiles: current workspaces, per-provider billable RUM (latest day), footnote "workspace deletions are not visible in state-version history". Task B's export gains `dailyWorkspaces` latest value, `providerTotals`.

- [ ] Engine tests RED→GREEN (`npm run test -w @rum-tool/rum-engine`)
- [ ] Client/job changes + tests green (`-- tfe-client`, `-- tfe-rum-history`)
- [ ] UI + build clean (artifact hygiene)
- [ ] Commit `feat: daily workspace + per-provider RUM breakdowns (engine, api, proof view)`

**Produces:** `RumHistoryResult.dailyWorkspaces`, `.dailyByProvider`; `StateVersionEvent.byProvider?`; UI totals. Order becomes: A → C → F → B → D → E.
