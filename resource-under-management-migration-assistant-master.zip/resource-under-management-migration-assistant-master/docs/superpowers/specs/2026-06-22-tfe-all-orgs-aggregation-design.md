# TFE Migration — All-Organizations Aggregation

**Date:** 2026-06-22
**Status:** Approved (design)
**Component:** `apps/api` (TFE migration domain) + `apps/web` (`TfeMigrationTab`)

## Problem

The TFE-to-TFC migration estimator scans one organization per run (`scopeLevel` is
`organization` or `project`). A user with many orgs must run the tool repeatedly and add
the RUM totals by hand. The web UI shows one run at a time, and `/metrics/combined-summary`
only reads the *latest* migration run, so multi-org totals are never aggregated anywhere.

We want a single run that scans multiple organizations concurrently and reports one
grand-total RUM plus a per-organization breakdown, viewable in the web page.

## Goals

- Scan multiple TFE/TFC organizations in one migration run.
- Produce a grand-total summary (RUM, workspaces, resources) across all scanned orgs,
  plus a per-org breakdown that drills down into per-workspace detail.
- Process each org **concurrently and independently** (async fan-out with a concurrency
  cap), so one slow or failing org never blocks the others.
- If an org fails, record the error, skip it, and still produce a grand total from the
  orgs that succeeded.

## Non-Goals

- True OS threads (`worker_threads`). The work is network I/O, not CPU; async concurrency
  is the correct and idiomatic tool. Explicitly out of scope.
- Cross-run aggregation in the UI (Approach B). Aggregation happens server-side in one
  record.
- Persisting multi-org migration records across server restart (the TFE store is
  in-memory today; unchanged here).

## Critical Constraint — No Embedded User Data

This is a presales tool for **any** customer. The organization list MUST always be
discovered at runtime from the supplied token. **No org names, emails, or account
identifiers may be hardcoded, defaulted, or committed anywhere** in code, config, tests,
or fixtures. Tests use synthetic/placeholder org names only.

## Approach

Approach A — add an `all-organizations` scope to the existing TFE migration job. The job
discovers/accepts a list of org names, fans them out concurrently, scans each with the
existing per-org workspace logic, and writes a single record holding a grand-total summary
plus a `byOrganization[]` breakdown. (Approaches B "frontend run-loop" and C "hybrid
orchestration endpoint" were rejected — they leave the grand total client-side and don't
feed the combined-summary dashboard.)

## Data Flow

```
UI: select scope "All organizations"
  └─ POST /tfe/organizations {tfeHostname, tfeToken, tlsInsecure}
        → [{ name, workspaceCount }]   (orgs the token can see)
  └─ user ticks orgs to include (all checked by default; select all/none toggle)
  └─ POST /tfe/migration/runs
        { scopeLevel:"all-organizations", organizations:[...], orgConcurrency?, concurrency? }
        → 202 { id, status:"queued" }
  └─ runTfeMigrationJob(id, request):
        fan out orgs through a bounded worker pool (orgConcurrency)
          each org task (isolated, own try/catch):
            list workspaces → download states → rum-engine → per-org summary
        aggregate successful orgs → grand-total summary + byOrganization[]
        update record → status "completed"
  └─ UI polls GET /tfe/migration/runs/:id until status completed/failed
        renders grand-total cards + per-org table (expand → that org's workspaces)
```

## Data Model (`apps/api/src/tfe-types.ts`)

Extend the scope type:

```ts
export type TfeScopeLevel = "organization" | "project" | "all-organizations";
```

Extend the request:

```ts
export type TfeMigrationRequest = {
  tfeHostname: string;
  tfeToken: string;
  organization?: string;         // required for "organization"/"project" scope;
                                  // ignored for "all-organizations" (see schema refinement)
  organizations?: string[];      // explicit org list for all-organizations scope
  scopeLevel?: TfeScopeLevel;
  projectId?: string;
  projectName?: string;
  workspaceFilter?: string;
  tlsInsecure?: boolean;
  concurrency?: number;          // per-workspace concurrency (existing)
  orgConcurrency?: number;       // NEW: per-org concurrency, default 4, max 10
};
```

New per-org result type (reuses the existing summary shape):

```ts
export type TfeOrganizationResult = {
  organization: string;
  status: "completed" | "error";
  error?: string;
  summary?: TfeMigrationSummary;          // undefined when status === "error"
  workspaces?: TfeWorkspaceResult[];      // that org's workspaces (for drill-down)
};
```

Extend the record:

```ts
export type TfeMigrationRecord = {
  // ...existing fields...
  byOrganization?: TfeOrganizationResult[];   // NEW: present for all-organizations scope
  progress?: {
    phase: "connecting" | "listing_workspaces" | "downloading_states"
         | "calculating" | "scanning_organizations";   // NEW phase
    workspacesFound?: number;
    workspacesProcessed?: number;
    orgsTotal?: number;          // NEW
    orgsProcessed?: number;      // NEW
  };
};
```

For all-organizations scope, the top-level `summary` (and `workspaces`) hold the **grand
total** — the sum across successful orgs — so existing summary cards and
`/metrics/combined-summary` work unchanged. `byOrganization[]` holds the breakdown.

## API Changes

### `apps/api/src/tfe-client.ts`

Add `listOrganizations`, mirroring `listProjects` (paginated `GET /api/v2/organizations`,
`page[size]=100`, follow `meta.pagination.next-page`):

```ts
export type TfeOrganization = {
  id: string;  // org name is the id in the v2 API
  attributes: { name: string; email?: string; "workspace-count"?: number };
};

export async function listOrganizations(
  options: TfeClientOptions
): Promise<TfeOrganization[]>;
```

### `apps/api/src/server.ts`

New endpoint (mirrors `/tfe/projects`), validated by the existing `tfeConnectionSchema`:

```
POST /tfe/organizations
  body: { tfeHostname, tfeToken, organization?, tlsInsecure? }
  200:  { organizations: [{ name, workspaceCount }] }
  502:  { error } on auth/connection failure
```

> Note: `tfeConnectionSchema` requires `organization`. For the org-discovery call the org
> is irrelevant, so relax `organization` to optional **for this endpoint only** via a
> dedicated `tfeOrgListSchema = tfeConnectionSchema.partial({ organization: true })`
> (or a purpose-built schema). The migration schema keeps `organization` required.

Extend `tfeMigrationRequestSchema`:

- Add `"all-organizations"` to the `scopeLevel` enum.
- Add `organizations: z.array(z.string().min(1)).optional()`.
- Add `orgConcurrency: z.number().int().positive().max(10).optional()`.
- Make `organization` optional at the schema level; enforce via refinement:
  - `scopeLevel` `organization`/`project` (or omitted) → `organization` required.
  - `scopeLevel === "all-organizations"` → `organizations` required (non-empty array);
    `organization` ignored. (The UI always sends the explicit, user-selected list. We do
    **not** silently auto-discover-and-scan-everything from the server, to avoid surprise
    scans.)

Credential redaction: unchanged — token already redacted before storage; the new
`organizations` array contains no secrets.

### `apps/api/src/tfe-job.ts`

- Refactor the current single-org scan body into a reusable
  `scanOrganization(clientOptions, orgName, request): Promise<TfeOrganizationResult>`
  that returns a per-org result (wrapping list-workspaces → `processWorkspaceBatch` →
  `buildSummary`). It catches its own errors and returns `{ status:"error", error }`.
- `runTfeMigrationJob` branches on `scopeLevel`:
  - `organization` / `project` → existing path (call `scanOrganization` once; keep
    current top-level `summary`/`byProject`/`workspaces` behavior).
  - `all-organizations` → fan out `request.organizations` through a **bounded worker
    pool** reusing the same queue+N-workers pattern as `processWorkspaceBatch`, with
    `orgConcurrency` (default 4) workers. Collect `TfeOrganizationResult[]`.
- Aggregate: `buildGrandTotal(byOrganization)` sums the `summary` fields of orgs with
  `status === "completed"` into a `TfeMigrationSummary`; concatenate their `workspaces`
  into the top-level `workspaces`. Write `byOrganization`, `summary`, `workspaces`.
- Progress: update `orgsProcessed`/`orgsTotal` as each org task finishes (phase
  `scanning_organizations`).

## UI Changes (`apps/web/src/components/TfeMigrationTab.tsx` + `lib/api.ts`)

- `lib/api.ts`: add `listTfeOrganizations(conn)` → `POST /tfe/organizations`; extend the
  migration-run request type with `organizations` and `orgConcurrency`.
- Scope selector: add a third radio **All organizations** beside Organization / Project.
- On selecting it (and on valid connection): call `listTfeOrganizations`, render a
  checkbox list of returned orgs (all checked by default) with a **Select all / none**
  toggle and a live "N of M selected" count. Show a loading and an error state, matching
  the existing project-picker UX.
- Submit: send `scopeLevel:"all-organizations"`, `organizations: <checked names>`.
- Results:
  - Reuse the existing grand-total summary cards (driven by top-level `summary`).
  - New **per-org table**: columns `Organization · Billable RUM · Workspaces ·
    Total Resources · Status`. Errored orgs show a red status with the error in a tooltip.
    Rows expand to that org's workspace rows (reuse the existing workspace table/row
    rendering, scoped to `org.workspaces`).
  - While running, show "Scanning organizations — {orgsProcessed}/{orgsTotal}".

## Error Handling

- Per-org `try/catch` inside `scanOrganization`; failures become
  `{ status:"error", error }` in `byOrganization`. Grand total sums successes only.
- A run only ends in `status:"failed"` if the job throws *outside* the per-org tasks
  (e.g., the initial connection validation fails). Individual org errors keep the run
  `completed` with partial results.
- `/tfe/organizations` returns `502 { error }` on auth/connection failure, same as
  `/tfe/projects`.
- Token redacted in the stored record; never returned in any response.

## Testing

- **Unit (`tfe-client.test.ts`):** `listOrganizations` pagination (single page, multi-page
  via `next-page`). Synthetic org names only.
- **Unit (job/aggregation):** `buildGrandTotal` sums only `completed` orgs; a mix of
  completed + errored orgs yields the correct grand total and preserves error entries.
- **Unit (schema):** `tfeMigrationRequestSchema` accepts `all-organizations` +
  non-empty `organizations`; rejects `all-organizations` with empty/missing
  `organizations`; `orgConcurrency` bounds (1..10) enforced.
- **Integration:** extend existing `tfe-store.test.ts` patterns for a record carrying
  `byOrganization`.
- **Manual acceptance:** run an all-orgs sweep against a real token, confirm grand total =
  sum of per-org RUM and per-org drill-down matches single-org runs. (No org names
  committed; this is a local manual check only.)

## Rollout / Compatibility

- Additive only: new optional fields, new scope value, new endpoint. Existing
  single-org/project runs and stored records are unaffected (`byOrganization` is optional).
- No migration of persisted data required (TFE store is in-memory).

## Open Items

- None blocking. Default `orgConcurrency = 4`, max `10` (tunable later if rate limits
  warrant; TFE API 429s are already handled with retry-after in `tfeApiFetch`).
