# Design: TFE/TFC RUM History Reconstruction

**Date:** 2026-07-01
**Status:** Approved (design), pending implementation plan
**Author:** Chris Dunlap + Claude

## Problem

The RUM billed to a customer on HCP Terraform / TFE is not a point-in-time count. It aggregates as a three-tier high-water mark:

1. **Day** = the high-water mark (peak concurrent managed resources) during that day. Everything sub-daily is discarded.
2. **Month** = the high-water mark across the days of that month (the single biggest day).
3. **Year / billed amount** = the **average of the monthly high-water marks** — this is what the customer actually pays on.

Because per-hour granularity is *below* the billing resolution, daily peak is the correct atomic unit to model. Collecting anything finer is wasted precision.

Today the tool only computes a **point-in-time** RUM (single snapshot count via `tfe-client.getCurrentStateVersion` + the managed scan engine). The **Pack Sizing** tab already does forward projection (12/36-month chart, growth rate, `recommendPack()`), but its inputs are **manual guesses**:

- `peakMultiplier` — default `1.0`, typed by hand (SE guesses peak-vs-snapshot uplift)
- `monthlyValues` — `Array(12).fill(0)`, SE types 12 numbers
- `growthBufferPct` / `forecastGrowthPct` — manual (25% / 20% defaults)

There is no ground truth behind the forecast, and no way to show a customer the proof behind a RUM number.

## Goal

Reconstruct a customer's **real** historical daily-peak RUM curve from data TFE/TFC already holds (state versions), so the tool can:

1. **Prove** today's billable number — show the daily RUM series and the day→month→year math, auditable end to end.
2. **Predict** RUM + growth — trend the real historical curve forward (configurable 1–5 year horizon).
3. **Feed migration sizing** — hand real numbers to the existing Pack Sizing forecast.

## Scope

**In scope:** the TFE/TFC data-getting path — reconstruction engine, the daily-peak proof surfaces, and a clean opt-in handoff into Pack Sizing.

**Explicitly out of scope:** we do **not** modify Pack Sizing's manual input machinery or the unmanaged/managed `getSummary` paths. Those flows (unmanaged estimator, greenfield/net-new customers with no TFE history) legitimately need the manual guess inputs. This feature is **additive** — one more input *source*, not a replacement.

Multi-organization aggregation is **not** in scope (most customers run one org; the earlier all-orgs design is shelved).

## Architecture

### 1. Additive input source (framing)

Pack Sizing remains a shared consumer with multiple input sources. We add one:

```
Pack Sizing inputs  ←  manual entry (SE guesses)          [unchanged]
                    ←  getSummary (managed/unmanaged)      [unchanged]
                    ←  NEW: "Prefill from TFE/TFC history"  ← this feature
```

When a TFE/TFC connection exists, the SE can opt to load reconstructed real monthly peaks / annual average / derived growth into Pack Sizing for that session. When no connection exists, manual inputs behave exactly as today. No existing flow breaks.

### 2. Backend reconstruction job

Follows the existing fire-and-forget pattern (`POST → 202 → poll GET`, in-memory `Map` + JSON persistence, Zod validation, TFE token single-use and redacted before storage).

- `POST /tfe/rum-history` with org name + credentials → `202` + record id
- Client polls `GET /tfe/rum-history/:id` until status `completed` / `failed`
- Job steps:
  1. `listAllWorkspaces(org)` — existing `tfe-client` call
  2. For each workspace, **list all state versions** — NEW `tfe-client` call (paginated; only `getCurrentStateVersion` exists today)
  3. Read the resource count from each state version's metadata (`resources` extract). Download-and-count via existing `downloadState` **only** when `resources-processed` is `false`
  4. Emit `{ workspaceId, createdAt, count }` events into the reconstruction engine
- New files follow the API domain pattern: `tfe-rum-history-types.ts`, `tfe-rum-history-store.ts`, `tfe-rum-history-job.ts`, plus routes + Zod schema in `server.ts`

### 3. Reconstruction engine (the heart)

Pure, zero-dependency, testable — lives in `packages/rum-engine` alongside the existing engine.

```
per workspace:
  sort state-version events by createdAt → step function
  (a workspace's count holds constant until its next apply)

merge all workspaces onto a shared daily timeline:
  daily total RUM(d) = Σ over workspaces of (that workspace's count as-of day d)

daily high-water mark  → monthly high-water mark  → annual average
```

This module is the auditable "math" surface — every displayed number derives from it and is unit-tested against fixtures.

### 4. Backward (actual) + forward (forecast)

- **Backward — reconstruct all available.** Walk back as far as state-version retention allows. Months with full coverage are solid; thin/partial/missing months are **flagged**, never fabricated.
- **Forward — reuse existing Pack Sizing projection.** Feed real monthly peaks in; default forward growth = a **CAGR derived from the reconstructed monthly high-water marks** (first vs last fully-covered month, annualized), expressed as an annual growth % so it plugs directly into Pack Sizing's existing compounded forecast input (`(1 + pct)^(1/12)`). SE-overridable. Horizon **configurable 1–5 years** (default 3), extending the current 12/36-month toggle. The projected line is drawn distinctly from actuals.
- **Accumulate over time.** Each run appends to the persisted history record, so real ground-truth deepens the longer the tool is used against an org — even customers with thin retention today build a multi-year record going forward.

### 5. Output / proof surfaces (TFE/TFC path only)

- **Daily-peak line chart** (recharts — already a dependency) = the proof
- **Monthly-peak table** with per-month coverage flags
- **Billable total** with the day→month→year arithmetic shown inline
- **CSV export** (matches existing export pattern)
- **"Load into Pack Sizing"** handoff → prefills its inputs and drives `recommendPack()`

## Data source feasibility (verified)

TFE/TFC State Versions API confirms the cheap path:

- The state-versions **list** endpoint returns per-version `resources` extract + `created-at` **without** downloading the state file, plus a `resources-processed` boolean indicating extraction is complete.
- Endpoint is paginated (`page[number]`, `page[size]`); filterable by workspace/org. No server-side date filter, but `created-at` on each version lets us window client-side.
- Full state download (existing `downloadState`) is the fallback only for unprocessed versions.

## Error handling & constraints

- **Token security:** TFE token passed to the job from the original request, never persisted, redacted in any stored record (existing `redactSensitiveXxxFields` pattern).
- **Retention gaps:** partial/missing months flagged in output; no fabrication.
- **Async extraction lag:** `resources-processed === false` → fall back to download+count for that version.
- **Large orgs:** counts read from metadata (not state downloads) keep the walk cheap; pagination bounded per workspace.
- **Empty/no history:** job completes with an explicit "insufficient history" state; SE falls back to manual Pack Sizing inputs.

## Testing

- **rum-engine unit tests:** step-function merge, daily/monthly high-water marks, annual average, partial-month flagging — against synthetic state-version event fixtures with known expected curves.
- **tfe-client unit tests:** state-version listing + pagination + metadata count extraction (extend existing `tfe-client.test.ts`).
- **Job/store tests:** record lifecycle, redaction, accumulation/append behavior.

## Out of scope / YAGNI

- Multi-organization aggregation (shelved).
- Modifying manual Pack Sizing inputs or the unmanaged/managed paths.
- Sub-daily (hourly) resolution — below billing resolution.
- Fabricating months with no retained history.
