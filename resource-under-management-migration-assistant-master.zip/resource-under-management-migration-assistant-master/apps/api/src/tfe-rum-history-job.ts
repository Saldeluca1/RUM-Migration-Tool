import { calculateRumFromState, parseTerraformState, reconstructRumHistory } from "@rum-tool/rum-engine";
import type { StateVersionEvent } from "@rum-tool/rum-engine";
import {
  listAllWorkspaces,
  listStateVersions,
  extractStateVersionBreakdown,
  providerFromType,
  downloadState
} from "./tfe-client.js";
import type { TfeClientOptions, TfeHistoricalStateVersion } from "./tfe-client.js";
import type { RumHistoryRequest } from "./tfe-rum-history-types.js";
import { updateRumHistoryRun, getPriorEventsForOrg } from "./tfe-rum-history-store.js";
import { logger } from "./logger.js";

type CountBreakdown = { count: number; byProvider?: Record<string, number> };

/**
 * Derives a state version's billable count and (when cheaply available) its
 * per-provider breakdown.
 *
 * Preference order:
 *  1. extractStateVersionBreakdown(sv) — the metadata sweep; when it returns
 *     non-null it already carries byProvider.
 *  2. Download-fallback: parse the raw state and run calculateRumFromState.
 *     Its evaluations carry each counted resource's `type`, so byProvider is
 *     derived the same type-prefix way as extractStateVersionBreakdown — it
 *     is not skipped just because we're on the fallback path.
 */
async function deriveBreakdown(
  clientOptions: TfeClientOptions,
  sv: TfeHistoricalStateVersion
): Promise<CountBreakdown | null> {
  const breakdown = extractStateVersionBreakdown(sv);
  if (breakdown !== null) return breakdown;

  const downloadUrl = sv.attributes["hosted-state-download-url"];
  if (!downloadUrl) return null;

  const rawState = await downloadState(clientOptions, downloadUrl);
  const state = parseTerraformState(rawState);
  const result = calculateRumFromState(state);

  const byProvider: Record<string, number> = {};
  for (const evaluation of result.evaluations) {
    if (!evaluation.counted) continue;
    const provider = providerFromType(evaluation.type);
    byProvider[provider] = (byProvider[provider] ?? 0) + evaluation.rum;
  }

  return { count: result.totalRum, byProvider };
}

export async function runRumHistoryJob(
  runId: string,
  request: RumHistoryRequest
): Promise<void> {
  const clientOptions: TfeClientOptions = {
    hostname: request.tfeHostname.replace(/\/+$/, ""),
    token: request.tfeToken,
    tlsInsecure: request.tlsInsecure
  };

  try {
    // Phase 1: Mark as running
    updateRumHistoryRun(runId, (current) => ({
      ...current,
      status: "running",
      progress: { phase: "connecting" }
    }));

    // Phase 2: List workspaces
    updateRumHistoryRun(runId, (current) => ({
      ...current,
      progress: { phase: "listing_workspaces" }
    }));

    const workspaces = await listAllWorkspaces(
      clientOptions,
      request.organization,
      { nameFilter: request.workspaceFilter }
    );

    updateRumHistoryRun(runId, (current) => ({
      ...current,
      progress: {
        phase: "listing_versions",
        workspacesFound: workspaces.length,
        workspacesProcessed: 0,
        workspaceErrors: 0
      }
    }));

    // Phase 3: List state versions per workspace and derive counts
    const freshEvents: StateVersionEvent[] = [];
    let workspacesProcessed = 0;
    let workspaceErrors = 0;

    for (const workspace of workspaces) {
      try {
        const versions = await listStateVersions(
          clientOptions,
          request.organization,
          workspace.attributes.name
        );

        for (const sv of versions) {
          const breakdown = await deriveBreakdown(clientOptions, sv);
          if (breakdown === null) continue;

          freshEvents.push({
            workspaceId: workspace.id,
            createdAt: sv.attributes["created-at"],
            count: breakdown.count,
            ...(breakdown.byProvider ? { byProvider: breakdown.byProvider } : {})
          });
        }
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        workspaceErrors += 1;
        logger.warn(
          { runId, workspace: workspace.attributes.name, err: message },
          "Skipping workspace in RUM history reconstruction"
        );
      }

      workspacesProcessed += 1;
      updateRumHistoryRun(runId, (current) => ({
        ...current,
        progress: {
          phase: "listing_versions",
          workspacesFound: workspaces.length,
          workspacesProcessed,
          workspaceErrors
        }
      }));
    }

    // Phase 4: Union with prior events for the org, deduping by workspaceId+createdAt (fresh wins)
    updateRumHistoryRun(runId, (current) => ({
      ...current,
      progress: { ...current.progress, phase: "reconstructing" }
    }));

    const priorEvents = getPriorEventsForOrg(clientOptions.hostname, request.organization);
    const dedupedByKey = new Map<string, StateVersionEvent>();
    for (const ev of priorEvents) {
      dedupedByKey.set(`${ev.workspaceId}|${ev.createdAt}`, ev);
    }
    for (const ev of freshEvents) {
      dedupedByKey.set(`${ev.workspaceId}|${ev.createdAt}`, ev);
    }
    const events = [...dedupedByKey.values()];

    const result = reconstructRumHistory(events, new Date().toISOString().slice(0, 10));

    // Phase 5: Persist and complete
    updateRumHistoryRun(runId, (current) => ({
      ...current,
      status: "completed",
      events,
      result
    }));

    logger.info(
      { runId, workspaces: workspaces.length, events: events.length },
      "RUM history reconstruction completed"
    );
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    logger.error({ runId, err: message }, "RUM history reconstruction failed");

    updateRumHistoryRun(runId, (current) => ({
      ...current,
      status: "failed",
      errorMessage: message
    }));
  }
}
