import { describe, it, expect, vi, beforeEach } from "vitest";

vi.mock("./tfe-client.js", () => ({
  listAllWorkspaces: vi.fn(async () => [{ id: "ws-1", attributes: { name: "prod" } }]),
  listStateVersions: vi.fn(async () => [
    { id: "sv-1", attributes: { serial: 1, "created-at": "2026-01-10T00:00:00Z", "resource-count": 100 } },
    { id: "sv-2", attributes: { serial: 2, "created-at": "2026-02-10T00:00:00Z", "resource-count": 200 } },
  ]),
  extractStateVersionBreakdown: (sv: any) => {
    const count = sv.attributes["resource-count"] ?? null;
    if (count === null) return null;
    return { count, byProvider: { aws: count } };
  },
  providerFromType: (type: string) => (type.includes("_") ? type.split("_")[0] : type),
  downloadState: vi.fn(),
}));

vi.mock("./tfe-rum-history-store.js", () => ({
  getPriorEventsForOrg: vi.fn(() => []),
  updateRumHistoryRun: vi.fn(),
}));

import { runRumHistoryJob } from "./tfe-rum-history-job.js";
import { getPriorEventsForOrg, updateRumHistoryRun } from "./tfe-rum-history-store.js";
import { listAllWorkspaces, listStateVersions } from "./tfe-client.js";
import type { RumHistoryRecord } from "./tfe-rum-history-types.js";

const baseRequest = { tfeHostname: "https://tfe.x", tfeToken: "t", organization: "acme" };

function makeRecord(overrides: Partial<RumHistoryRecord> = {}): RumHistoryRecord {
  return {
    id: "run-1",
    status: "queued",
    createdAt: "2026-01-01T00:00:00Z",
    updatedAt: "2026-01-01T00:00:00Z",
    request: { ...baseRequest, tfeToken: "***redacted***" },
    ...overrides
  };
}

/**
 * Simulates the store's updateRumHistoryRun: applies each updater function in
 * sequence to a mutable fake record, mirroring how the real store folds updates.
 */
function trackUpdates(initial: RumHistoryRecord) {
  let record = initial;
  (updateRumHistoryRun as any).mockImplementation((_id: string, updater: (current: RumHistoryRecord) => RumHistoryRecord) => {
    record = updater(record);
    return record;
  });
  return {
    get current() {
      return record;
    }
  };
}

describe("runRumHistoryJob", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    (listAllWorkspaces as any).mockResolvedValue([{ id: "ws-1", attributes: { name: "prod" } }]);
    (listStateVersions as any).mockResolvedValue([
      { id: "sv-1", attributes: { serial: 1, "created-at": "2026-01-10T00:00:00Z", "resource-count": 100 } },
      { id: "sv-2", attributes: { serial: 2, "created-at": "2026-02-10T00:00:00Z", "resource-count": 200 } },
    ]);
    (getPriorEventsForOrg as any).mockReturnValue([]);
  });

  it("reconstructs and completes", async () => {
    const tracker = trackUpdates(makeRecord());
    await runRumHistoryJob("run-1", baseRequest);
    const done = tracker.current;
    expect(done.status).toBe("completed");
    expect(done.result?.monthlyPeaks.length).toBeGreaterThan(0);
    expect(done.events?.length).toBe(2);
  });

  it("populates byProvider on fresh events from extractStateVersionBreakdown", async () => {
    const tracker = trackUpdates(makeRecord());
    await runRumHistoryJob("run-1", baseRequest);
    const done = tracker.current;
    const events = done.events ?? [];
    expect(events.find((e) => e.count === 100)?.byProvider).toEqual({ aws: 100 });
    expect(events.find((e) => e.count === 200)?.byProvider).toEqual({ aws: 200 });
  });

  it("overwrites colliding prior events with fresh counts and keeps non-colliding ones", async () => {
    (getPriorEventsForOrg as any).mockReturnValue([
      // Collides with sv-1 (same workspaceId + createdAt) — stale count should be overwritten.
      { workspaceId: "ws-1", createdAt: "2026-01-10T00:00:00Z", count: 999 },
      // Non-colliding — should survive into final events.
      { workspaceId: "ws-1", createdAt: "2025-12-01T00:00:00Z", count: 42 },
    ]);

    const tracker = trackUpdates(makeRecord());
    await runRumHistoryJob("run-1", baseRequest);
    const done = tracker.current;

    expect(done.status).toBe("completed");
    const events = done.events ?? [];

    const collided = events.find(
      (e) => e.workspaceId === "ws-1" && e.createdAt === "2026-01-10T00:00:00Z"
    );
    expect(collided?.count).toBe(100); // fresh wins over stale 999

    const survivor = events.find(
      (e) => e.workspaceId === "ws-1" && e.createdAt === "2025-12-01T00:00:00Z"
    );
    expect(survivor?.count).toBe(42);
  });

  it("isolates a failing workspace and still completes with the healthy workspace's events", async () => {
    (listAllWorkspaces as any).mockResolvedValue([
      { id: "ws-bad", attributes: { name: "broken" } },
      { id: "ws-good", attributes: { name: "healthy" } },
    ]);
    (listStateVersions as any).mockImplementation(async (_opts: any, _org: string, wsName: string) => {
      if (wsName === "broken") {
        throw new Error("rate limited");
      }
      return [
        { id: "sv-1", attributes: { serial: 1, "created-at": "2026-01-10T00:00:00Z", "resource-count": 50 } },
      ];
    });

    const tracker = trackUpdates(makeRecord());
    await runRumHistoryJob("run-1", baseRequest);
    const done = tracker.current;

    expect(done.status).toBe("completed");
    expect(done.events?.length).toBe(1);
    expect(done.events?.[0]?.workspaceId).toBe("ws-good");

    // The final record (not a replayed intermediate update) must still carry
    // the isolated failure count — proves later updates don't wipe it.
    expect(done.progress?.workspaceErrors).toBe(1);
  });

  it("fails the run when listAllWorkspaces throws", async () => {
    (listAllWorkspaces as any).mockRejectedValue(new Error("auth failure"));

    const tracker = trackUpdates(makeRecord());
    await runRumHistoryJob("run-1", baseRequest);
    const done = tracker.current;

    expect(done.status).toBe("failed");
    expect(done.errorMessage).toBe("auth failure");
  });
});
