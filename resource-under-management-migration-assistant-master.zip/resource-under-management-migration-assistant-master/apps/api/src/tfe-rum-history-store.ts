import { randomUUID } from "node:crypto";
import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";
import type { StateVersionEvent } from "@rum-tool/rum-engine";
import type { RumHistoryRecord, RumHistoryRequest } from "./tfe-rum-history-types.js";
import { atomicWriteFileSync } from "./atomic-write.js";
import { logger } from "./logger.js";

const runs = new Map<string, RumHistoryRecord>();
const STORE_PATH = join(process.cwd(), "data", "tfe-rum-history.json");

type PersistedRumHistoryStore = {
  version: number;
  runs: RumHistoryRecord[];
};

function persistRuns(): void {
  const payload: PersistedRumHistoryStore = {
    version: 1,
    runs: [...runs.values()]
  };
  atomicWriteFileSync(STORE_PATH, JSON.stringify(payload, null, 2));
}

function loadRunsFromDisk(): void {
  if (!existsSync(STORE_PATH)) return;
  try {
    const raw = readFileSync(STORE_PATH, "utf-8");
    const parsed = JSON.parse(raw) as PersistedRumHistoryStore;
    for (const run of parsed.runs ?? []) {
      runs.set(run.id, run);
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    logger.error({ err: message, path: STORE_PATH }, "Failed to load RUM history runs");
  }
}

loadRunsFromDisk();

export function redactRumHistoryRequest(
  request: RumHistoryRequest
): RumHistoryRecord["request"] {
  return {
    ...request,
    tfeToken: request.tfeToken ? "***redacted***" : ""
  };
}

export function createRumHistoryRun(
  request: RumHistoryRequest
): RumHistoryRecord {
  const now = new Date().toISOString();
  const id = randomUUID();
  const record: RumHistoryRecord = {
    id,
    status: "queued",
    createdAt: now,
    updatedAt: now,
    request: redactRumHistoryRequest(request)
  };
  runs.set(id, record);
  persistRuns();
  return record;
}

export function updateRumHistoryRun(
  id: string,
  updater: (current: RumHistoryRecord) => RumHistoryRecord
): RumHistoryRecord | null {
  const existing = runs.get(id);
  if (!existing) return null;
  const updated = updater(existing);
  runs.set(id, { ...updated, updatedAt: new Date().toISOString() });
  persistRuns();
  return runs.get(id) ?? null;
}

export function getRumHistoryRun(id: string): RumHistoryRecord | null {
  return runs.get(id) ?? null;
}

export function listRumHistoryRuns(): RumHistoryRecord[] {
  return [...runs.values()].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export function getPriorEventsForOrg(hostname: string, organization: string): StateVersionEvent[] {
  const matches = [...runs.values()]
    .filter((r) => r.status === "completed" && r.request.tfeHostname === hostname && r.request.organization === organization)
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  return matches[0]?.events ?? [];
}
