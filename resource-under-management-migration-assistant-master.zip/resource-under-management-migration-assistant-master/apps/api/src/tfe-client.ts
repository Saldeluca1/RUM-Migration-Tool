import https from "node:https";

export type TfeClientOptions = {
  hostname: string;
  token: string;
  tlsInsecure?: boolean;
};

export type TfeProject = {
  id: string;
  attributes: {
    name: string;
    description?: string;
    "workspace-count"?: number;
  };
};

export type TfeWorkspace = {
  id: string;
  attributes: {
    name: string;
    "terraform-version"?: string;
    "resource-count"?: number;
    "updated-at"?: string;
  };
  relationships?: {
    project?: {
      data?: { id: string; type: string };
    };
  };
};

export type TfeStateVersion = {
  id: string;
  attributes: {
    serial: number;
    "hosted-state-download-url": string;
    "created-at": string;
  };
};

/**
 * Shape of an entry in attributes.resources on a TFC/TFE state-version
 * response. Observed empirically (a live TFC organization,
 * 2026-07-01): no "mode" field is present, but data source entries are
 * identifiable via a "data." prefix on "type" (e.g. "data.vault_kv_secret_v2").
 */
export type TfeStateVersionResourceSummary = {
  type?: string;
  count?: number;
  name?: string;
  module?: string;
  provider?: string;
  "index-keys"?: string[];
};

export type TfeHistoricalStateVersion = {
  id: string;
  attributes: {
    serial: number;
    "created-at": string;
    "resources-processed"?: boolean;
    /** Legacy/raw count. Includes data sources — never used as a billable count. */
    "resource-count"?: number;
    /** TFC-computed billable RUM count for this state version, when available. */
    "billable-rum-count"?: number;
    resources?: TfeStateVersionResourceSummary[];
    "hosted-state-download-url"?: string;
  };
};

type TfeApiResponse<T> = {
  data: T;
  meta?: {
    pagination?: {
      "current-page": number;
      "next-page": number | null;
      "total-pages": number;
      "total-count": number;
    };
  };
};

function buildAgent(tlsInsecure?: boolean): https.Agent | undefined {
  if (tlsInsecure) {
    return new https.Agent({ rejectUnauthorized: false });
  }
  return undefined;
}

async function tfeApiFetch<T>(
  url: string,
  token: string,
  tlsInsecure?: boolean
): Promise<T> {
  const agent = buildAgent(tlsInsecure);
  const fetchOptions: RequestInit & { dispatcher?: unknown } = {
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/vnd.api+json"
    }
  };

  // Node 18+ uses the undici agent for fetch; for https.Agent we need a workaround.
  // We use the global agent approach for self-signed cert support.
  if (agent) {
    (fetchOptions as Record<string, unknown>).dispatcher = agent;
  }

  const response = await fetch(url, fetchOptions);

  if (response.status === 429) {
    const retryAfter = response.headers.get("retry-after");
    const delayMs = retryAfter ? Number(retryAfter) * 1000 : 5000;
    await new Promise((resolve) => setTimeout(resolve, delayMs));
    return tfeApiFetch<T>(url, token, tlsInsecure);
  }

  if (!response.ok) {
    const body = await response.text().catch(() => "");
    throw new Error(`TFE API ${response.status}: ${response.statusText} — ${body}`);
  }

  return response.json() as Promise<T>;
}

export async function validateConnection(options: TfeClientOptions): Promise<{
  orgName: string;
  email?: string;
}> {
  const url = `${options.hostname}/api/v2/organizations/${encodeURIComponent("__ping__")}`;

  // We actually validate by hitting the org endpoint
  const orgUrl = `${options.hostname}/api/v2/ping`;
  const response = await fetch(orgUrl, {
    headers: { Authorization: `Bearer ${options.token}` }
  });

  if (!response.ok) {
    throw new Error(`Connection failed: ${response.status} ${response.statusText}`);
  }

  return { orgName: "validated" };
}

export async function getOrganization(
  options: TfeClientOptions,
  orgName: string
): Promise<{ name: string; email?: string }> {
  type OrgData = { id: string; attributes: { name: string; email?: string } };
  const result = await tfeApiFetch<TfeApiResponse<OrgData>>(
    `${options.hostname}/api/v2/organizations/${encodeURIComponent(orgName)}`,
    options.token,
    options.tlsInsecure
  );
  return {
    name: result.data.attributes.name,
    email: result.data.attributes.email
  };
}

export async function listProjects(
  options: TfeClientOptions,
  orgName: string
): Promise<TfeProject[]> {
  const projects: TfeProject[] = [];
  let page = 1;
  const pageSize = 100;

  // eslint-disable-next-line no-constant-condition
  while (true) {
    const url = `${options.hostname}/api/v2/organizations/${encodeURIComponent(orgName)}/projects?page[size]=${pageSize}&page[number]=${page}`;
    const result = await tfeApiFetch<TfeApiResponse<TfeProject[]>>(
      url,
      options.token,
      options.tlsInsecure
    );

    projects.push(...result.data);

    const nextPage = result.meta?.pagination?.["next-page"];
    if (!nextPage) break;
    page = nextPage;
  }

  return projects;
}

export type ListWorkspacesOptions = {
  nameFilter?: string;
  projectId?: string;
};

export async function listAllWorkspaces(
  options: TfeClientOptions,
  orgName: string,
  filterOptions?: ListWorkspacesOptions | string
): Promise<TfeWorkspace[]> {
  // Backward compat: if filterOptions is a string, treat as nameFilter
  const opts: ListWorkspacesOptions =
    typeof filterOptions === "string" ? { nameFilter: filterOptions } : (filterOptions ?? {});

  const workspaces: TfeWorkspace[] = [];
  let page = 1;
  const pageSize = 100;

  // eslint-disable-next-line no-constant-condition
  while (true) {
    let url = `${options.hostname}/api/v2/organizations/${encodeURIComponent(orgName)}/workspaces?page[size]=${pageSize}&page[number]=${page}`;
    if (opts.nameFilter) {
      url += `&search[name]=${encodeURIComponent(opts.nameFilter)}`;
    }
    if (opts.projectId) {
      url += `&filter[project][id]=${encodeURIComponent(opts.projectId)}`;
    }

    const result = await tfeApiFetch<TfeApiResponse<TfeWorkspace[]>>(
      url,
      options.token,
      options.tlsInsecure
    );

    workspaces.push(...result.data);

    const nextPage = result.meta?.pagination?.["next-page"];
    if (!nextPage) break;
    page = nextPage;
  }

  return workspaces;
}

export async function getCurrentStateVersion(
  options: TfeClientOptions,
  workspaceId: string
): Promise<TfeStateVersion | null> {
  try {
    const result = await tfeApiFetch<TfeApiResponse<TfeStateVersion>>(
      `${options.hostname}/api/v2/workspaces/${encodeURIComponent(workspaceId)}/current-state-version`,
      options.token,
      options.tlsInsecure
    );
    return result.data;
  } catch (error) {
    // Workspace may have no state yet
    if (error instanceof Error && error.message.includes("404")) {
      return null;
    }
    throw error;
  }
}

export async function downloadState(
  options: TfeClientOptions,
  downloadUrl: string
): Promise<string> {
  const agent = buildAgent(options.tlsInsecure);
  const fetchOptions: RequestInit & { dispatcher?: unknown } = {
    headers: {
      Authorization: `Bearer ${options.token}`
    }
  };

  if (agent) {
    (fetchOptions as Record<string, unknown>).dispatcher = agent;
  }

  const response = await fetch(downloadUrl, fetchOptions);

  if (!response.ok) {
    throw new Error(`State download failed: ${response.status} ${response.statusText}`);
  }

  return response.text();
}

// RUM billing excludes data sources and these resource types, regardless of
// mode (mirrors packages/rum-engine's EXCLUDED_TYPES + mode:"data" rule).
const DATA_SOURCE_TYPE_PREFIX = "data.";
const EXCLUDED_RESOURCE_TYPES = new Set(["null_resource", "terraform_data"]);

function isBillableResourceSummary(entry: TfeStateVersionResourceSummary): boolean {
  const type = entry.type;
  if (typeof type !== "string") return false; // unknown type: cannot confirm billable, exclude (overstatement forbidden)
  if (type.startsWith(DATA_SOURCE_TYPE_PREFIX)) return false;
  if (EXCLUDED_RESOURCE_TYPES.has(type)) return false;
  return true;
}

/**
 * Provider short name for a billable resource type, derived from the leading
 * segment before the first underscore ("aws_instance" -> "aws",
 * "google_compute_instance" -> "google"; a type with no underscore, e.g.
 * "time", is used as-is).
 *
 * Empirically (a live TFC organization, 2026-07-01), real
 * state versions DO carry a per-entry "provider" field and a top-level
 * attributes.providers breakdown — but both key off the full provider source
 * address (e.g. `provider["registry.terraform.io/grafana/grafana"]`), which
 * would require parsing a quoted registry address string. The type-prefix
 * heuristic yields the same practical grouping by registry namespace without
 * that parsing, so it's the approach used here.
 */
export function providerFromType(type: string): string {
  const idx = type.indexOf("_");
  return idx === -1 ? type : type.slice(0, idx);
}

/**
 * Billing-aware billable RUM count, with a per-provider breakdown, for a
 * historical state version. Single source of truth for the billable-sweep
 * rules — extractStateVersionCount below delegates here.
 *
 * Preference order (same as extractStateVersionCount):
 *  1. resources-processed === false → null (not yet processed by TFE/TFC;
 *     caller must download the raw state and count).
 *  2. attributes.resources present → sum only billable entries (excludes
 *     data source entries identified by a "data." type prefix, entries with
 *     a missing/non-string type, and types null_resource/terraform_data).
 *     This is computed directly rather than trusting resource-count, which
 *     includes data sources.
 *  3. Otherwise → null; caller must download the state and count. We
 *     deliberately do NOT fall back to "resource-count" (overstates by
 *     including data sources) or "billable-rum-count" (not authoritative
 *     enough to trust without the resources array to cross-check against;
 *     overstatement is forbidden, so any metadata we can't verify directly
 *     must be treated as unusable).
 */
export function extractStateVersionBreakdown(
  sv: TfeHistoricalStateVersion
): { count: number; byProvider: Record<string, number> } | null {
  const attr = sv.attributes;
  if (attr["resources-processed"] === false) return null; // not yet processed; caller must download and count

  if (!Array.isArray(attr.resources)) return null; // resources array absent/unusable; caller must download the state and count

  const byProvider: Record<string, number> = {};
  let count = 0;
  for (const entry of attr.resources) {
    if (!isBillableResourceSummary(entry)) continue;
    const entryCount = typeof entry.count === "number" ? entry.count : 0;
    count += entryCount;
    const provider = providerFromType(entry.type as string);
    byProvider[provider] = (byProvider[provider] ?? 0) + entryCount;
  }

  return { count, byProvider };
}

/**
 * Billing-aware billable RUM count for a historical state version. Delegates
 * to extractStateVersionBreakdown so the billable-sweep rules live in one
 * place; see that function's doc comment for the full preference order.
 */
export function extractStateVersionCount(sv: TfeHistoricalStateVersion): number | null {
  const breakdown = extractStateVersionBreakdown(sv);
  return breakdown ? breakdown.count : null;
}

export async function listStateVersions(
  options: TfeClientOptions,
  orgName: string,
  workspaceName: string
): Promise<TfeHistoricalStateVersion[]> {
  const versions: TfeHistoricalStateVersion[] = [];
  let page = 1;
  const pageSize = 100;
  // eslint-disable-next-line no-constant-condition
  while (true) {
    const url =
      `${options.hostname}/api/v2/state-versions` +
      `?filter[workspace][name]=${encodeURIComponent(workspaceName)}` +
      `&filter[organization][name]=${encodeURIComponent(orgName)}` +
      `&page[size]=${pageSize}&page[number]=${page}`;
    const result = await tfeApiFetch<TfeApiResponse<TfeHistoricalStateVersion[]>>(
      url, options.token, options.tlsInsecure
    );
    versions.push(...result.data);
    const nextPage = result.meta?.pagination?.["next-page"];
    if (!nextPage) break;
    page = nextPage;
  }
  return versions;
}
