import type { RumHistoryResult, StateVersionEvent } from "@rum-tool/rum-engine";

export type RumHistoryStatus = "queued" | "running" | "completed" | "failed";

export type RumHistoryRequest = {
  tfeHostname: string;
  tfeToken: string;
  organization: string;
  workspaceFilter?: string;
  tlsInsecure?: boolean;
};

export type RumHistoryRecord = {
  id: string;
  status: RumHistoryStatus;
  createdAt: string;
  updatedAt: string;
  request: Omit<RumHistoryRequest, "tfeToken"> & { tfeToken: string };
  errorMessage?: string;
  progress?: {
    phase: "connecting" | "listing_workspaces" | "listing_versions" | "reconstructing";
    workspacesFound?: number;
    workspacesProcessed?: number;
    workspaceErrors?: number;
  };
  events?: StateVersionEvent[]; // accumulated, deduped by workspaceId+createdAt
  result?: RumHistoryResult;
};
