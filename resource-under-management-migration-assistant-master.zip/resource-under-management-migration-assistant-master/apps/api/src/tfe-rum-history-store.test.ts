import { describe, it, expect, vi } from "vitest";

// Mock filesystem before importing store
vi.mock("node:fs", () => ({
  existsSync: vi.fn(() => false),
  mkdirSync: vi.fn(),
  readFileSync: vi.fn(),
  writeFileSync: vi.fn(),
  renameSync: vi.fn()
}));

const {
  createRumHistoryRun,
  updateRumHistoryRun,
  getRumHistoryRun,
  getPriorEventsForOrg
} = await import("./tfe-rum-history-store.js");

describe("tfe-rum-history-store", () => {
  const req = { tfeHostname: "https://tfe.x", tfeToken: "secret", organization: "acme" };
  it("redacts the token on create", () => {
    const rec = createRumHistoryRun(req);
    expect(rec.request.tfeToken).toBe("***redacted***");
    expect(rec.status).toBe("queued");
  });
  it("updates and reads back", () => {
    const rec = createRumHistoryRun(req);
    updateRumHistoryRun(rec.id, (c) => ({ ...c, status: "completed", events: [{ workspaceId: "w", createdAt: "2026-01-01T00:00:00Z", count: 5 }] }));
    expect(getRumHistoryRun(rec.id)?.status).toBe("completed");
  });
  it("returns prior events for the same org for accumulation", () => {
    const rec = createRumHistoryRun(req);
    updateRumHistoryRun(rec.id, (c) => ({ ...c, status: "completed", events: [{ workspaceId: "w", createdAt: "2026-01-01T00:00:00Z", count: 5 }] }));
    const prior = getPriorEventsForOrg("https://tfe.x", "acme");
    expect(prior).toContainEqual({ workspaceId: "w", createdAt: "2026-01-01T00:00:00Z", count: 5 });
  });
});
