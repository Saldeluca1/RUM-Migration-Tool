import { describe, expect, it, vi, beforeEach, afterEach } from "vitest";

// We test the pure logic and URL construction without hitting real TFE.
// The actual HTTP calls are tested via integration tests.

describe("tfe-client module structure", () => {
  it("exports expected functions", async () => {
    const client = await import("./tfe-client.js");
    expect(typeof client.validateConnection).toBe("function");
    expect(typeof client.getOrganization).toBe("function");
    expect(typeof client.listAllWorkspaces).toBe("function");
    expect(typeof client.getCurrentStateVersion).toBe("function");
    expect(typeof client.downloadState).toBe("function");
  });
});

describe("TFE client URL construction", () => {
  let originalFetch: typeof global.fetch;

  beforeEach(() => {
    originalFetch = global.fetch;
  });

  afterEach(() => {
    global.fetch = originalFetch;
  });

  it("getOrganization calls correct endpoint", async () => {
    const { getOrganization } = await import("./tfe-client.js");

    let capturedUrl = "";
    global.fetch = vi.fn(async (url: string | URL | Request) => {
      capturedUrl = typeof url === "string" ? url : url.toString();
      return new Response(
        JSON.stringify({
          data: {
            id: "org-123",
            attributes: { name: "my-org", email: "admin@example.com" }
          }
        }),
        { status: 200, headers: { "Content-Type": "application/json" } }
      );
    }) as typeof fetch;

    const result = await getOrganization(
      { hostname: "https://tfe.example.com", token: "test-token" },
      "my-org"
    );

    expect(capturedUrl).toBe("https://tfe.example.com/api/v2/organizations/my-org");
    expect(result.name).toBe("my-org");
    expect(result.email).toBe("admin@example.com");
  });

  it("handles 404 for getCurrentStateVersion gracefully", async () => {
    const { getCurrentStateVersion } = await import("./tfe-client.js");

    global.fetch = vi.fn(async () => {
      return new Response(JSON.stringify({ errors: [{ status: "404" }] }), {
        status: 404,
        statusText: "Not Found"
      });
    }) as typeof fetch;

    const result = await getCurrentStateVersion(
      { hostname: "https://tfe.example.com", token: "test-token" },
      "ws-no-state"
    );

    expect(result).toBeNull();
  });

  it("handles rate limiting with retry", async () => {
    const { getOrganization } = await import("./tfe-client.js");
    let callCount = 0;

    global.fetch = vi.fn(async () => {
      callCount++;
      if (callCount === 1) {
        return new Response("", {
          status: 429,
          headers: { "retry-after": "0" }
        });
      }
      return new Response(
        JSON.stringify({
          data: { id: "org-1", attributes: { name: "retry-org" } }
        }),
        { status: 200, headers: { "Content-Type": "application/json" } }
      );
    }) as typeof fetch;

    const result = await getOrganization(
      { hostname: "https://tfe.example.com", token: "tok" },
      "retry-org"
    );

    expect(callCount).toBe(2);
    expect(result.name).toBe("retry-org");
  });
});

describe("extractStateVersionCount", () => {
  // Fixtures below mirror the real TFC state-versions response shape observed
  // empirically against a live TFC organization (2026-07-01):
  // attributes.resources[] entries have { name, type, count, module, provider,
  // "index-keys" } — no "mode" field, but data sources are identifiable via a
  // "data." type prefix (e.g. "data.vault_kv_secret_v2"). attributes also
  // exposes a top-level "billable-rum-count" number computed by TFC itself.
  // The legacy "resource-count" attribute was NOT present in the real response.

  it("sums only billable resources, excluding data sources by type prefix", async () => {
    const { extractStateVersionCount } = await import("./tfe-client.js");
    const result = extractStateVersionCount({
      id: "sv-1",
      attributes: {
        serial: 14,
        "created-at": "x",
        "billable-rum-count": 22,
        resources: [
          { name: "grafana_admin", type: "data.vault_kv_secret_v2", count: 1, module: "root" },
          { name: "all", type: "grafana_dashboard", count: 16, module: "root" },
          { name: "loki", type: "grafana_data_source", count: 1, module: "root" },
          { name: "prometheus", type: "grafana_data_source", count: 1, module: "root" },
          { name: "hashistack", type: "grafana_folder", count: 1, module: "root" },
          { name: "admin_user", type: "grafana_user", count: 1, module: "root" },
          { name: "admin_user", type: "random_password", count: 1, module: "root" },
          { name: "grafana_admin", type: "vault_kv_secret_v2", count: 1, module: "root" }
        ]
      }
    });
    // 16+1+1+1+1+1+1 = 22 (excludes the data.vault_kv_secret_v2 entry) — matches
    // TFC's own billable-rum-count for this exact real state version.
    expect(result).toBe(22);
  });

  it("excludes null_resource and terraform_data types from the billable sum", async () => {
    const { extractStateVersionCount } = await import("./tfe-client.js");
    const result = extractStateVersionCount({
      id: "sv-1",
      attributes: {
        serial: 1,
        "created-at": "x",
        resources: [
          { name: "a", type: "aws_instance", count: 3, module: "root" },
          { name: "b", type: "null_resource", count: 5, module: "root" },
          { name: "c", type: "terraform_data", count: 2, module: "root" },
          { name: "d", type: "data.aws_ami", count: 1, module: "root" }
        ]
      }
    });
    expect(result).toBe(3);
  });

  it("does not fall back to the raw resource-count attribute when a billable sum is computable from resources", async () => {
    const { extractStateVersionCount } = await import("./tfe-client.js");
    const result = extractStateVersionCount({
      id: "sv-1",
      attributes: {
        serial: 1,
        "created-at": "x",
        "resource-count": 999,
        resources: [{ name: "a", type: "aws_instance", count: 1, module: "root" }]
      }
    });
    expect(result).toBe(1);
  });

  it("returns null when the resources array is absent, even if billable-rum-count is present (does not fall back to it)", async () => {
    const { extractStateVersionCount } = await import("./tfe-client.js");
    const result = extractStateVersionCount({
      id: "sv-1",
      attributes: { serial: 1, "created-at": "x", "billable-rum-count": 7, "resource-count": 999 }
    });
    expect(result).toBeNull();
  });

  it("excludes entries with a missing/non-string type from the billable sum (unknown type is not billable)", async () => {
    const { extractStateVersionCount } = await import("./tfe-client.js");
    const result = extractStateVersionCount({
      id: "sv-1",
      attributes: {
        serial: 1,
        "created-at": "x",
        resources: [
          { name: "a", type: "aws_instance", count: 3, module: "root" },
          { name: "unknown", count: 5, module: "root" } as unknown as {
            type?: string;
            count?: number;
            name?: string;
            module?: string;
          }
        ]
      }
    });
    expect(result).toBe(3);
  });

  it("returns null when neither resources nor billable-rum-count is available (does not fall back to raw resource-count)", async () => {
    const { extractStateVersionCount } = await import("./tfe-client.js");
    const result = extractStateVersionCount({
      id: "sv-1",
      attributes: { serial: 1, "created-at": "x", "resource-count": 999 }
    });
    expect(result).toBeNull();
  });

  it("returns null when not yet processed", async () => {
    const { extractStateVersionCount } = await import("./tfe-client.js");
    expect(extractStateVersionCount({ id: "sv-1", attributes: { serial: 1, "created-at": "x", "resources-processed": false } })).toBeNull();
  });
  it("returns null when not yet processed even if resources is an empty array", async () => {
    const { extractStateVersionCount } = await import("./tfe-client.js");
    expect(
      extractStateVersionCount({
        id: "sv-1",
        attributes: { serial: 1, "created-at": "x", "resources-processed": false, resources: [] }
      })
    ).toBeNull();
  });
});

describe("extractStateVersionBreakdown", () => {
  // Provider derivation: the leading segment of the resource TYPE before the
  // first underscore ("aws_instance" -> "aws", "google_compute_instance" ->
  // "google"). Empirically (a live TFC organization,
  // 2026-07-01), real state versions DO carry a per-entry "provider" field
  // AND a top-level attributes.providers breakdown — but both key off the
  // full provider source address (e.g. `provider["registry.terraform.io/
  // grafana/grafana"]`), which requires parsing a quoted address string. The
  // type-prefix heuristic gives the same practical grouping (by registry
  // namespace) without that parsing, and reuses the exact billable-exclusion
  // sweep already verified in extractStateVersionCount, so it's the accepted
  // approach here.

  it("sums billable counts per provider derived from the type prefix", async () => {
    const { extractStateVersionBreakdown } = await import("./tfe-client.js");
    const result = extractStateVersionBreakdown({
      id: "sv-1",
      attributes: {
        serial: 1,
        "created-at": "x",
        resources: [
          { name: "a", type: "aws_instance", count: 3, module: "root" },
          { name: "b", type: "aws_s3_bucket", count: 2, module: "root" },
          { name: "c", type: "google_compute_instance", count: 1, module: "root" }
        ]
      }
    });
    expect(result).toEqual({ count: 6, byProvider: { aws: 5, google: 1 } });
  });

  it("excludes data sources, null_resource/terraform_data, and non-string types from both count and byProvider", async () => {
    const { extractStateVersionBreakdown } = await import("./tfe-client.js");
    const result = extractStateVersionBreakdown({
      id: "sv-1",
      attributes: {
        serial: 1,
        "created-at": "x",
        resources: [
          { name: "a", type: "aws_instance", count: 3, module: "root" },
          { name: "b", type: "null_resource", count: 5, module: "root" },
          { name: "c", type: "terraform_data", count: 2, module: "root" },
          { name: "d", type: "data.aws_ami", count: 1, module: "root" },
          { name: "e", count: 9, module: "root" } as unknown as { type?: string; count?: number }
        ]
      }
    });
    expect(result).toEqual({ count: 3, byProvider: { aws: 3 } });
  });

  it("uses the whole type as the provider when there is no underscore", async () => {
    const { extractStateVersionBreakdown } = await import("./tfe-client.js");
    const result = extractStateVersionBreakdown({
      id: "sv-1",
      attributes: {
        serial: 1,
        "created-at": "x",
        resources: [{ name: "a", type: "time", count: 1, module: "root" }]
      }
    });
    expect(result).toEqual({ count: 1, byProvider: { time: 1 } });
  });

  it("returns null when not yet processed", async () => {
    const { extractStateVersionBreakdown } = await import("./tfe-client.js");
    expect(
      extractStateVersionBreakdown({
        id: "sv-1",
        attributes: { serial: 1, "created-at": "x", "resources-processed": false }
      })
    ).toBeNull();
  });

  it("returns null when the resources array is absent", async () => {
    const { extractStateVersionBreakdown } = await import("./tfe-client.js");
    expect(
      extractStateVersionBreakdown({
        id: "sv-1",
        attributes: { serial: 1, "created-at": "x", "billable-rum-count": 7 }
      })
    ).toBeNull();
  });

  it("agrees with extractStateVersionCount's total (single source of exclusion rules)", async () => {
    const { extractStateVersionBreakdown, extractStateVersionCount } = await import("./tfe-client.js");
    const sv = {
      id: "sv-1",
      attributes: {
        serial: 14,
        "created-at": "x",
        resources: [
          { name: "grafana_admin", type: "data.vault_kv_secret_v2", count: 1, module: "root" },
          { name: "all", type: "grafana_dashboard", count: 16, module: "root" },
          { name: "loki", type: "grafana_data_source", count: 1, module: "root" },
          { name: "admin_user", type: "random_password", count: 1, module: "root" },
          { name: "grafana_admin", type: "vault_kv_secret_v2", count: 1, module: "root" }
        ]
      }
    };
    expect(extractStateVersionBreakdown(sv)?.count).toBe(extractStateVersionCount(sv));
  });
});

describe("listStateVersions", () => {
  afterEach(() => vi.restoreAllMocks());
  it("paginates and accumulates all versions", async () => {
    const { listStateVersions } = await import("./tfe-client.js");
    const page1 = { data: [{ id: "sv-2", attributes: { serial: 2, "created-at": "2026-02-01T00:00:00Z" } }], meta: { pagination: { "next-page": 2 } } };
    const page2 = { data: [{ id: "sv-1", attributes: { serial: 1, "created-at": "2026-01-01T00:00:00Z" } }], meta: { pagination: { "next-page": null } } };
    const fetchMock = vi.spyOn(global, "fetch")
      .mockResolvedValueOnce({ ok: true, status: 200, json: async () => page1 } as Response)
      .mockResolvedValueOnce({ ok: true, status: 200, json: async () => page2 } as Response);
    const result = await listStateVersions({ hostname: "https://tfe.example.com", token: "t" }, "acme", "prod");
    expect(result.map((v) => v.id)).toEqual(["sv-2", "sv-1"]);
    expect(fetchMock).toHaveBeenCalledTimes(2);
    const calledUrl = fetchMock.mock.calls[0][0] as string;
    expect(calledUrl).toContain("/api/v2/state-versions");
    expect(calledUrl).toContain("filter[workspace][name]=prod");
    expect(calledUrl).toContain("filter[organization][name]=acme");
  });
});
