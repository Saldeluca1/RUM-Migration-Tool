import pino from "pino";

const isDev = process.env.NODE_ENV !== "production";

export const logger = pino({
  level: process.env.LOG_LEVEL ?? (isDev ? "debug" : "info"),
  ...(isDev
    ? {
        transport: {
          target: "pino-pretty",
          options: {
            colorize: true,
            translateTime: "HH:MM:ss.l",
            ignore: "pid,hostname"
          }
        }
      }
    : {})
});

/** Create a child logger with a request ID for tracing */
export function requestLogger(requestId: string) {
  return logger.child({ requestId });
}
