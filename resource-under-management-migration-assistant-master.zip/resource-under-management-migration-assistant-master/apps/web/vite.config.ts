import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";

const rootPkg = JSON.parse(
  readFileSync(fileURLToPath(new URL("../../package.json", import.meta.url)), "utf-8")
) as { version: string };

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5174
  },
  define: {
    __APP_VERSION__: JSON.stringify(rootPkg.version)
  }
});
