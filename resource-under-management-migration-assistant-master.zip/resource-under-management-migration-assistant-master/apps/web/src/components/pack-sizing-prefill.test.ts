import { describe, expect, it } from "vitest";
import { applyPrefill } from "./pack-sizing-prefill";

describe("applyPrefill", () => {
  it("sets useMonthlyMode true and passes monthlyValues through", () => {
    const monthlyValues = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120];
    const result = applyPrefill({ monthlyValues, growthPct: null });

    expect(result.useMonthlyMode).toBe(true);
    expect(result.monthlyValues).toBe(monthlyValues);
  });

  it("omits forecastGrowthPct when growthPct is null", () => {
    const result = applyPrefill({ monthlyValues: Array(12).fill(0), growthPct: null });

    expect(result).not.toHaveProperty("forecastGrowthPct");
  });

  it("rounds growthPct 33.4 to 33", () => {
    const result = applyPrefill({ monthlyValues: Array(12).fill(0), growthPct: 33.4 });

    expect(result.forecastGrowthPct).toBe(33);
  });
});
