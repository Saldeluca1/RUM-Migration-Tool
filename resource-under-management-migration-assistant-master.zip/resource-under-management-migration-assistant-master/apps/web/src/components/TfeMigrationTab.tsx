import { useState } from "react";
import {
  Button,
  Checkbox,
  DataTable,
  InlineLoading,
  ActionableNotification,
  PasswordInput,
  ProgressBar,
  Select,
  SelectItem,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableHeader,
  TableRow,
  Tag,
  TextInput,
  Tile
} from "@carbon/react";
import {
  startTfeMigrationRun,
  getTfeMigrationRun,
  getTfeMigrationExportUrl,
  listTfeProjects,
  type TfeMigrationRecord,
  type TfeMigrationSummary,
  type TfeWorkspaceResult,
  type TfeProject,
  type TfeProjectSummary,
  type TfeModuleSummary,
  type TfeModuleEntry
} from "../lib/api";

export function TfeMigrationTab() {
  /* ---------- form state ---------- */
  const [tfeHostname, setTfeHostname] = useState("");
  const [tfeToken, setTfeToken] = useState("");
  const [organization, setOrganization] = useState("");
  const [workspaceFilter, setWorkspaceFilter] = useState("");
  const [tlsInsecure, setTlsInsecure] = useState(false);

  /* ---------- scope state ---------- */
  const [scopeLevel, setScopeLevel] = useState<"organization" | "project">("organization");
  const [projects, setProjects] = useState<TfeProject[]>([]);
  const [selectedProjectId, setSelectedProjectId] = useState("");
  const [selectedProjectName, setSelectedProjectName] = useState("");
  const [projectsLoading, setProjectsLoading] = useState(false);
  const [projectsError, setProjectsError] = useState("");

  /* ---------- run state ---------- */
  const [isRunning, setIsRunning] = useState(false);
  const [runId, setRunId] = useState<string | null>(null);
  const [status, setStatus] = useState<string>("");
  const [progress, setProgress] = useState<TfeMigrationRecord["progress"]>(undefined);
  const [message, setMessage] = useState("");

  /* ---------- result state ---------- */
  const [summary, setSummary] = useState<TfeMigrationSummary | null>(null);
  const [byProject, setByProject] = useState<TfeProjectSummary[]>([]);
  const [byModule, setByModule] = useState<TfeModuleSummary | null>(null);
  const [workspaces, setWorkspaces] = useState<TfeWorkspaceResult[]>([]);
  const [moduleExpanded, setModuleExpanded] = useState(true);

  /* ---------- load projects ---------- */
  async function handleLoadProjects() {
    if (!tfeHostname || !tfeToken || !organization) return;

    setProjectsLoading(true);
    setProjectsError("");
    setProjects([]);
    setSelectedProjectId("");
    setSelectedProjectName("");

    try {
      const result = await listTfeProjects({
        tfeHostname: tfeHostname.replace(/\/+$/, ""),
        tfeToken,
        organization,
        tlsInsecure: tlsInsecure || undefined
      });
      setProjects(result);
      if (result.length === 0) {
        setProjectsError("No projects found in this organization.");
      }
    } catch (error) {
      const msg = error instanceof Error ? error.message : String(error);
      setProjectsError(`Failed to load projects: ${msg}`);
    } finally {
      setProjectsLoading(false);
    }
  }

  /* ---------- polling ---------- */
  async function pollRun(id: string) {
    for (let i = 0; i < 300; i += 1) {
      const run = await getTfeMigrationRun(id);
      setStatus(run.status);
      setProgress(run.progress);

      if (run.status === "completed") {
        setSummary(run.summary ?? null);
        setByProject(run.byProject ?? []);
        setByModule(run.byModule ?? null);
        setWorkspaces(run.workspaces ?? []);
        setMessage(`Migration estimate ${id} completed.`);
        return;
      }
      if (run.status === "failed") {
        setMessage(`Migration estimate ${id} failed: ${run.errorMessage ?? "unknown error"}`);
        return;
      }
      await new Promise((resolve) => setTimeout(resolve, 1000));
    }
    setMessage(`Migration estimate ${id} timed out after 5 minutes.`);
  }

  /* ---------- submit ---------- */
  async function handleRun() {
    if (!tfeHostname || !tfeToken || !organization) return;
    if (scopeLevel === "project" && !selectedProjectId) return;

    setIsRunning(true);
    setMessage("");
    setSummary(null);
    setByProject([]);
    setByModule(null);
    setWorkspaces([]);
    setStatus("queued");
    setProgress(undefined);

    try {
      const created = await startTfeMigrationRun({
        tfeHostname: tfeHostname.replace(/\/+$/, ""),
        tfeToken,
        organization,
        scopeLevel,
        projectId: scopeLevel === "project" ? selectedProjectId : undefined,
        projectName: scopeLevel === "project" ? selectedProjectName : undefined,
        workspaceFilter: workspaceFilter || undefined,
        tlsInsecure: tlsInsecure || undefined
      });
      setRunId(created.id);
      setMessage(`Run ${created.id} queued — connecting to TFE...`);
      await pollRun(created.id);
    } catch (error) {
      const msg = error instanceof Error ? error.message : String(error);
      setMessage(`Error: ${msg}`);
    } finally {
      setIsRunning(false);
    }
  }

  /* ---------- validation ---------- */
  const canLoadProjects = Boolean(tfeHostname && tfeToken && organization && !isRunning && !projectsLoading);
  const canRun = Boolean(
    tfeHostname && tfeToken && organization && !isRunning &&
    (scopeLevel === "organization" || selectedProjectId)
  );

  /* ---------- progress label ---------- */
  function progressLabel(): string {
    if (!progress) return status;
    switch (progress.phase) {
      case "connecting":
        return "Connecting to TFE...";
      case "listing_workspaces":
        return "Listing workspaces...";
      case "downloading_states":
        return `Processing workspaces (${progress.workspacesProcessed ?? 0} / ${progress.workspacesFound ?? "?"})...`;
      case "calculating":
        return "Finalizing results...";
      default:
        return status;
    }
  }

  /* ---------- project table ---------- */
  const projHeaders = [
    { key: "projectName", header: "Project" },
    { key: "workspaceCount", header: "Workspaces" },
    { key: "billableRum", header: "Billable RUM" },
    { key: "nonBillable", header: "Non-Billable" },
    { key: "totalResources", header: "Total Resources" }
  ];

  const projRows = byProject.map((p, idx) => ({
    id: `proj-${idx}`,
    projectName: p.projectName,
    workspaceCount: String(p.workspaceCount),
    billableRum: String(p.rum),
    nonBillable: String(p.excludedResources),
    totalResources: String(p.rum + p.excludedResources)
  }));

  /* ---------- workspace table ---------- */
  const wsHeaders = [
    { key: "workspaceName", header: "Workspace" },
    { key: "projectName", header: "Project" },
    { key: "billableRum", header: "Billable RUM" },
    { key: "nonBillable", header: "Non-Billable" },
    { key: "totalResources", header: "Total Resources" },
    { key: "status", header: "Status" }
  ];

  const wsRows = workspaces.map((ws, idx) => ({
    id: `ws-${idx}`,
    workspaceName: ws.workspaceName,
    projectName: ws.projectName ?? "—",
    billableRum: String(ws.rum),
    nonBillable: String(ws.excludedResources),
    totalResources: String(ws.totalResources),
    status: ws.parseError ? `Error: ${ws.parseError}` : "OK"
  }));

  return (
    <div style={{ display: "grid", gap: "1rem" }}>
      {/* ---------- connection form ---------- */}
      <Tile className="card" style={{ padding: "1.25rem" }}>
        <h3 style={{ margin: "0 0 0.75rem" }}>TFE Migration Estimator</h3>
        <p className="helper-text" style={{ marginBottom: "1rem" }}>
          Connect to a Terraform Enterprise instance to estimate the RUM impact of migrating workspaces to HCP Terraform Cloud.
          Scope by entire organization or drill down to a specific project.
        </p>

        <div className="wizard-form">
          <TextInput
            id="tfe-hostname"
            labelText="TFE Hostname"
            placeholder="https://tfe.company.com"
            value={tfeHostname}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTfeHostname(e.target.value)}
            disabled={isRunning}
          />
          <PasswordInput
            id="tfe-token"
            labelText="TFE API Token"
            placeholder="Workspace-scoped or team token with read access"
            value={tfeToken}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTfeToken(e.target.value)}
            disabled={isRunning}
            hidePasswordLabel="Hide token"
            showPasswordLabel="Show token"
          />
          <TextInput
            id="tfe-org"
            labelText="Organization"
            placeholder="my-org"
            value={organization}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setOrganization(e.target.value)}
            disabled={isRunning}
          />

          {/* ---------- scope selector ---------- */}
          <div>
            <p style={{ fontSize: "0.85rem", fontWeight: 600, marginBottom: "0.5rem" }}>Scan Scope</p>
            <div className="wizard-actions">
              <Button
                kind={scopeLevel === "organization" ? "primary" : "tertiary"}
                size="sm"
                onClick={() => setScopeLevel("organization")}
                disabled={isRunning}
              >
                Entire Organization
              </Button>
              <Button
                kind={scopeLevel === "project" ? "primary" : "tertiary"}
                size="sm"
                onClick={() => {
                  setScopeLevel("project");
                  if (projects.length === 0 && canLoadProjects) {
                    void handleLoadProjects();
                  }
                }}
                disabled={isRunning}
              >
                By Project
              </Button>
            </div>
          </div>

          {/* ---------- project picker ---------- */}
          {scopeLevel === "project" && (
            <div className="provider-card">
              <div style={{ display: "flex", alignItems: "flex-end", gap: "0.5rem", flexWrap: "wrap" }}>
                <div style={{ flex: 1, minWidth: "200px" }}>
                  <Select
                    id="tfe-project-select"
                    labelText="Project"
                    value={selectedProjectId}
                    onChange={(e: React.ChangeEvent<HTMLSelectElement>) => {
                      const proj = projects.find((p) => p.id === e.target.value);
                      setSelectedProjectId(e.target.value);
                      setSelectedProjectName(proj?.name ?? "");
                    }}
                    disabled={isRunning || projectsLoading}
                  >
                    <SelectItem value="" text={projectsLoading ? "Loading projects…" : projects.length === 0 ? "No projects loaded" : "Select a project…"} />
                    {projects.map((proj) => (
                      <SelectItem
                        key={proj.id}
                        value={proj.id}
                        text={`${proj.name}${proj.description ? ` — ${proj.description}` : ""} (${proj.workspaceCount} workspace${proj.workspaceCount !== 1 ? "s" : ""})`}
                      />
                    ))}
                  </Select>
                </div>
                <Button kind="tertiary" size="sm" onClick={handleLoadProjects} disabled={!canLoadProjects}>
                  {projectsLoading ? "Loading…" : projects.length === 0 ? "Load Projects" : "Refresh"}
                </Button>
              </div>

              {projectsError && (
                <p className="scan-error" style={{ fontSize: "0.85rem", marginTop: "0.4rem" }}>{projectsError}</p>
              )}

              {selectedProjectId && projects.find((p) => p.id === selectedProjectId) && (() => {
                const proj = projects.find((p) => p.id === selectedProjectId)!;
                const estSecs = Math.ceil(proj.workspaceCount * 0.5);
                return (
                  <p className="helper-text" style={{ marginTop: "0.4rem" }}>
                    This project contains <strong>{proj.workspaceCount}</strong> workspace{proj.workspaceCount !== 1 ? "s" : ""} · Estimated time: ~{estSecs}s
                  </p>
                );
              })()}
            </div>
          )}

          <TextInput
            id="tfe-workspace-filter"
            labelText="Workspace Filter (optional)"
            placeholder="Search by workspace name"
            value={workspaceFilter}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setWorkspaceFilter(e.target.value)}
            disabled={isRunning}
          />
          <Checkbox
            id="tfe-tls-insecure"
            labelText="Allow self-signed TLS certificates"
            checked={tlsInsecure}
            onChange={(_: unknown, { checked }: { checked: boolean }) => setTlsInsecure(checked)}
            disabled={isRunning}
          />
        </div>

        <div className="wizard-actions" style={{ marginTop: "1rem" }}>
          <Button kind="primary" onClick={handleRun} disabled={!canRun}>
            {isRunning ? "Running..." : scopeLevel === "project" && selectedProjectName
              ? `Estimate RUM for "${selectedProjectName}"`
              : "Run Migration Estimate"}
          </Button>
        </div>
      </Tile>

      {/* ---------- status panel ---------- */}
      {isRunning && (
        <Tile className="card" style={{ padding: "1.25rem" }}>
          {progress?.workspacesFound && progress.workspacesFound > 0 ? (
            <>
              <ProgressBar
                label={progressLabel()}
                value={Math.round(((progress.workspacesProcessed ?? 0) / progress.workspacesFound) * 100)}
                max={100}
                status="active"
                size="big"
              />
              {progress.workspacesProcessed !== undefined && (
                <p style={{ fontSize: "0.8rem", color: "#6f6f6f", marginTop: "0.4rem" }}>
                  {progress.workspacesProcessed.toLocaleString()} / {progress.workspacesFound.toLocaleString()} workspaces
                  {progress.workspacesProcessed > 0 && (
                    <> · ~{Math.ceil((progress.workspacesFound - progress.workspacesProcessed) * 0.5)}s remaining</>
                  )}
                </p>
              )}
            </>
          ) : (
            <InlineLoading description={progressLabel()} status="active" />
          )}
          {runId && <p style={{ fontSize: "0.8rem", color: "#6f6f6f", marginTop: "0.4rem" }}>Run ID: {runId}</p>}
        </Tile>
      )}

      {!isRunning && message && (message.includes("failed") || message.includes("timed out")) && (
        <ActionableNotification
          kind="error"
          title="Migration Failed"
          subtitle={message}
          lowContrast
          inline
          actionButtonLabel="Retry"
          onActionButtonClick={handleRun}
          hideCloseButton
        />
      )}

      {!isRunning && message && !message.includes("failed") && !message.includes("timed out") && summary && (
        <ActionableNotification
          kind="success"
          title="Migration Estimate Complete"
          subtitle={`${summary.totalRum.toLocaleString()} Billable RUM across ${summary.totalWorkspaces} workspaces`}
          lowContrast
          inline
          actionButtonLabel="Re-run"
          onActionButtonClick={handleRun}
          hideCloseButton
        />
      )}

      {/* ---------- summary ---------- */}
      {summary && (
        <Tile className="card" style={{ padding: "1.25rem" }}>
          <h3 style={{ margin: "0 0 0.75rem" }}>Migration Summary</h3>
          <div className="kpi-grid-inline">
            <div>
              <h4>
                Billable RUM
                <span className="metric-help" tabIndex={0}>
                  i
                  <span className="metric-help-text">
                    Resources Under Management — the billing metric for HCP Terraform. Counts managed resource instances excluding null_resource and terraform_data.
                  </span>
                </span>
              </h4>
              <p>{summary.totalRum.toLocaleString()}</p>
            </div>
            <div>
              <h4>Workspaces Scanned</h4>
              <p>{summary.totalWorkspaces.toLocaleString()}</p>
            </div>
            <div>
              <h4>With State</h4>
              <p>{summary.workspacesWithState.toLocaleString()}</p>
            </div>
            <div>
              <h4>
                Non-Billable Resources
                <span className="metric-help" tabIndex={0}>
                  i
                  <span className="metric-help-text">
                    Resources in state that do not count toward RUM: data sources, null_resource, and terraform_data.
                  </span>
                </span>
              </h4>
              <p>{summary.totalExcludedResources.toLocaleString()}</p>
            </div>
            <div>
              <h4>Total Resources</h4>
              <p>{(summary.totalCountedResources + summary.totalExcludedResources).toLocaleString()}</p>
            </div>
            <div>
              <h4>Parse Errors</h4>
              <p>{summary.parseErrors.toLocaleString()}</p>
            </div>
          </div>
        </Tile>
      )}

      {/* ---------- project breakdown ---------- */}
      {byProject.length > 1 && (
        <Tile className="card" style={{ padding: "1.25rem" }}>
          <h3 style={{ margin: "0 0 0.75rem" }}>By Project</h3>
          <DataTable rows={projRows} headers={projHeaders}>
            {({ rows, headers, getHeaderProps, getTableProps }) => (
              <TableContainer>
                <Table {...getTableProps()}>
                  <TableHead>
                    <TableRow>
                      {headers.map((header) => {
                        const { key: _key, ...headerProps } = getHeaderProps({ header });
                        return (
                          <TableHeader key={header.key} {...headerProps}>
                            {header.header}
                          </TableHeader>
                        );
                      })}
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {rows.map((row) => (
                      <TableRow key={row.id}>
                        {row.cells.map((cell) => (
                          <TableCell key={cell.id}>{cell.value}</TableCell>
                        ))}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            )}
          </DataTable>
        </Tile>
      )}

      {/* ---------- module breakdown ---------- */}
      {byModule && byModule.modules.length > 0 && (
        <Tile className="card" style={{ padding: "1.25rem" }}>
          <div
            className="table-header-row"
            style={{ cursor: "pointer" }}
            onClick={() => setModuleExpanded(!moduleExpanded)}
          >
            <h3 style={{ margin: 0, display: "flex", alignItems: "center", gap: "0.5rem", flexWrap: "wrap" }}>
              {moduleExpanded ? "▾" : "▸"} Module Breakdown
              <span style={{ fontSize: "0.85rem", fontWeight: 400, color: "#64748b" }}>
                {byModule.totalModules} module{byModule.totalModules !== 1 ? "s" : ""}
              </span>
              <Tag type="warm-gray" size="sm">Max depth: {byModule.maxDepth}</Tag>
              {byModule.maxDepth >= 3 && (
                <Tag type="red" size="sm">Deeply nested — review before migration</Tag>
              )}
            </h3>
          </div>

          {moduleExpanded && (
            <div style={{ marginTop: "0.75rem" }}>
              {byModule.maxDepth >= 3 && (
                <p className="helper-text" style={{ marginBottom: "0.75rem", color: "#da1e28" }}>
                  Deeply nested modules (depth ≥ 3) may require refactoring before migration.
                  See <a href="https://developer.hashicorp.com/terraform/language/modules/develop/structure" target="_blank" rel="noopener noreferrer">HashiCorp module best practices</a>.
                </p>
              )}
              <DataTable
                rows={byModule.modules.map((mod, idx) => ({
                  id: `mod-${idx}`,
                  path: mod.path,
                  depth: String(mod.depth),
                  billableRum: String(mod.rum),
                  resourceCount: String(mod.resourceCount),
                  resourceTypes: mod.resourceTypes.length <= 5
                    ? mod.resourceTypes.join(", ")
                    : `${mod.resourceTypes.slice(0, 5).join(", ")} +${mod.resourceTypes.length - 5} more`
                }))}
                headers={[
                  { key: "path", header: "Module Path" },
                  { key: "depth", header: "Depth" },
                  { key: "billableRum", header: "Billable RUM" },
                  { key: "resourceCount", header: "Resources" },
                  { key: "resourceTypes", header: "Resource Types" }
                ]}
              >
                {({ rows, headers, getHeaderProps, getTableProps }) => (
                  <TableContainer>
                    <Table {...getTableProps()} size="sm">
                      <TableHead>
                        <TableRow>
                          {headers.map((header) => {
                            const { key: _key, ...headerProps } = getHeaderProps({ header });
                            return (
                              <TableHeader key={header.key} {...headerProps}>
                                {header.header}
                              </TableHeader>
                            );
                          })}
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {rows.map((row) => {
                          const mod = byModule.modules[parseInt(row.id.replace("mod-", ""))];
                          return (
                            <TableRow key={row.id}>
                              {row.cells.map((cell) => (
                                <TableCell key={cell.id}>
                                  {cell.info.header === "path" ? (
                                    <span style={{ display: "flex", alignItems: "center", gap: "0.4rem" }}>
                                      <code style={{ fontSize: "0.8rem" }}>{cell.value}</code>
                                      {mod && mod.depth >= 3 && <Tag type="red" size="sm">deep</Tag>}
                                    </span>
                                  ) : cell.value}
                                </TableCell>
                              ))}
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </TableContainer>
                )}
              </DataTable>
            </div>
          )}
        </Tile>
      )}

      {/* ---------- workspace table ---------- */}
      {workspaces.length > 0 && (
        <Tile className="card" style={{ padding: "1.25rem" }}>
          <div className="table-header-row">
            <h3 style={{ margin: 0 }}>Workspace Breakdown</h3>
            <div className="table-actions">
              {runId && (
                <>
                  <Button
                    kind="tertiary"
                    size="sm"
                    onClick={() => window.open(getTfeMigrationExportUrl(runId, "csv"), "_blank")}
                  >
                    Export CSV
                  </Button>
                  <Button
                    kind="tertiary"
                    size="sm"
                    onClick={() => window.open(getTfeMigrationExportUrl(runId, "json"), "_blank")}
                  >
                    Export JSON
                  </Button>
                </>
              )}
            </div>
          </div>

          <DataTable rows={wsRows} headers={wsHeaders}>
            {({ rows, headers, getHeaderProps, getTableProps }) => (
              <TableContainer>
                <Table {...getTableProps()}>
                  <TableHead>
                    <TableRow>
                      {headers.map((header) => {
                        const { key: _key, ...headerProps } = getHeaderProps({ header });
                        return (
                          <TableHeader key={header.key} {...headerProps}>
                            {header.header}
                          </TableHeader>
                        );
                      })}
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {rows.map((row) => (
                      <TableRow key={row.id}>
                        {row.cells.map((cell) => (
                          <TableCell key={cell.id}>{cell.value}</TableCell>
                        ))}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            )}
          </DataTable>
        </Tile>
      )}
    </div>
  );
}
