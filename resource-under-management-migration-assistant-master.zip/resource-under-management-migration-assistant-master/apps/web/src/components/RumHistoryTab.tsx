import { useState } from "react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  Legend,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis
} from "recharts";
import {
  ActionableNotification,
  Button,
  Checkbox,
  DataTable,
  InlineLoading,
  InlineNotification,
  PasswordInput,
  ProgressBar,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableHeader,
  TableRow,
  Tag,
  TextInput,
  Tile
} from "@carbon/react";
import {
  startRumHistoryRun,
  getRumHistoryRun,
  type RumHistoryRun,
  type RumHistoryResultDto,
  type RumMonthlyPeak
} from "../lib/api";
import { buildSummaryExport, RUM_HISTORY_DISCLAIMER } from "./rum-history-export";

type LoadIntoPackSizingPayload = {
  monthlyValues: number[];
  growthPct: number | null;
};

export function RumHistoryTab({
  onLoadIntoPackSizing
}: {
  onLoadIntoPackSizing: (payload: LoadIntoPackSizingPayload) => void;
}) {
  /* ---------- form state ---------- */
  const [tfeHostname, setTfeHostname] = useState("");
  const [tfeToken, setTfeToken] = useState("");
  const [organization, setOrganization] = useState("");
  const [workspaceFilter, setWorkspaceFilter] = useState("");
  const [tlsInsecure, setTlsInsecure] = useState(false);

  /* ---------- run state ---------- */
  const [isRunning, setIsRunning] = useState(false);
  const [runId, setRunId] = useState<string | null>(null);
  const [status, setStatus] = useState<string>("");
  const [progress, setProgress] = useState<RumHistoryRun["progress"]>(undefined);
  const [message, setMessage] = useState("");

  /* ---------- result state ---------- */
  const [result, setResult] = useState<RumHistoryResultDto | null>(null);

  /* ---------- polling ---------- */
  async function pollRun(id: string) {
    for (let i = 0; i < 300; i += 1) {
      const run = await getRumHistoryRun(id);
      setStatus(run.status);
      if (run.progress) {
        setProgress(run.progress);
      }

      if (run.status === "completed") {
        setResult(run.result ?? null);
        setMessage(`RUM history run ${id} completed.`);
        return;
      }
      if (run.status === "failed") {
        setMessage(`RUM history run ${id} failed: ${run.errorMessage ?? "unknown error"}`);
        return;
      }
      await new Promise((resolve) => setTimeout(resolve, 1000));
    }
    setMessage(`RUM history run ${id} timed out after 5 minutes.`);
  }

  /* ---------- submit ---------- */
  async function handleRun() {
    if (!tfeHostname || !tfeToken || !organization) return;

    setIsRunning(true);
    setMessage("");
    setResult(null);
    setStatus("queued");
    setProgress(undefined);

    try {
      const created = await startRumHistoryRun({
        tfeHostname: tfeHostname.replace(/\/+$/, ""),
        tfeToken,
        organization,
        workspaceFilter: workspaceFilter || undefined,
        tlsInsecure: tlsInsecure || undefined
      });
      setRunId(created.id);
      setMessage(`Run ${created.id} queued — connecting to TFE...`);
      await pollRun(created.id);
    } catch (error) {
      const msg = error instanceof Error ? error.message : String(error);
      setMessage(`Error: ${msg}`);
    } finally {
      setIsRunning(false);
    }
  }

  /* ---------- validation ---------- */
  const canRun = Boolean(tfeHostname && tfeToken && organization && !isRunning);

  /* ---------- progress label ---------- */
  function progressLabel(): string {
    if (!progress) return status;
    switch (progress.phase) {
      case "connecting":
        return "Connecting to TFE...";
      case "listing_workspaces":
        return "Listing workspaces...";
      case "listing_versions":
        return `Listing state versions (${progress.workspacesProcessed ?? 0} / ${progress.workspacesFound ?? "?"})...`;
      case "reconstructing":
        return "Reconstructing history...";
      default:
        return status;
    }
  }

  /* ---------- derived values ---------- */
  const workspaceErrors = progress?.workspaceErrors ?? 0;

  function monthlyValuesForPackSizing(monthlyPeaks: RumMonthlyPeak[]): number[] {
    const fullMonths = monthlyPeaks.filter((p) => p.coverage === "full");
    const rums = fullMonths.map((p) => p.rum);
    const last12 = rums.slice(-12);
    const padCount = Math.max(0, 12 - last12.length);
    return [...Array(padCount).fill(0), ...last12];
  }

  function handleLoadIntoPackSizing() {
    if (!result) return;
    onLoadIntoPackSizing({
      monthlyValues: monthlyValuesForPackSizing(result.monthlyPeaks),
      growthPct: result.derivedAnnualGrowthPct
    });
  }

  function buildMonthlyCsv(monthlyPeaks: RumMonthlyPeak[]): string {
    const header = "month,rum,coverage";
    const lines = monthlyPeaks.map((row) => `${row.month},${row.rum},${row.coverage}`);
    return [header, ...lines].join("\n");
  }

  function handleDownloadCsv() {
    if (!result) return;
    const csv = buildMonthlyCsv(result.monthlyPeaks);
    const dataUrl = `data:text/csv;charset=utf-8,${encodeURIComponent(csv)}`;
    const link = document.createElement("a");
    link.href = dataUrl;
    link.download = `rum-history-monthly-${organization || "org"}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  function handleDownloadSummary() {
    if (!result) return;
    const payload = buildSummaryExport(
      {
        organization,
        result,
        workspacesFound: progress?.workspacesFound,
        workspaceErrors: progress?.workspaceErrors
      },
      __APP_VERSION__
    );
    const json = JSON.stringify(payload, null, 2);
    const dataUrl = `data:application/json;charset=utf-8,${encodeURIComponent(json)}`;
    const link = document.createElement("a");
    link.href = dataUrl;
    const date = new Date().toISOString().slice(0, 10);
    link.download = `rum-history-summary-${organization || "org"}-${date}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  /* ---------- monthly table ---------- */
  const monthlyHeaders = [
    { key: "month", header: "Month" },
    { key: "rum", header: "Peak RUM" },
    { key: "coverage", header: "Coverage" }
  ];

  const monthlyRows = (result?.monthlyPeaks ?? []).map((row, idx) => ({
    id: `month-${idx}`,
    month: row.month,
    rum: String(row.rum),
    coverage: row.coverage
  }));

  /* ---------- workspace + provider derived values ---------- */
  const dailyWorkspaces = result?.dailyWorkspaces ?? [];
  const dailyByProvider = result?.dailyByProvider ?? [];
  const currentWorkspaces = dailyWorkspaces.length
    ? dailyWorkspaces[dailyWorkspaces.length - 1].count
    : 0;
  const latestProviderDay = dailyByProvider.length ? dailyByProvider[dailyByProvider.length - 1] : null;
  const providerKeys = [
    ...new Set(dailyByProvider.flatMap((day) => Object.keys(day).filter((key) => key !== "date")))
  ].sort();
  const providerColors = ["#0f62fe", "#08bdba", "#8a3ffc", "#ff832b", "#d12771", "#24a148"];

  function providerColor(index: number): string {
    return providerColors[index % providerColors.length];
  }

  return (
    <div style={{ display: "grid", gap: "1rem" }}>
      {/* ---------- connection form ---------- */}
      <Tile className="card" style={{ padding: "1.25rem" }}>
        <h3 style={{ margin: "0 0 0.75rem" }}>TFE RUM History Reconstruction</h3>
        <p className="helper-text" style={{ marginBottom: "1rem" }}>
          Connect to a Terraform Enterprise instance to reconstruct historical daily and monthly RUM
          high-water marks from state version history — an auditable record of your usage before you
          move to RUM-based pricing.
        </p>

        <div className="wizard-form">
          <TextInput
            id="rum-history-hostname"
            labelText="TFE Hostname"
            placeholder="https://tfe.company.com"
            value={tfeHostname}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTfeHostname(e.target.value)}
            disabled={isRunning}
          />
          <PasswordInput
            id="rum-history-token"
            labelText="TFE API Token"
            placeholder="Workspace-scoped or team token with read access"
            value={tfeToken}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTfeToken(e.target.value)}
            disabled={isRunning}
            hidePasswordLabel="Hide token"
            showPasswordLabel="Show token"
          />
          <TextInput
            id="rum-history-org"
            labelText="Organization"
            placeholder="my-org"
            value={organization}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setOrganization(e.target.value)}
            disabled={isRunning}
          />
          <TextInput
            id="rum-history-workspace-filter"
            labelText="Workspace Filter (optional)"
            placeholder="Search by workspace name"
            value={workspaceFilter}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setWorkspaceFilter(e.target.value)}
            disabled={isRunning}
          />
          <Checkbox
            id="rum-history-tls-insecure"
            labelText="Allow self-signed TLS certificates"
            checked={tlsInsecure}
            onChange={(_: unknown, { checked }: { checked: boolean }) => setTlsInsecure(checked)}
            disabled={isRunning}
          />
        </div>

        <div className="wizard-actions" style={{ marginTop: "1rem" }}>
          <Button kind="primary" onClick={handleRun} disabled={!canRun}>
            {isRunning ? "Running..." : "Reconstruct RUM History"}
          </Button>
        </div>
      </Tile>

      {/* ---------- status panel ---------- */}
      {isRunning && (
        <Tile className="card" style={{ padding: "1.25rem" }}>
          {progress?.workspacesFound && progress.workspacesFound > 0 ? (
            <>
              <ProgressBar
                label={progressLabel()}
                value={Math.round(((progress.workspacesProcessed ?? 0) / progress.workspacesFound) * 100)}
                max={100}
                status="active"
                size="big"
              />
              {progress.workspacesProcessed !== undefined && (
                <p style={{ fontSize: "0.8rem", color: "#6f6f6f", marginTop: "0.4rem" }}>
                  {progress.workspacesProcessed.toLocaleString()} / {progress.workspacesFound.toLocaleString()} workspaces
                </p>
              )}
            </>
          ) : (
            <InlineLoading description={progressLabel()} status="active" />
          )}
          {runId && <p style={{ fontSize: "0.8rem", color: "#6f6f6f", marginTop: "0.4rem" }}>Run ID: {runId}</p>}
        </Tile>
      )}

      {!isRunning && message && (message.includes("failed") || message.includes("timed out")) && (
        <ActionableNotification
          kind="error"
          title="RUM History Reconstruction Failed"
          subtitle={message}
          lowContrast
          inline
          actionButtonLabel="Retry"
          onActionButtonClick={handleRun}
          hideCloseButton
        />
      )}

      {!isRunning && result && (
        <>
          {workspaceErrors > 0 && (
            <InlineNotification
              kind="warning"
              lowContrast
              title="Some workspaces were skipped"
              subtitle={`${workspaceErrors.toLocaleString()} workspace${workspaceErrors === 1 ? "" : "s"} could not be processed and are excluded from this history. The daily and monthly peaks below reflect only the workspaces that were successfully read.`}
            />
          )}

          {result.fullMonths === 0 && (
            <InlineNotification
              kind="warning"
              lowContrast
              title="Not enough history yet"
              subtitle="There isn't a full calendar month of state history for this organization yet, so the billable annual average is 0 and the Pack Sizing prefill is disabled."
            />
          )}

          {/* ---------- daily peak chart ---------- */}
          <Tile className="card" style={{ padding: "1.25rem" }}>
            <h3 style={{ margin: "0 0 0.75rem" }}>Daily Peak RUM</h3>
            <ResponsiveContainer width="100%" height={320}>
              <LineChart data={result.dailyPeaks}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip formatter={(value) => (typeof value === "number" ? value.toLocaleString() : String(value ?? ""))} />
                <Line type="monotone" dataKey="rum" stroke="#0f62fe" dot={false} strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </Tile>

          {/* ---------- workspaces/day chart ---------- */}
          <Tile className="card" style={{ padding: "1.25rem" }}>
            <h3 style={{ margin: "0 0 0.75rem" }}>Workspaces / Day</h3>
            <ResponsiveContainer width="100%" height={240}>
              <LineChart data={dailyWorkspaces}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
                <Tooltip formatter={(value) => (typeof value === "number" ? value.toLocaleString() : String(value ?? ""))} />
                <Line type="monotone" dataKey="count" name="Workspaces" stroke="#24a148" dot={false} strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
            <p className="helper-text" style={{ marginTop: "0.5rem" }}>
              Workspace deletions are not visible in state-version history — this count reflects workspaces
              with at least one recorded state version on or before that day and will never decrease.
            </p>
          </Tile>

          {/* ---------- provider RUM stacked chart ---------- */}
          {providerKeys.length > 0 && (
            <Tile className="card" style={{ padding: "1.25rem" }}>
              <h3 style={{ margin: "0 0 0.75rem" }}>Billable RUM by Provider / Day</h3>
              <ResponsiveContainer width="100%" height={320}>
                <AreaChart data={dailyByProvider}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip formatter={(value) => (typeof value === "number" ? value.toLocaleString() : String(value ?? ""))} />
                  <Legend />
                  {providerKeys.map((provider, idx) => (
                    <Area
                      key={provider}
                      type="monotone"
                      dataKey={provider}
                      name={provider}
                      stackId="providers"
                      stroke={providerColor(idx)}
                      fill={providerColor(idx)}
                    />
                  ))}
                </AreaChart>
              </ResponsiveContainer>
              <p className="helper-text" style={{ marginTop: "0.5rem" }}>
                Only state versions with a recorded provider breakdown contribute here; older accumulated
                events without one still count toward total RUM above but are not attributable to a provider.
              </p>
            </Tile>
          )}

          {/* ---------- totals tiles ---------- */}
          <Tile className="card" style={{ padding: "1.25rem" }}>
            <h3 style={{ margin: "0 0 0.75rem" }}>Current Workspaces &amp; Provider Totals</h3>
            <div className="kpi-grid-inline">
              <div>
                <h4>Current Workspaces</h4>
                <p style={{ fontSize: "2rem", fontWeight: 600 }}>{currentWorkspaces.toLocaleString()}</p>
              </div>
              {providerKeys.map((provider) => (
                <div key={provider}>
                  <h4>{provider} (billable RUM, latest day)</h4>
                  <p style={{ fontSize: "1.5rem", fontWeight: 600 }}>
                    {Math.round(Number(latestProviderDay?.[provider] ?? 0)).toLocaleString()}
                  </p>
                </div>
              ))}
            </div>
            <p className="helper-text" style={{ marginTop: "0.75rem" }}>
              Workspace deletions are not visible in state-version history.
            </p>
          </Tile>

          {/* ---------- monthly peak table ---------- */}
          <Tile className="card" style={{ padding: "1.25rem" }}>
            <div className="table-header-row">
              <h3 style={{ margin: 0 }}>Monthly Peak RUM</h3>
              <div className="table-actions">
                <Button kind="tertiary" size="sm" onClick={handleDownloadCsv}>
                  Export CSV
                </Button>
                <Button kind="tertiary" size="sm" onClick={handleDownloadSummary}>
                  Export Summary (JSON)
                </Button>
              </div>
            </div>
            <DataTable rows={monthlyRows} headers={monthlyHeaders}>
              {({ rows, headers, getHeaderProps, getTableProps }) => (
                <TableContainer>
                  <Table {...getTableProps()}>
                    <TableHead>
                      <TableRow>
                        {headers.map((header) => {
                          const { key: _key, ...headerProps } = getHeaderProps({ header });
                          return (
                            <TableHeader key={header.key} {...headerProps}>
                              {header.header}
                            </TableHeader>
                          );
                        })}
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {rows.map((row) => {
                        const monthly = result.monthlyPeaks[parseInt(row.id.replace("month-", ""), 10)];
                        return (
                          <TableRow key={row.id}>
                            {row.cells.map((cell) => (
                              <TableCell key={cell.id}>
                                {cell.info.header === "coverage" ? (
                                  <span style={{ display: "flex", alignItems: "center", gap: "0.4rem" }}>
                                    {cell.value}
                                    {monthly?.coverage === "partial" && (
                                      <Tag type="warm-gray" size="sm">partial</Tag>
                                    )}
                                  </span>
                                ) : (
                                  cell.value
                                )}
                              </TableCell>
                            ))}
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </TableContainer>
              )}
            </DataTable>
          </Tile>

          {/* ---------- billable total ---------- */}
          <Tile className="card" style={{ padding: "1.25rem" }}>
            <h3 style={{ margin: "0 0 0.75rem" }}>Billable RUM</h3>
            <p className="helper-text" style={{ marginTop: 0, marginBottom: "0.75rem" }}>
              {RUM_HISTORY_DISCLAIMER}
            </p>
            <div className="kpi-grid-inline">
              <div>
                <h4>Trailing 12 months (billable run-rate)</h4>
                <p style={{ fontSize: "2rem", fontWeight: 600 }}>{result.trailing12Average.toLocaleString()}</p>
              </div>
              <div>
                <h4>All-history average</h4>
                <p>{result.annualAverage.toLocaleString()}</p>
              </div>
              <div>
                <h4>Year-over-Year Growth</h4>
                <p>
                  {result.derivedAnnualGrowthPct === null
                    ? "—"
                    : `${result.derivedAnnualGrowthPct > 0 ? "+" : ""}${result.derivedAnnualGrowthPct.toFixed(1)}%`}
                </p>
              </div>
            </div>
            <p className="helper-text" style={{ marginTop: "0.75rem" }}>
              Trailing 12 months is the average of the last {Math.min(result.fullMonths, 12)} full-month high-water
              mark{Math.min(result.fullMonths, 12) === 1 ? "" : "s"}; all-history average is the average of all{" "}
              {result.fullMonths} full-month high-water mark{result.fullMonths === 1 ? "" : "s"}. HCP Terraform
              bills on the average of the monthly high-water marks across full calendar months — partial months
              are excluded from both figures.
            </p>

            <div className="wizard-actions" style={{ marginTop: "1rem" }}>
              <Button
                kind="primary"
                onClick={handleLoadIntoPackSizing}
                disabled={result.fullMonths === 0}
              >
                Load into Pack Sizing
              </Button>
            </div>
            <p className="helper-text" style={{ marginTop: "0.5rem" }}>
              Loads the last 12 full months (missing months as 0).
            </p>
          </Tile>
        </>
      )}
    </div>
  );
}
