export type PackSizingPrefill = {
  monthlyValues: number[];
  growthPct: number | null;
};

export type AppliedPrefill = {
  useMonthlyMode: boolean;
  monthlyValues: number[];
  forecastGrowthPct?: number;
};

export function applyPrefill(prefill: PackSizingPrefill): AppliedPrefill {
  const result: AppliedPrefill = {
    useMonthlyMode: true,
    monthlyValues: prefill.monthlyValues,
  };

  if (prefill.growthPct != null) {
    result.forecastGrowthPct = Math.round(prefill.growthPct);
  }

  return result;
}
