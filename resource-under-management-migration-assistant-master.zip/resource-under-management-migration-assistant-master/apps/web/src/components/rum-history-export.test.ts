import { describe, expect, it } from "vitest";
import { buildSummaryExport, RUM_HISTORY_DISCLAIMER } from "./rum-history-export";
import type { RumHistoryResultDto } from "../lib/api";

function makeResult(overrides: Partial<RumHistoryResultDto> = {}): RumHistoryResultDto {
  return {
    dailyPeaks: [{ date: "2026-06-01", rum: 100 }],
    monthlyPeaks: [{ month: "2026-06", rum: 100, coverage: "full" }],
    annualAverage: 90,
    trailing12Average: 95,
    fullMonths: 12,
    derivedAnnualGrowthPct: 12.5,
    historyStart: "2025-06-01",
    historyEnd: "2026-06-30",
    dailyWorkspaces: [
      { date: "2026-06-01", count: 10 },
      { date: "2026-06-02", count: 12 }
    ],
    dailyByProvider: [
      { date: "2026-06-01", aws: 60, azure: 40 },
      { date: "2026-06-02", aws: 70, azure: 45 }
    ],
    ...overrides
  };
}

describe("buildSummaryExport", () => {
  it("includes all required fields", () => {
    const payload = buildSummaryExport(
      { organization: "acme-corp", result: makeResult(), workspacesFound: 42, workspaceErrors: 1 },
      "0.1.0"
    );

    expect(payload.organization).toBe("acme-corp");
    expect(payload.toolVersion).toBe("0.1.0");
    expect(typeof payload.generatedAt).toBe("string");
    expect(payload.historyStart).toBe("2025-06-01");
    expect(payload.historyEnd).toBe("2026-06-30");
    expect(payload.fullMonths).toBe(12);
    expect(payload.annualAverage).toBe(90);
    expect(payload.trailing12Average).toBe(95);
    expect(payload.derivedAnnualGrowthPct).toBe(12.5);
    expect(payload.monthlyPeaks).toEqual([{ month: "2026-06", rum: 100, coverage: "full" }]);
    expect(payload.workspacesFound).toBe(42);
    expect(payload.workspaceErrors).toBe(1);
  });

  it("sets the exact disclaimer string", () => {
    const payload = buildSummaryExport({ organization: "acme-corp", result: makeResult() }, "0.1.0");
    expect(payload.disclaimer).toBe(
      "Reconstruction estimate derived from Terraform state-version history. Not a quote or invoice figure."
    );
    expect(payload.disclaimer).toBe(RUM_HISTORY_DISCLAIMER);
  });

  it("derives currentWorkspaces from the latest dailyWorkspaces entry", () => {
    const payload = buildSummaryExport({ organization: "acme-corp", result: makeResult() }, "0.1.0");
    expect(payload.currentWorkspaces).toBe(12);
  });

  it("derives providerTotals from the latest dailyByProvider entry, excluding date", () => {
    const payload = buildSummaryExport({ organization: "acme-corp", result: makeResult() }, "0.1.0");
    expect(payload.providerTotals).toEqual({ aws: 70, azure: 45 });
  });

  it("never includes credentials or internal hostnames", () => {
    const payload = buildSummaryExport(
      { organization: "acme-corp", result: makeResult(), workspacesFound: 1, workspaceErrors: 0 },
      "0.1.0"
    );
    const keys = Object.keys(payload);
    expect(keys).not.toContain("tfeToken");
    expect(keys).not.toContain("tfeHostname");
    expect(JSON.stringify(payload)).not.toMatch(/tfeToken|tfeHostname/i);
  });

  it("gracefully handles missing dailyWorkspaces/dailyByProvider (older records)", () => {
    const result = makeResult({ dailyWorkspaces: [], dailyByProvider: [] });
    const payload = buildSummaryExport({ organization: "acme-corp", result }, "0.1.0");
    expect(payload.currentWorkspaces).toBeUndefined();
    expect(payload.providerTotals).toBeUndefined();
  });

  it("gracefully handles undefined dailyWorkspaces/dailyByProvider fields entirely", () => {
    const result = makeResult();
    // Simulate an older persisted record that predates these fields.
    delete (result as Partial<RumHistoryResultDto>).dailyWorkspaces;
    delete (result as Partial<RumHistoryResultDto>).dailyByProvider;
    const payload = buildSummaryExport({ organization: "acme-corp", result }, "0.1.0");
    expect(payload.currentWorkspaces).toBeUndefined();
    expect(payload.providerTotals).toBeUndefined();
  });

  it("omits workspacesFound/workspaceErrors when not provided", () => {
    const payload = buildSummaryExport({ organization: "acme-corp", result: makeResult() }, "0.1.0");
    expect(payload.workspacesFound).toBeUndefined();
    expect(payload.workspaceErrors).toBeUndefined();
  });
});
