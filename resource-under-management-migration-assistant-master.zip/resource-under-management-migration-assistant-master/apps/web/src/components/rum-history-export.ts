import type { RumHistoryResultDto } from "../lib/api";

/** The exact disclaimer string shown to customers alongside every exported/rendered RUM figure. */
export const RUM_HISTORY_DISCLAIMER =
  "Reconstruction estimate derived from Terraform state-version history. Not a quote or invoice figure.";

export type RumHistorySummaryExportInput = {
  organization: string;
  result: RumHistoryResultDto;
  workspacesFound?: number;
  workspaceErrors?: number;
};

export type RumHistorySummaryExport = {
  organization: string;
  generatedAt: string;
  toolVersion: string;
  disclaimer: string;
  historyStart: string | null;
  historyEnd: string | null;
  fullMonths: number;
  annualAverage: number;
  trailing12Average: number;
  derivedAnnualGrowthPct: number | null;
  monthlyPeaks: RumHistoryResultDto["monthlyPeaks"];
  workspacesFound?: number;
  workspaceErrors?: number;
  currentWorkspaces?: number;
  providerTotals?: Record<string, number>;
};

/**
 * Builds the customer-shareable RUM history summary payload.
 *
 * Pure function: no DOM/browser APIs, no credentials or hostnames — safe to unit test and safe to
 * hand to a customer. NEVER add tfeToken/tfeHostname or any other connection detail here.
 */
export function buildSummaryExport(
  run: RumHistorySummaryExportInput,
  toolVersion: string
): RumHistorySummaryExport {
  const { organization, result, workspacesFound, workspaceErrors } = run;

  const dailyWorkspaces = result.dailyWorkspaces ?? [];
  const currentWorkspaces = dailyWorkspaces.length
    ? dailyWorkspaces[dailyWorkspaces.length - 1].count
    : undefined;

  const dailyByProvider = result.dailyByProvider ?? [];
  const latestProviderDay = dailyByProvider.length
    ? dailyByProvider[dailyByProvider.length - 1]
    : undefined;
  let providerTotals: Record<string, number> | undefined;
  if (latestProviderDay) {
    providerTotals = {};
    for (const [key, value] of Object.entries(latestProviderDay)) {
      if (key === "date") continue;
      providerTotals[key] = Math.round(Number(value ?? 0));
    }
  }

  const payload: RumHistorySummaryExport = {
    organization,
    generatedAt: new Date().toISOString(),
    toolVersion,
    disclaimer: RUM_HISTORY_DISCLAIMER,
    historyStart: result.historyStart,
    historyEnd: result.historyEnd,
    fullMonths: result.fullMonths,
    annualAverage: result.annualAverage,
    trailing12Average: result.trailing12Average,
    derivedAnnualGrowthPct: result.derivedAnnualGrowthPct,
    monthlyPeaks: result.monthlyPeaks
  };

  if (workspacesFound !== undefined) payload.workspacesFound = workspacesFound;
  if (workspaceErrors !== undefined) payload.workspaceErrors = workspaceErrors;
  if (currentWorkspaces !== undefined) payload.currentWorkspaces = currentWorkspaces;
  if (providerTotals !== undefined) payload.providerTotals = providerTotals;

  return payload;
}
