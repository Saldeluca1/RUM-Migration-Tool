import { useState } from "react";
import { Button, InlineLoading, InlineNotification, Tile } from "@carbon/react";
import { startScan, getScan } from "../lib/api";

type Section = "overview" | "demo" | "faq" | "security" | "reference";
type TabId = "managed" | "unmanaged" | "tfe" | "pack" | "reporting" | "guide";

const NAV_ITEMS: { id: Section; label: string }[] = [
  { id: "overview", label: "Overview" },
  { id: "demo", label: "Sample Data Walkthrough" },
  { id: "faq", label: "FAQ" },
  { id: "security", label: "Security & Trust" },
  { id: "reference", label: "Quick Reference" },
];

export function SEGuideTab({
  onNavigate,
  onDemoLoaded,
}: {
  onNavigate: (tab: TabId) => void;
  onDemoLoaded: () => void;
}) {
  const [activeSection, setActiveSection] = useState<Section>("overview");
  const [demoStatus, setDemoStatus] = useState<"idle" | "running" | "done" | "error">("idle");
  const [demoMessage, setDemoMessage] = useState("");
  const [fixturesPath, setFixturesPath] = useState("fixtures/synthetic");

  async function handleLoadDemo() {
    setDemoStatus("running");
    setDemoMessage("");
    try {
      const created = await startScan({
        providers: ["local"],
        targets: [{ provider: "local", directoryPath: fixturesPath, recursive: true, patterns: ["*.tfstate.json"] }],
        options: { maxObjects: 10000 }
      });

      for (let i = 0; i < 120; i++) {
        const scan = await getScan(created.id);
        if (scan.status === "completed") {
          const rum = scan.summary?.totalRum ?? 0;
          const files = scan.summary?.stateFilesParsed ?? 0;
          setDemoStatus("done");
          setDemoMessage(`Sample data loaded — ${rum.toLocaleString()} RUM across ${files} synthetic state files.`);
          onDemoLoaded();
          setTimeout(() => onNavigate("managed"), 800);
          return;
        }
        if (scan.status === "failed") {
          setDemoStatus("error");
          setDemoMessage(scan.errorMessage ?? "Sample scan failed.");
          return;
        }
        await new Promise((r) => setTimeout(r, 1000));
      }
      setDemoStatus("error");
      setDemoMessage("Sample scan timed out.");
    } catch (err) {
      setDemoStatus("error");
      setDemoMessage(err instanceof Error ? err.message : "Failed to start sample scan.");
    }
  }

  return (
    <div style={{ display: "flex", gap: "1.5rem", alignItems: "flex-start" }}>
      {/* Sidebar nav */}
      <Tile className="card" style={{ minWidth: "200px", padding: "1rem", flexShrink: 0 }}>
        <p style={{ fontSize: "0.75rem", fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.08em", color: "#6f6f6f", marginBottom: "0.75rem" }}>
          Engineer Guide
        </p>
        {NAV_ITEMS.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setActiveSection(item.id)}
            style={{
              display: "block",
              width: "100%",
              textAlign: "left",
              padding: "0.5rem 0.75rem",
              marginBottom: "0.25rem",
              border: "none",
              borderRadius: "4px",
              background: activeSection === item.id ? "#e8f1ff" : "transparent",
              color: activeSection === item.id ? "#0043ce" : "#161616",
              fontWeight: activeSection === item.id ? 600 : 400,
              fontSize: "0.875rem",
              cursor: "pointer",
            }}
          >
            {item.label}
          </button>
        ))}
      </Tile>

      {/* Content */}
      <div style={{ flex: 1, minWidth: 0 }}>
        {activeSection === "overview" && (
          <Tile className="card" style={{ padding: "1.5rem" }}>
            <h2 style={{ marginTop: 0 }}>What is this tool?</h2>
            <p>
              The <strong>TFC RUM Calculator</strong> answers the question you have before migrating to HCP Terraform:
              <em> "What will my RUM bill actually be?"</em>
            </p>
            <p>
              Resources Under Management (RUM) is the billing unit for HCP Terraform Cloud and the upcoming TFE billing model.
              It counts managed resource <em>instances</em> in Terraform state — not workspaces, not resource blocks, instances.
            </p>

            <h3>Three scan modes, one answer</h3>
            <div style={{ display: "grid", gap: "0.75rem", marginBottom: "1rem" }}>
              <div style={{ padding: "0.75rem 1rem", background: "#f4f4f4", borderLeft: "3px solid #0f62fe", borderRadius: "0 4px 4px 0" }}>
                <strong>Managed State Scanner</strong> — Scans existing Terraform state files from S3, Azure Blob, GCP GCS, or local disk.
                Gives the exact RUM count for resources already managed by Terraform. Use this when you already have existing TF state.
              </div>
              <div style={{ padding: "0.75rem 1rem", background: "#f4f4f4", borderLeft: "3px solid #a56eff", borderRadius: "0 4px 4px 0" }}>
                <strong>Unmanaged Estimator</strong> — Discovers cloud resources <em>not yet</em> in Terraform state and estimates how many
                would become RUM if adopted. Use this to size a cloud-to-IaC migration.
              </div>
              <div style={{ padding: "0.75rem 1rem", background: "#f4f4f4", borderLeft: "3px solid #24a148", borderRadius: "0 4px 4px 0" }}>
                <strong>TFE Migration Estimator</strong> — Connects directly to any TFE or TFC instance via API, downloads all workspace
                state, and calculates current RUM. Use this to answer "what will I pay after migration?" if you're on TFE.
              </div>
            </div>

            <h3>Key things to know</h3>
            <ul>
              <li><strong>This is not an estimate — it's the real number.</strong> For managed state scans and TFE migration, the engine reads actual state files using the same logic TFC billing uses.</li>
              <li><strong>Nothing leaves your machine.</strong> All scans run locally. Cloud credentials are used once for discovery and never persisted.</li>
              <li><strong>Supports any migration direction.</strong> TFE→TFC, TFC→TFE, TFE→TFE, TFC audit — the TFE API v2 is bidirectional.</li>
              <li><strong>Pack Sizing is built in.</strong> After scanning, the tool applies IBM's 5-step methodology to recommend the right HCP Terraform pack tier.</li>
            </ul>
          </Tile>
        )}

        {activeSection === "demo" && (
          <div style={{ display: "grid", gap: "1rem" }}>
            <Tile className="card" style={{ padding: "1.5rem" }}>
              <h2 style={{ marginTop: 0 }}>Sample Data Walkthrough</h2>
              <p className="helper-text">
                Load synthetic data to walk through the tool without real cloud credentials. The sample scan uses 20 pre-built
                Terraform state files with known RUM counts (1,045 total RUM).
              </p>

              <div style={{ display: "flex", alignItems: "flex-end", gap: "0.75rem", flexWrap: "wrap", marginBottom: "1rem" }}>
                <div style={{ flex: 1, minWidth: "280px" }}>
                  <label htmlFor="fixtures-path" style={{ display: "block", fontSize: "0.75rem", fontWeight: 600, marginBottom: "0.25rem" }}>
                    Fixtures path (relative to API server root)
                  </label>
                  <input
                    id="fixtures-path"
                    type="text"
                    value={fixturesPath}
                    onChange={(e) => setFixturesPath(e.target.value)}
                    disabled={demoStatus === "running"}
                    style={{
                      width: "100%",
                      padding: "0.5rem 0.75rem",
                      border: "1px solid #8d8d8d",
                      background: "#fff",
                      fontSize: "0.875rem",
                      boxSizing: "border-box",
                    }}
                  />
                </div>
                <Button
                  kind="primary"
                  disabled={demoStatus === "running"}
                  onClick={handleLoadDemo}
                >
                  {demoStatus === "running" ? "Loading sample data…" : "Load Sample Data"}
                </Button>
              </div>

              {demoStatus === "running" && (
                <InlineLoading description="Scanning synthetic state files…" status="active" />
              )}
              {demoStatus === "done" && (
                <InlineNotification kind="success" title="Sample data loaded" subtitle={demoMessage} lowContrast hideCloseButton />
              )}
              {demoStatus === "error" && (
                <InlineNotification kind="error" title="Sample scan failed" subtitle={demoMessage} lowContrast hideCloseButton />
              )}
            </Tile>

            <Tile className="card" style={{ padding: "1.5rem" }}>
              <h3 style={{ marginTop: 0 }}>Step-by-step walkthrough</h3>

              <div style={{ display: "grid", gap: "1rem" }}>
                <div>
                  <div style={{ display: "flex", alignItems: "center", gap: "0.75rem", marginBottom: "0.5rem" }}>
                    <span style={{ background: "#0f62fe", color: "#fff", borderRadius: "50%", width: "1.5rem", height: "1.5rem", display: "inline-flex", alignItems: "center", justifyContent: "center", fontSize: "0.8rem", fontWeight: 700, flexShrink: 0 }}>1</span>
                    <strong>Load sample data → Managed State Scanner</strong>
                    <Button kind="ghost" size="sm" onClick={() => { onNavigate("managed"); }}>Go to tab →</Button>
                  </div>
                  <p className="helper-text" style={{ marginLeft: "2.25rem" }}>
                    Click "Load Sample Data" above. The scanner runs against synthetic state files and completes in under 5 seconds.
                    The Dashboard below the wizard shows 1,045 total RUM, 20 state files, and a resource breakdown by rule code.
                    Watch for the <em>count/for_each expansion</em> warning — this is the most common billing surprise.
                  </p>
                </div>

                <div>
                  <div style={{ display: "flex", alignItems: "center", gap: "0.75rem", marginBottom: "0.5rem" }}>
                    <span style={{ background: "#0f62fe", color: "#fff", borderRadius: "50%", width: "1.5rem", height: "1.5rem", display: "inline-flex", alignItems: "center", justifyContent: "center", fontSize: "0.8rem", fontWeight: 700, flexShrink: 0 }}>2</span>
                    <strong>Pack Sizing → Pack recommendation</strong>
                    <Button kind="ghost" size="sm" onClick={() => onNavigate("pack")}>Go to tab →</Button>
                  </div>
                  <p className="helper-text" style={{ marginLeft: "2.25rem" }}>
                    The Pack Sizing tab auto-populates from the scan total. Walk through the 6-step IBM methodology:
                    snapshot → peak multiplier → annual average → growth buffer → pack tier.
                    The recommended pack and headroom % are shown in the callout. Enable the 36-month forecast to show
                    when a tier upgrade would be needed.
                  </p>
                </div>

                <div>
                  <div style={{ display: "flex", alignItems: "center", gap: "0.75rem", marginBottom: "0.5rem" }}>
                    <span style={{ background: "#0f62fe", color: "#fff", borderRadius: "50%", width: "1.5rem", height: "1.5rem", display: "inline-flex", alignItems: "center", justifyContent: "center", fontSize: "0.8rem", fontWeight: 700, flexShrink: 0 }}>3</span>
                    <strong>TFE Migration → Connect to real instance</strong>
                    <Button kind="ghost" size="sm" onClick={() => onNavigate("tfe")}>Go to tab →</Button>
                  </div>
                  <p className="helper-text" style={{ marginLeft: "2.25rem" }}>
                    To connect to your real TFE or TFC instance, provide the hostname, a read-only API token, and
                    organization name. The estimator enumerates workspaces, downloads current state, and produces
                    a per-workspace RUM table. Use "By Project" scope to scope the estimate to a specific team or
                    environment. Export CSV to share with your HashiCorp account team.
                  </p>
                </div>

                <div>
                  <div style={{ display: "flex", alignItems: "center", gap: "0.75rem", marginBottom: "0.5rem" }}>
                    <span style={{ background: "#0f62fe", color: "#fff", borderRadius: "50%", width: "1.5rem", height: "1.5rem", display: "inline-flex", alignItems: "center", justifyContent: "center", fontSize: "0.8rem", fontWeight: 700, flexShrink: 0 }}>4</span>
                    <strong>Reporting → Cross-source breakdown</strong>
                    <Button kind="ghost" size="sm" onClick={() => onNavigate("reporting")}>Go to tab →</Button>
                  </div>
                  <p className="helper-text" style={{ marginLeft: "2.25rem" }}>
                    After running multiple scan types, the Reporting tab shows a unified view. Switch between sources
                    (Managed / Unmanaged / TFE) and dimensions (by provider, bucket, project, workspace). The insight
                    card auto-generates the headline stat you can share with your team.
                  </p>
                </div>
              </div>
            </Tile>
          </div>
        )}

        {activeSection === "faq" && (
          <Tile className="card" style={{ padding: "1.5rem" }}>
            <h2 style={{ marginTop: 0 }}>FAQ</h2>
            <div style={{ display: "grid", gap: "1.25rem" }}>
              {[
                {
                  q: "How accurate is this? Is it the same number the billing portal uses?",
                  a: "For Managed State and TFE Migration scans: yes, the calculation is exact. The engine reads the same Terraform state JSON that TFC billing reads, and applies the same exclusion rules (data sources, null_resource, terraform_data are excluded; managed resource instances are counted). For the Unmanaged Estimator: it's an estimate based on ARN/resource-type classification — useful for sizing IaC adoption conversations but not a billing guarantee.",
                },
                {
                  q: "What about resources not yet in Terraform?",
                  a: "That's what the Unmanaged Estimator tab is for. It discovers all resources in scope (by region, tag filter) using the cloud provider's resource tagging API, classifies each one against the Terraform provider schema, and estimates how many would count as RUM if adopted. The 'RUM Candidates' metric is the potential uplift from full IaC adoption.",
                },
                {
                  q: "What does Non-Billable mean?",
                  a: "Non-Billable resources are in Terraform state but don't count toward RUM billing. Specifically: data sources (mode: 'data'), null_resource, and terraform_data. These are common in large TF codebases. The tool surfaces the count so you aren't confused when your resource block count is higher than your RUM count.",
                },
                {
                  q: "Does the tool need special permissions or network access?",
                  a: "Managed state scans need read access to the state storage backend (S3 GetObject + ListBucket, Azure Blob read, etc.). TFE migration needs a TFE API token with workspace read access — a read-only team token scoped to the organization is sufficient. The Unmanaged Estimator needs resourcegroupstaggingapi:GetResources for AWS plus per-service read permissions. The IAM Remediation panel generates a minimal suggested policy automatically.",
                },
              ].map(({ q, a }) => (
                <div key={q} style={{ borderBottom: "1px solid #e0e0e0", paddingBottom: "1rem" }}>
                  <p style={{ fontWeight: 600, marginBottom: "0.4rem" }}>Q: {q}</p>
                  <p style={{ color: "#525252", margin: 0 }}>{a}</p>
                </div>
              ))}
            </div>
          </Tile>
        )}

        {activeSection === "security" && (
          <Tile className="card" style={{ padding: "1.5rem" }}>
            <h2 style={{ marginTop: 0 }}>Security & Trust</h2>

            <h3>Credential handling</h3>
            <div style={{ padding: "1rem", background: "#defbe6", borderLeft: "4px solid #24a148", borderRadius: "0 4px 4px 0", marginBottom: "1rem" }}>
              <strong>Credentials are never stored.</strong> AWS keys, TFE tokens, Azure credentials, and GCP credential paths
              are passed directly to the scan job and used once. They are redacted before the job record is written to disk.
              If you retrieve a scan record via API, the credentials are not present.
            </div>

            <h3>Data flow</h3>
            <ol>
              <li><strong>User submits form</strong> → credentials + scan config POSTed to local API server (port 8080)</li>
              <li><strong>API stores redacted record</strong> → original credentials passed only to the job function in memory</li>
              <li><strong>Job runs locally</strong> → invokes AWS CLI / TFE API / Azure CLI with the provided credentials</li>
              <li><strong>State files downloaded locally</strong> → parsed by the RUM engine on the local machine</li>
              <li><strong>Results stored locally</strong> → in <code>apps/api/data/</code> (runtime data, not committed to git)</li>
              <li><strong>Credentials discarded</strong> → after job completes, credentials are gone</li>
            </ol>

            <h3>Network boundary</h3>
            <ul>
              <li>The tool makes outbound calls to: your cloud provider APIs (AWS/Azure/GCP), your TFE hostname, and nothing else.</li>
              <li>No telemetry. No analytics. No external endpoints.</li>
              <li>For TFE instances with self-signed TLS: check "Allow self-signed TLS certificates" — this sets <code>NODE_TLS_REJECT_UNAUTHORIZED=0</code> for that single job only.</li>
            </ul>

            <h3>Deployment options</h3>
            <ul>
              <li><strong>Local dev</strong>: <code>npm run dev</code> — runs on localhost, your data never leaves your machine</li>
              <li><strong>Docker / Rancher Desktop</strong>: <code>nerdctl compose up</code> — containerized, non-root, health-checked</li>
              <li><strong>Air-gapped TFE</strong>: run on a machine with network access to the TFE instance; the tool only needs port 443 to the TFE hostname</li>
            </ul>
          </Tile>
        )}

        {activeSection === "reference" && (
          <div style={{ display: "grid", gap: "1rem" }}>
            <Tile className="card" style={{ padding: "1.5rem" }}>
              <h3 style={{ marginTop: 0 }}>Quick Start Commands</h3>
              <pre style={{ background: "#f4f4f4", padding: "0.75rem 1rem", borderRadius: "4px", fontSize: "0.85rem", overflowX: "auto" }}>
{`# Native dev
npm install && npm run dev
# Web: http://localhost:5174  API: http://localhost:8080

# Docker (Rancher Desktop / nerdctl)
nerdctl compose up --build -d
# Web: http://localhost:80

# Docker (Docker Desktop)
docker compose up --build -d`}
              </pre>
            </Tile>

            <Tile className="card" style={{ padding: "1.5rem" }}>
              <h3 style={{ marginTop: 0 }}>Key API Endpoints</h3>
              <pre style={{ background: "#f4f4f4", padding: "0.75rem 1rem", borderRadius: "4px", fontSize: "0.85rem", overflowX: "auto" }}>
{`POST /scans                        # Start managed state scan
GET  /scans/:id                    # Poll scan status
GET  /scans/:id/resources          # Per-resource RUM breakdown

POST /estimator/aws/runs           # Start AWS unmanaged estimator
POST /estimator/azure/runs         # Start Azure unmanaged estimator
POST /estimator/gcp/runs           # Start GCP unmanaged estimator
GET  /estimator/runs/:id           # Poll estimator status
GET  /estimator/runs/:id/diagnostics  # Coverage %, missing permissions

POST /tfe/projects                 # List TFE/TFC projects
POST /tfe/migration/runs           # Start TFE migration estimate
GET  /tfe/migration/runs/:id       # Poll migration status
GET  /tfe/migration/runs/:id/export?format=csv  # Export results

GET  /metrics/combined-summary     # Aggregate RUM across all sources
GET  /health                       # API health check`}
              </pre>
            </Tile>

            <Tile className="card" style={{ padding: "1.5rem" }}>
              <h3 style={{ marginTop: 0 }}>RUM Calculation Rules</h3>
              <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "0.875rem" }}>
                <thead>
                  <tr style={{ background: "#f4f4f4" }}>
                    <th style={{ padding: "0.5rem 0.75rem", textAlign: "left", border: "1px solid #e0e0e0" }}>Resource type</th>
                    <th style={{ padding: "0.5rem 0.75rem", textAlign: "left", border: "1px solid #e0e0e0" }}>Counted?</th>
                    <th style={{ padding: "0.5rem 0.75rem", textAlign: "left", border: "1px solid #e0e0e0" }}>Rule</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    ["managed resource (mode: managed)", "✅ Yes", "Each instance counts as 1 RUM"],
                    ["data source (mode: data)", "❌ No", "EXCLUDED_DATA_SOURCE"],
                    ["null_resource", "❌ No", "EXCLUDED_NULL_RESOURCE"],
                    ["terraform_data", "❌ No", "EXCLUDED_TERRAFORM_DATA"],
                    ["count / for_each expansion", "✅ Yes × N", "Each instance counts separately"],
                  ].map(([type, counted, rule]) => (
                    <tr key={type as string}>
                      <td style={{ padding: "0.5rem 0.75rem", border: "1px solid #e0e0e0", fontFamily: "monospace", fontSize: "0.8rem" }}>{type}</td>
                      <td style={{ padding: "0.5rem 0.75rem", border: "1px solid #e0e0e0" }}>{counted}</td>
                      <td style={{ padding: "0.5rem 0.75rem", border: "1px solid #e0e0e0", color: "#525252" }}>{rule}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </Tile>

            <Tile className="card" style={{ padding: "1.5rem" }}>
              <h3 style={{ marginTop: 0 }}>Pack Tier Reference</h3>
              <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "0.875rem" }}>
                <thead>
                  <tr style={{ background: "#f4f4f4" }}>
                    <th style={{ padding: "0.5rem 0.75rem", textAlign: "left", border: "1px solid #e0e0e0" }}>Packs</th>
                    <th style={{ padding: "0.5rem 0.75rem", textAlign: "left", border: "1px solid #e0e0e0" }}>RUM Entitlement</th>
                    <th style={{ padding: "0.5rem 0.75rem", textAlign: "left", border: "1px solid #e0e0e0" }}>Typical use case</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    ["100", "10,000", "Small teams, pilot projects"],
                    ["250", "25,000", "Mid-market, growing IaC adoption"],
                    ["500", "50,000", "Enterprise, moderate cloud footprint"],
                    ["1,000", "100,000", "Large enterprise"],
                    ["2,500", "250,000", "Very large enterprise, multi-cloud"],
                    ["5,000", "500,000", "Hyperscale environments"],
                  ].map(([packs, rum, use]) => (
                    <tr key={packs as string}>
                      <td style={{ padding: "0.5rem 0.75rem", border: "1px solid #e0e0e0" }}>{packs}</td>
                      <td style={{ padding: "0.5rem 0.75rem", border: "1px solid #e0e0e0", fontWeight: 600 }}>{rum}</td>
                      <td style={{ padding: "0.5rem 0.75rem", border: "1px solid #e0e0e0", color: "#525252" }}>{use}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <p className="helper-text" style={{ marginTop: "0.5rem" }}>
                IBM guidance: add 20–30% growth buffer before selecting the tier. The Pack Sizing tab does this automatically.
              </p>
            </Tile>
          </div>
        )}
      </div>
    </div>
  );
}
