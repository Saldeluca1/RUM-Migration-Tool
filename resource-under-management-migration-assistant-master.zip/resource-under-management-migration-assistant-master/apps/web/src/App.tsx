import { useState } from "react";
import { Button, Content, Header, HeaderName } from "@carbon/react";
import { WizardCards } from "./components/WizardCards";
import { DeployActions } from "./components/DeployActions";
import { Dashboard } from "./components/Dashboard";
import { TerminalPanel } from "./components/TerminalPanel";
import { UnmanagedEstimatorTab } from "./components/UnmanagedEstimatorTab";
import { TfeMigrationTab } from "./components/TfeMigrationTab";
import { RumHistoryTab } from "./components/RumHistoryTab";
import { CombinedSummaryBanner } from "./components/CombinedSummaryBanner";
import { PackSizingTab } from "./components/PackSizingTab";
import { ReportingDashboard } from "./components/ReportingDashboard";
import { SEGuideTab } from "./components/SEGuideTab";

type TabId = "managed" | "unmanaged" | "tfe" | "rum-history" | "pack" | "reporting" | "guide";

export function App() {
  const [refreshKey, setRefreshKey] = useState(0);
  const [activeTab, setActiveTab] = useState<TabId>("managed");
  const [packPrefill, setPackPrefill] = useState<
    { monthlyValues: number[]; growthPct: number | null } | undefined
  >(undefined);

  return (
    <>
      <Header aria-label="TFC RUM Calculator">
        <HeaderName href="#" prefix="IBM">Terraform Cloud RUM Assistant</HeaderName>
      </Header>

      {/* Trust banner — always visible, credentials never leave this machine */}
      <div style={{
        background: "#f4f4f4",
        borderBottom: "1px solid #e0e0e0",
        padding: "0.375rem 1rem",
        fontSize: "0.8rem",
        color: "#525252",
        display: "flex",
        alignItems: "center",
        gap: "0.4rem",
      }}>
        <span style={{ fontSize: "0.9rem" }}>🔒</span>
        <span>All scans run locally. Credentials are used once and never stored.</span>
        <button
          type="button"
          onClick={() => setActiveTab("guide")}
          style={{ background: "none", border: "none", color: "#0f62fe", cursor: "pointer", fontSize: "0.8rem", padding: 0, textDecoration: "underline" }}
        >
          Learn more
        </button>
      </div>

      <Content id="main-content" className="layout">
        <section className="hero">
          <h1>Resource Under Management Migration Assistant</h1>
          <p>Card-guided scan setup, one-click deployment actions, and RUM analytics dashboard for OSS-to-TFC onboarding.</p>
        </section>

        <CombinedSummaryBanner />

        <section className="tab-row">
          <Button kind={activeTab === "managed" ? "primary" : "tertiary"} onClick={() => setActiveTab("managed")}>
            Managed State Scanner
          </Button>
          <Button kind={activeTab === "unmanaged" ? "primary" : "tertiary"} onClick={() => setActiveTab("unmanaged")}>
            Unmanaged Estimator
          </Button>
          <Button kind={activeTab === "tfe" ? "primary" : "tertiary"} onClick={() => setActiveTab("tfe")}>
            TFE Migration
          </Button>
          <Button kind={activeTab === "rum-history" ? "primary" : "tertiary"} onClick={() => setActiveTab("rum-history")}>
            RUM History (TFE/TFC)
          </Button>
          <Button kind={activeTab === "pack" ? "primary" : "tertiary"} onClick={() => setActiveTab("pack")}>
            Pack Sizing
          </Button>
          <Button kind={activeTab === "reporting" ? "primary" : "tertiary"} onClick={() => setActiveTab("reporting")}>
            Reporting
          </Button>
          <Button kind={activeTab === "guide" ? "primary" : "tertiary"} onClick={() => setActiveTab("guide")}>
            Engineer Guide
          </Button>
        </section>

        {/* All tabs stay mounted to preserve state — hidden via CSS display */}
        <div style={{ display: activeTab === "managed" ? "block" : "none" }}>
          <section className="two-col">
            <WizardCards onScanStarted={() => setRefreshKey((k) => k + 1)} />
            <DeployActions />
          </section>

          <section>
            <Dashboard refreshKey={refreshKey} />
          </section>

          <section>
            <TerminalPanel />
          </section>
        </div>

        <div style={{ display: activeTab === "unmanaged" ? "block" : "none" }}>
          <section>
            <UnmanagedEstimatorTab />
          </section>
        </div>

        <div style={{ display: activeTab === "tfe" ? "block" : "none" }}>
          <section>
            <TfeMigrationTab />
          </section>
        </div>

        <div style={{ display: activeTab === "rum-history" ? "block" : "none" }}>
          <section>
            <RumHistoryTab
              onLoadIntoPackSizing={(p) => {
                setPackPrefill(p);
                setActiveTab("pack");
              }}
            />
          </section>
        </div>

        <div style={{ display: activeTab === "pack" ? "block" : "none" }}>
          <section>
            <PackSizingTab prefill={packPrefill} />
          </section>
        </div>

        <div style={{ display: activeTab === "reporting" ? "block" : "none" }}>
          <section>
            <ReportingDashboard onNavigate={setActiveTab} />
          </section>
        </div>

        <div style={{ display: activeTab === "guide" ? "block" : "none" }}>
          <section>
            <SEGuideTab
              onNavigate={setActiveTab}
              onDemoLoaded={() => setRefreshKey((k) => k + 1)}
            />
          </section>
        </div>
      </Content>
    </>
  );
}
