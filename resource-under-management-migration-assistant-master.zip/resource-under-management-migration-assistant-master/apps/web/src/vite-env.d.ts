/// <reference types="vite/client" />

/** Root package.json version, injected at build time via vite.config.ts `define`. */
declare const __APP_VERSION__: string;
