import type { EstimatorRunProgress } from "../lib/api";

/** Rows shown per category table. Larger categories are previewed; exports carry the rest. */
export const CATEGORY_PREVIEW_LIMIT = 200;

/** Splits a comma-, space- or newline-separated list, trimming and dropping blanks and repeats. */
export function parseList(text: string): string[] {
  return [...new Set(text.split(/[\s,]+/).map((value) => value.trim()).filter(Boolean))];
}

export function findInvalidAccountIds(accountIds: string[]): string[] {
  return accountIds.filter((id) => !/^\d{12}$/.test(id));
}

/**
 * Poll interval for a running job. Short runs still feel immediate; long multi-account
 * runs back off so the API is not polled every second for many minutes.
 */
export function nextPollDelayMs(elapsedMs: number): number {
  if (elapsedMs < 30_000) return 1_000;
  if (elapsedMs < 5 * 60_000) return 3_000;
  return 5_000;
}

export function formatElapsed(elapsedMs: number): string {
  const totalSeconds = Math.max(0, Math.floor(elapsedMs / 1000));
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return minutes > 0 ? `${minutes}m ${String(seconds).padStart(2, "0")}s` : `${seconds}s`;
}

/** One-line description of where a run is, for the status tile. */
export function describeProgress(progress: EstimatorRunProgress | undefined): string {
  if (!progress) return "Waiting to start";
  const count = (n: number) => n.toLocaleString("en-US");
  if (progress.phase === "classifying") {
    return `Classifying resources: ${count(progress.resourcesClassified)} of ${count(progress.resourcesDiscovered)}`;
  }
  if (progress.phase === "finalizing") {
    return `Summarising ${count(progress.resourcesDiscovered)} resources`;
  }
  const parts = [`Discovering resources: ${count(progress.resourcesDiscovered)} found`];
  if (progress.pagesFetched > 0) parts.push(`${count(progress.pagesFetched)} ${progress.pagesFetched === 1 ? "page" : "pages"} fetched`);
  if (progress.unitsTotal && progress.unitsTotal > 1) parts.push(`${progress.unitsCompleted ?? 0} of ${progress.unitsTotal} complete`);
  return parts.join(" · ");
}
