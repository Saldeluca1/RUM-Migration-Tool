import { useEffect, useMemo, useRef, useState } from "react";
import { Button, Checkbox, CodeSnippet, DataTable, InlineLoading, ActionableNotification, PasswordInput, Table, TableBody, TableCell, TableContainer, TableHead, TableHeader, TableRow, Tag, TextArea, TextInput, Tile, Tooltip } from "@carbon/react";
import {
  getEstimatorMappingMetadata,
  getEstimatorCategoryExportUrl,
  getEstimatorIamRemediation,
  getEstimatorIamRemediationPolicyExportUrl,
  getEstimatorCategoryRows,
  getEstimatorRunDiagnostics,
  getEstimatorRun,
  listAwsConfigAggregators,
  listEstimatorRuns,
  startAwsEstimatorRun,
  startAzureEstimatorRun,
  startGcpEstimatorRun,
  type AwsDiscoverySource,
  type ConfigAggregatorSummary,
  type EstimatorAccountSummary,
  type EstimatorDiscoveryInfo,
  type EstimatorProvider,
  type EstimatorMappingMetadata,
  type EstimatorResourceRow,
  type EstimatorRunProgress,
  type EstimatorRunRecord
} from "../lib/api";
import {
  CATEGORY_PREVIEW_LIMIT,
  describeProgress,
  findInvalidAccountIds,
  formatElapsed,
  nextPollDelayMs,
  parseList
} from "./estimator-run-helpers";

const MAX_CONSECUTIVE_POLL_ERRORS = 5;
const TAGGING_BASE_PERMISSIONS = ["resourcegroupstaggingapi:GetResources"];
const CONFIG_BASE_PERMISSIONS = ["config:DescribeConfigurationAggregators", "config:SelectAggregateResourceConfig"];

type SummaryMetric = {
  label: string;
  value: number;
  help: string;
};

export function UnmanagedEstimatorTab() {
  const [provider, setProvider] = useState<EstimatorProvider>("aws");
  const [regions, setRegions] = useState("us-east-1");
  const [awsRegion, setAwsRegion] = useState("");
  const [awsProfile, setAwsProfile] = useState("");
  const [awsAccessKeyId, setAwsAccessKeyId] = useState("");
  const [awsSecretAccessKey, setAwsSecretAccessKey] = useState("");
  const [awsSessionToken, setAwsSessionToken] = useState("");
  const [isRunning, setIsRunning] = useState(false);
  const [runId, setRunId] = useState("");
  const [status, setStatus] = useState("");
  const [message, setMessage] = useState("");
  const [summary, setSummary] = useState<EstimatorRunRecord["summary"]>();
  const [history, setHistory] = useState<EstimatorRunRecord[]>([]);
  const [mappingMetadata, setMappingMetadata] = useState<EstimatorMappingMetadata | null>(null);
  const [candidateRows, setCandidateRows] = useState<EstimatorResourceRow[]>([]);
  const [autoCreatedRows, setAutoCreatedRows] = useState<EstimatorResourceRow[]>([]);
  const [nonManageableRows, setNonManageableRows] = useState<EstimatorResourceRow[]>([]);
  const [unmappedRows, setUnmappedRows] = useState<EstimatorResourceRow[]>([]);
  const [detailsLoading, setDetailsLoading] = useState(false);
  const [topUnmapped, setTopUnmapped] = useState<Array<{ key: string; count: number; sampleResourceId: string }>>([]);
  const [topMissingPermissions, setTopMissingPermissions] = useState<Array<{ permission: string; count: number }>>([]);
  const [permissionDeniedCount, setPermissionDeniedCount] = useState(0);
  const [coveragePct, setCoveragePct] = useState(0);
  const [serviceLevelMatches, setServiceLevelMatches] = useState(0);
  const [suggestedPermissions, setSuggestedPermissions] = useState<string[]>(TAGGING_BASE_PERMISSIONS);
  const [suggestedPolicyJson, setSuggestedPolicyJson] = useState("{}");
  const [copyPolicyStatus, setCopyPolicyStatus] = useState("");
  const [includeTagFilter, setIncludeTagFilter] = useState(false);
  const [tagKey, setTagKey] = useState("Environment");
  const [tagValues, setTagValues] = useState("prod");
  const [azureSubscriptionId, setAzureSubscriptionId] = useState("");
  const [azureResourceGroup, setAzureResourceGroup] = useState("");
  const [azureTenantId, setAzureTenantId] = useState("");
  const [gcpProjectId, setGcpProjectId] = useState("");
  const [gcpCredentialsPath, setGcpCredentialsPath] = useState("");
  const [discoverySource, setDiscoverySource] = useState<AwsDiscoverySource>("tagging-api");
  const [aggregatorName, setAggregatorName] = useState("");
  const [aggregatorRegion, setAggregatorRegion] = useState("");
  const [configRegions, setConfigRegions] = useState("");
  const [configAccountIds, setConfigAccountIds] = useState("");
  const [taggingRoleName, setTaggingRoleName] = useState("");
  const [taggingExternalId, setTaggingExternalId] = useState("");
  const [aggregators, setAggregators] = useState<ConfigAggregatorSummary[]>([]);
  const [aggregatorLookup, setAggregatorLookup] = useState<{ status: "idle" | "loading" | "done" | "error"; message: string }>({
    status: "idle",
    message: ""
  });
  const [progress, setProgress] = useState<EstimatorRunProgress>();
  const [elapsedMs, setElapsedMs] = useState(0);
  const [byAccount, setByAccount] = useState<EstimatorAccountSummary[]>([]);
  const [discoveryInfo, setDiscoveryInfo] = useState<EstimatorDiscoveryInfo>();
  const [categoryTotals, setCategoryTotals] = useState({ candidates: 0, "likely-auto-created": 0, "non-manageable": 0, unmapped: 0 });
  const isMounted = useRef(true);

  useEffect(() => {
    isMounted.current = true;
    return () => {
      // Stops the polling loop when the tab is left; the job keeps running on the server.
      isMounted.current = false;
    };
  }, []);

  const usingConfig = provider === "aws" && discoverySource !== "tagging-api";
  const usingCombined = provider === "aws" && discoverySource === "combined";
  const parsedAccountIds = useMemo(() => parseList(configAccountIds), [configAccountIds]);
  const invalidAccountIds = useMemo(() => findInvalidAccountIds(parsedAccountIds), [parsedAccountIds]);

  const canRun = useMemo(() => {
    if (provider === "gcp") {
      return gcpProjectId.trim().length > 0;
    }
    if (provider === "azure") {
      return true;
    }
    const hasKey = awsAccessKeyId.trim().length > 0;
    const hasSecret = awsSecretAccessKey.trim().length > 0;
    if (hasKey !== hasSecret) return false;
    if (discoverySource !== "tagging-api") {
      return aggregatorName.trim().length > 0 && invalidAccountIds.length === 0;
    }
    return true;
  }, [provider, gcpProjectId, awsAccessKeyId, awsSecretAccessKey, discoverySource, aggregatorName, invalidAccountIds]);

  function awsExecutionEnv() {
    return {
      awsRegion: awsRegion || undefined,
      awsProfile: awsProfile || undefined,
      awsAccessKeyId: awsAccessKeyId || undefined,
      awsSecretAccessKey: awsSecretAccessKey || undefined,
      awsSessionToken: awsSessionToken || undefined
    };
  }

  async function findAggregators() {
    setAggregatorLookup({ status: "loading", message: "" });
    try {
      const data = await listAwsConfigAggregators({
        aggregatorRegion: aggregatorRegion.trim() || undefined,
        executionEnv: awsExecutionEnv()
      });
      setAggregators(data.aggregators);
      if (data.aggregators.length === 1 && !aggregatorName.trim()) setAggregatorName(data.aggregators[0].name);
      setAggregatorLookup({
        status: "done",
        message:
          data.aggregators.length === 0
            ? "No aggregators found in this account and region. Check the aggregator region, or use credentials for the account that owns the aggregator."
            : `Found ${data.aggregators.length} aggregator${data.aggregators.length === 1 ? "" : "s"}. Select one to use it.`
      });
    } catch (error) {
      setAggregators([]);
      setAggregatorLookup({ status: "error", message: error instanceof Error ? error.message : "Unable to list aggregators" });
    }
  }

  useEffect(() => {
    void refreshHistory();
    void refreshMapping();
  }, [provider]);

  async function refreshHistory() {
    const data = await listEstimatorRuns();
    setHistory((data.runs ?? []) as EstimatorRunRecord[]);
  }

  async function refreshMapping() {
    try {
      const metadata = await getEstimatorMappingMetadata(provider);
      setMappingMetadata(metadata);
    } catch {
      setMappingMetadata(null);
    }
  }

  async function runEstimator() {
    setIsRunning(true);
    setMessage("");
    setCandidateRows([]);
    setAutoCreatedRows([]);
    setNonManageableRows([]);
    setUnmappedRows([]);
    setTopUnmapped([]);
    setTopMissingPermissions([]);
    setPermissionDeniedCount(0);
    setCoveragePct(0);
    setServiceLevelMatches(0);
    setSuggestedPermissions(
      usingCombined ? [...CONFIG_BASE_PERMISSIONS, ...TAGGING_BASE_PERMISSIONS, "sts:AssumeRole"] : usingConfig ? CONFIG_BASE_PERMISSIONS : TAGGING_BASE_PERMISSIONS
    );
    setSuggestedPolicyJson("{}");
    setCopyPolicyStatus("");
    setProgress(undefined);
    setElapsedMs(0);
    setByAccount([]);
    setDiscoveryInfo(undefined);
    setCategoryTotals({ candidates: 0, "likely-auto-created": 0, "non-manageable": 0, unmapped: 0 });
    try {
      const configRegionList = parseList(configRegions);
      const created = provider === "aws"
        ? await startAwsEstimatorRun({
            scope: usingConfig
              ? {
                  discoverySource,
                  regions: configRegionList.length > 0 ? configRegionList : undefined,
                  tagging: usingCombined
                    ? { roleName: taggingRoleName.trim() || undefined, externalId: taggingExternalId || undefined }
                    : undefined,
                  configAggregator: {
                    name: aggregatorName.trim(),
                    region: aggregatorRegion.trim() || undefined,
                    accountIds: parsedAccountIds.length > 0 ? parsedAccountIds : undefined
                  }
                }
              : {
                  regions: regions.split(",").map((v) => v.trim()).filter(Boolean),
                  tagFilters: includeTagFilter
                    ? [{ key: tagKey, values: tagValues.split(",").map((v) => v.trim()).filter(Boolean) }]
                    : undefined
                },
            executionEnv: awsExecutionEnv()
          })
        : provider === "azure"
          ? await startAzureEstimatorRun({
              scope: {
                subscriptionId: azureSubscriptionId || undefined,
                resourceGroup: azureResourceGroup || undefined
              },
              executionEnv: {
                azureSubscriptionId: azureSubscriptionId || undefined,
                azureTenantId: azureTenantId || undefined
              }
            })
          : await startGcpEstimatorRun({
              scope: {
                projectId: gcpProjectId
              },
              executionEnv: {
                gcpProjectId: gcpProjectId || undefined,
                googleApplicationCredentials: gcpCredentialsPath || undefined
              }
            });

      setRunId(created.id);
      setStatus(created.status);
      await pollRun(created.id);
      await refreshHistory();
    } catch (error) {
      const msg = error instanceof Error ? error.message : "Unknown error";
      setMessage(`Estimator failed to start: ${msg}`);
    } finally {
      setIsRunning(false);
    }
  }

  // Polls until the run finishes. There is no attempt cap: a multi-account run can take
  // many minutes, and the server marks a run failed if its process dies, so the loop ends.
  async function pollRun(id: string) {
    const startedAt = Date.now();
    let consecutiveErrors = 0;
    while (isMounted.current) {
      const elapsed = Date.now() - startedAt;
      try {
        const run = await getEstimatorRun(id);
        consecutiveErrors = 0;
        if (!isMounted.current) return;
        setStatus(run.status);
        setProgress(run.progress);
        setElapsedMs(elapsed);
        if (run.status === "completed") {
          setSummary(run.summary);
          setByAccount(run.byAccount ?? []);
          setDiscoveryInfo(run.discovery);
          await refreshCategoryDetails(id);
          setMessage(`Run ${id} completed in ${formatElapsed(elapsed)}.`);
          return;
        }
        if (run.status === "failed") {
          setMessage(`Run ${id} failed: ${run.errorMessage ?? "unknown error"}`);
          return;
        }
      } catch (error) {
        // A dropped status request should not abandon a long run; give up only if the API stays unreachable.
        consecutiveErrors += 1;
        if (consecutiveErrors >= MAX_CONSECUTIVE_POLL_ERRORS) {
          const detail = error instanceof Error ? error.message : "unknown error";
          setMessage(`Run ${id} status check failed repeatedly (${detail}). The run may still be in progress on the server; check Estimator Run History.`);
          return;
        }
      }
      await new Promise((resolve) => setTimeout(resolve, nextPollDelayMs(elapsed)));
    }
  }

  async function refreshCategoryDetails(id: string) {
    setDetailsLoading(true);
    try {
      const [candidates, autoCreated, nonManageable, unmapped] = await Promise.all([
        getEstimatorCategoryRows(id, "candidates", CATEGORY_PREVIEW_LIMIT),
        getEstimatorCategoryRows(id, "likely-auto-created", CATEGORY_PREVIEW_LIMIT),
        getEstimatorCategoryRows(id, "non-manageable", CATEGORY_PREVIEW_LIMIT),
        getEstimatorCategoryRows(id, "unmapped", CATEGORY_PREVIEW_LIMIT)
      ]);
      const diagnostics = await getEstimatorRunDiagnostics(id);
      const remediation = await getEstimatorIamRemediation(id);
      setCandidateRows(candidates.rows);
      setAutoCreatedRows(autoCreated.rows);
      setNonManageableRows(nonManageable.rows);
      setUnmappedRows(unmapped.rows);
      setCategoryTotals({
        candidates: candidates.total,
        "likely-auto-created": autoCreated.total,
        "non-manageable": nonManageable.total,
        unmapped: unmapped.total
      });
      setTopUnmapped(diagnostics.diagnostics.topUnmappedPrefixes ?? []);
      setTopMissingPermissions(diagnostics.diagnostics.topMissingPermissions ?? []);
      setPermissionDeniedCount(diagnostics.diagnostics.permissionDenied ?? 0);
      setCoveragePct(diagnostics.diagnostics.coveragePct ?? 0);
      setServiceLevelMatches(diagnostics.diagnostics.serviceLevelMatches ?? 0);
      setSuggestedPermissions(remediation.suggestedActions ?? []);
      setSuggestedPolicyJson(JSON.stringify(remediation.policy, null, 2));
    } finally {
      setDetailsLoading(false);
    }
  }

  function renderCategoryTable(
    title: string,
    rows: EstimatorResourceRow[],
    category: "candidates" | "likely-auto-created" | "non-manageable" | "unmapped",
    note?: string
  ) {
    const total = categoryTotals[category];
    const showAccount = rows.some((row) => row.accountId);
    return (
      <Tile className="card table-card">
        <div className="table-header-row">
          <h3>{title} ({total.toLocaleString("en-US")})</h3>
          <div className="table-actions">
            <Button
              kind="tertiary"
              size="sm"
              disabled={!runId}
              onClick={() => {
                if (!runId) return;
                window.open(getEstimatorCategoryExportUrl(runId, category, "json"), "_blank", "noopener,noreferrer");
              }}
            >
              Export JSON
            </Button>
            <Button
              kind="secondary"
              size="sm"
              disabled={!runId}
              onClick={() => {
                if (!runId) return;
                window.open(getEstimatorCategoryExportUrl(runId, category, "csv"), "_blank", "noopener,noreferrer");
              }}
            >
              Export CSV
            </Button>
          </div>
        </div>
        {note && <p className="helper-text">{note}</p>}
        {rows.length === 0 ? (
          <p className="helper-text">{detailsLoading ? "Loading..." : "No resources in this category for the selected run."}</p>
        ) : (
          <>
          {total > rows.length && (
            <p className="helper-text">
              Showing the first {rows.length.toLocaleString("en-US")} of {total.toLocaleString("en-US")} resources. Use Export CSV or Export JSON for the full list.
            </p>
          )}
          <DataTable
            rows={rows.map((row, index) => ({
              id: `${category}-${index}-${row.resourceId}`,
              resourceId: row.resourceId,
              accountId: row.accountId ?? "",
              service: row.service,
              resourceType: row.resourceType,
              region: row.region ?? "",
              terraform: row.terraformResourceType ?? "",
              reason: row.reasonCode,
              reasonDetail: row.reasonDetail ?? ""
            }))}
            headers={[
              { key: "resourceId", header: "Resource ID" },
              ...(showAccount ? [{ key: "accountId", header: "Account" }] : []),
              { key: "service", header: "Service" },
              { key: "resourceType", header: "Resource Type" },
              { key: "region", header: "Region" },
              { key: "terraform", header: "Terraform Type" },
              { key: "reason", header: "Reason" },
              { key: "reasonDetail", header: "Reason Detail" }
            ]}
          >
            {({ rows: tableRows, headers, getHeaderProps, getTableProps }) => (
              <TableContainer>
                <Table {...getTableProps()}>
                  <TableHead>
                    <TableRow>
                      {headers.map((header) => (
                        <TableHeader {...getHeaderProps({ header })}>{header.header}</TableHeader>
                      ))}
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {tableRows.map((row) => (
                      <TableRow key={row.id}>
                        {row.cells.map((cell) => (
                          <TableCell key={cell.id}>{cell.value}</TableCell>
                        ))}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            )}
          </DataTable>
          </>
        )}
      </Tile>
    );
  }

  const likelyAutoCreated = summary?.likelyAutoCreated ?? 0;
  const metrics: SummaryMetric[] = [
    {
      label: "Discovered",
      value: summary?.discoveredResources ?? 0,
      help: "Total resources discovered in selected scope before Terraform support classification."
    },
    {
      label: "RUM Candidates",
      value: summary?.rumCandidates ?? 0,
      help: "Discovered resources currently mapped to Terraform-manageable types and counted as estimated potential RUM."
    },
    {
      label: "Likely Auto-Created",
      value: likelyAutoCreated,
      help: "Resources Terraform could manage but that AWS or another resource normally creates, such as an instance's network interface and volumes, instances launched by an Auto Scaling group, snapshots and the default VPC. They are rarely in Terraform state, so they are not counted as RUM candidates."
    },
    {
      label: "Non-Manageable",
      value: summary?.nonManageable ?? 0,
      help: "Resources mapped but excluded or otherwise not counted as estimated RUM candidates."
    },
    {
      label: "Unmapped",
      value: summary?.unmapped ?? 0,
      help: "Discovered resources with no current mapping to Terraform provider-supported resource types."
    },
    {
      label: "Permission Issues",
      value: permissionDeniedCount,
      help: "Resources where deeper classification was blocked by missing permissions."
    }
  ];

  return (
    <div className="dashboard-grid">
      <Tile className="card table-card">
        <h3>Unmanaged Estimator (Prototype)</h3>
        <p className="helper-text">Discovers cloud resources in scope and estimates Terraform-manageable RUM candidates.</p>
        {mappingMetadata && (
          <div className={`mapping-banner ${mappingMetadata.isStale ? "mapping-stale" : "mapping-fresh"}`}>
            <p>
              <strong>Mapping:</strong> v{mappingMetadata.mappingVersion} | updated {mappingMetadata.updatedAt} | age {mappingMetadata.ageDays} days
              {mappingMetadata.providerVersionConstraint ? ` | provider ${mappingMetadata.providerVersionConstraint}` : ""}
              {mappingMetadata.providerVersionResolved ? ` | resolved ${mappingMetadata.providerVersionResolved}` : ""}
              {mappingMetadata.resourceTypeMappings ? ` | ${mappingMetadata.resourceTypeMappings} resource-type mappings` : ""}
            </p>
            <p>
              <strong>Status:</strong> {mappingMetadata.isStale ? "STALE" : "Fresh"} (threshold {mappingMetadata.staleThresholdDays} days)
            </p>
          </div>
        )}
        <div className="provider-card">
          <div className="wizard-actions">
            <Button kind={provider === "aws" ? "primary" : "tertiary"} size="sm" onClick={() => setProvider("aws")}>AWS</Button>
            <Button kind={provider === "azure" ? "primary" : "tertiary"} size="sm" onClick={() => setProvider("azure")}>Azure</Button>
            <Button kind={provider === "gcp" ? "primary" : "tertiary"} size="sm" onClick={() => setProvider("gcp")}>GCP</Button>
          </div>
          {provider === "aws" && (
            <>
              <div>
                <p className="helper-text" style={{ marginBottom: "0.25rem" }}><strong>Discovery method</strong></p>
                <div className="wizard-actions">
                  <Button kind={discoverySource === "tagging-api" ? "primary" : "tertiary"} size="sm" onClick={() => setDiscoverySource("tagging-api")}>Single account (Tagging API)</Button>
                  <Button kind={discoverySource === "config-aggregator" ? "primary" : "tertiary"} size="sm" onClick={() => setDiscoverySource("config-aggregator")}>Multi-account (AWS Config aggregator)</Button>
                  <Button kind={discoverySource === "combined" ? "primary" : "tertiary"} size="sm" onClick={() => setDiscoverySource("combined")}>Multi-account, most complete (Config + Tagging API)</Button>
                </div>
                <p className="helper-text">
                  {usingCombined
                    ? "Queries the AWS Config aggregator, then scans each account with the Tagging API and merges the two. Config misses resource types your recorders do not record; the Tagging API misses resources that were never tagged. Together they cover more than either alone. Needs a role the tool can assume in every account."
                    : usingConfig
                      ? "Queries one AWS Config aggregator for every account and region it collects, including untagged resources. Counts only the resource types your Config recorders record. Use credentials for the account that owns the aggregator."
                      : "Scans the account your credentials belong to, region by region. Only finds resources that are tagged or were tagged in the past."}
                </p>
              </div>
              {usingConfig ? (
                <>
                  <TextInput id="est-agg-region" labelText="Aggregator region (optional)" helperText="Region the aggregator lives in, if different from your default region." placeholder="us-east-1" value={aggregatorRegion} onChange={(e) => setAggregatorRegion(e.currentTarget.value)} />
                  <TextInput id="est-agg-name" labelText="Config aggregator name" value={aggregatorName} onChange={(e) => setAggregatorName(e.currentTarget.value)} />
                  <div className="wizard-actions">
                    <Button kind="tertiary" size="sm" disabled={aggregatorLookup.status === "loading"} onClick={findAggregators}>
                      {aggregatorLookup.status === "loading" ? "Looking up..." : "Find aggregators"}
                    </Button>
                    {aggregators.map((aggregator) => (
                      <Button
                        key={aggregator.name}
                        kind={aggregator.name === aggregatorName ? "primary" : "ghost"}
                        size="sm"
                        onClick={() => setAggregatorName(aggregator.name)}
                        title={`${aggregator.type === "organization" ? "Organization-wide" : aggregator.type === "accounts" ? `${aggregator.accountCount ?? 0} accounts` : "Unknown scope"} · ${aggregator.allRegions ? "all regions" : aggregator.regions.join(", ") || "no regions listed"}`}
                      >
                        {aggregator.name}
                      </Button>
                    ))}
                  </div>
                  {aggregatorLookup.message && (
                    <p className="helper-text" style={aggregatorLookup.status === "error" ? { color: "#da1e28" } : undefined}>{aggregatorLookup.message}</p>
                  )}
                  <TextInput id="est-config-regions" labelText="Regions to include (optional, comma-separated)" helperText={usingCombined ? "Leave blank for every region in the aggregator. These are also the regions the Tagging API scans, so list them all if some regions have no Config data." : "Leave blank for every region in the aggregator. Global resources such as IAM are always included."} value={configRegions} onChange={(e) => setConfigRegions(e.currentTarget.value)} />
                  <TextArea
                    id="est-config-accounts"
                    labelText="Account IDs to include (optional)"
                    helperText={
                      invalidAccountIds.length > 0
                        ? `Not a 12-digit account ID: ${invalidAccountIds.slice(0, 3).join(", ")}${invalidAccountIds.length > 3 ? "..." : ""}`
                        : parsedAccountIds.length > 0
                          ? `${parsedAccountIds.length} account${parsedAccountIds.length === 1 ? "" : "s"} entered.`
                          : "Leave blank for every account in the aggregator. Separate IDs with commas, spaces or new lines."
                    }
                    invalid={invalidAccountIds.length > 0}
                    invalidText={`Not a 12-digit account ID: ${invalidAccountIds.slice(0, 3).join(", ")}${invalidAccountIds.length > 3 ? "..." : ""}`}
                    rows={3}
                    value={configAccountIds}
                    onChange={(e) => setConfigAccountIds(e.currentTarget.value)}
                  />
                  {usingCombined && (
                    <>
                      <TextInput
                        id="est-tagging-role"
                        labelText="Role to assume in each account (optional)"
                        helperText="A role name that exists in every account, allows tag:GetResources, and trusts your credentials. Leave blank to scan only the account your credentials belong to."
                        placeholder="RumEstimatorReadOnly"
                        value={taggingRoleName}
                        onChange={(e) => setTaggingRoleName(e.currentTarget.value)}
                      />
                      <PasswordInput
                        id="est-tagging-external-id"
                        labelText="Role external ID (optional)"
                        value={taggingExternalId}
                        onChange={(e) => setTaggingExternalId(e.currentTarget.value)}
                      />
                    </>
                  )}
                </>
              ) : (
                <>
                  <TextInput id="regions" labelText="Regions (comma-separated)" value={regions} onChange={(e) => setRegions(e.currentTarget.value)} />
                  <Checkbox id="include-tag-filter" labelText="Apply tag filter" checked={includeTagFilter} onChange={(_evt: unknown, { checked }: { checked: boolean | "indeterminate" }) => setIncludeTagFilter(Boolean(checked))} />
                  {includeTagFilter && (
                    <>
                      <TextInput id="tag-key" labelText="Tag Key" value={tagKey} onChange={(e) => setTagKey(e.currentTarget.value)} />
                      <TextInput id="tag-values" labelText="Tag Values (comma-separated)" value={tagValues} onChange={(e) => setTagValues(e.currentTarget.value)} />
                    </>
                  )}
                </>
              )}
              <TextInput id="est-aws-region" labelText="AWS Region override (optional)" value={awsRegion} onChange={(e) => setAwsRegion(e.currentTarget.value)} />
              <TextInput id="est-aws-profile" labelText="AWS Profile (optional)" value={awsProfile} onChange={(e) => setAwsProfile(e.currentTarget.value)} />
              <TextInput id="est-aws-access-key" labelText="AWS Access Key ID (optional)" value={awsAccessKeyId} onChange={(e) => setAwsAccessKeyId(e.currentTarget.value)} />
              <PasswordInput id="est-aws-secret" labelText="AWS Secret Access Key (optional)" value={awsSecretAccessKey} onChange={(e) => setAwsSecretAccessKey(e.currentTarget.value)} />
              <PasswordInput id="est-aws-token" labelText="AWS Session Token (optional)" value={awsSessionToken} onChange={(e) => setAwsSessionToken(e.currentTarget.value)} />
            </>
          )}
          {provider === "azure" && (
            <>
              <TextInput id="est-az-sub" labelText="Subscription ID (optional)" value={azureSubscriptionId} onChange={(e) => setAzureSubscriptionId(e.currentTarget.value)} />
              <TextInput id="est-az-rg" labelText="Resource Group (optional)" value={azureResourceGroup} onChange={(e) => setAzureResourceGroup(e.currentTarget.value)} />
              <TextInput id="est-az-tenant" labelText="Tenant ID (optional)" value={azureTenantId} onChange={(e) => setAzureTenantId(e.currentTarget.value)} />
            </>
          )}
          {provider === "gcp" && (
            <>
              <TextInput id="est-gcp-project" labelText="Project ID" value={gcpProjectId} onChange={(e) => setGcpProjectId(e.currentTarget.value)} />
              <TextInput id="est-gcp-creds" labelText="Credentials File Path (optional)" value={gcpCredentialsPath} onChange={(e) => setGcpCredentialsPath(e.currentTarget.value)} />
            </>
          )}
          <Button kind="primary" disabled={isRunning || !canRun} onClick={runEstimator}>{isRunning ? "Running..." : "Run Estimator"}</Button>
        </div>
      </Tile>

      {/* ---------- status / notifications ---------- */}
      {isRunning && (
        <Tile className="card table-card" style={{ padding: "1.25rem" }}>
          <InlineLoading description={`Estimator ${status || "starting"}: ${describeProgress(progress)}`} status="active" />
          {progress?.detail && <p style={{ fontSize: "0.85rem", color: "#64748b", marginTop: "0.5rem" }}>{progress.detail}</p>}
          {progress && progress.retries > 0 && (
            <p style={{ fontSize: "0.85rem", color: "#64748b", marginTop: "0.25rem" }}>
              {progress.retries} cloud API {progress.retries === 1 ? "call was" : "calls were"} retried automatically{progress.lastRetryReason ? ` (latest: ${progress.lastRetryReason})` : ""}.
            </p>
          )}
          {runId && <p style={{ fontSize: "0.85rem", color: "#64748b", marginTop: "0.5rem" }}>Run ID: {runId} · elapsed {formatElapsed(elapsedMs)}</p>}
        </Tile>
      )}

      {!isRunning && message && (message.includes("failed") || message.includes("Error")) && (
        <ActionableNotification
          kind="error"
          title="Estimator Failed"
          subtitle={message}
          lowContrast
          inline
          actionButtonLabel="Retry"
          onActionButtonClick={runEstimator}
          hideCloseButton
        />
      )}

      {!isRunning && status === "completed" && message && !message.includes("failed") && (
        <ActionableNotification
          kind="success"
          title="Estimator Complete"
          subtitle={message}
          lowContrast
          inline
          actionButtonLabel="Re-run"
          onActionButtonClick={runEstimator}
          hideCloseButton
        />
      )}

      <Tile className="card table-card">
        <div style={{ display: "flex", alignItems: "center", gap: "0.75rem", flexWrap: "wrap", marginBottom: "0.5rem" }}>
          <h3 style={{ margin: 0 }}>Latest Estimator Summary</h3>
          {coveragePct > 0 && (
            <Tooltip
              label={`${coveragePct}% of discovered resources matched a known Terraform type. Resources without a match appear in the Unmapped category.`}
              align="bottom"
            >
              <Tag
                type={coveragePct >= 70 ? "green" : coveragePct >= 40 ? "warm-gray" : "red"}
                size="md"
                style={{ cursor: "help" }}
              >
                Coverage: {coveragePct}%
              </Tag>
            </Tooltip>
          )}
        </div>
        <div className="kpi-grid-inline">
          {metrics.map((metric) => (
            <div key={metric.label} className="metric-card">
              <h4>
                {metric.label}
                <span className="metric-help" tabIndex={0} aria-label={`${metric.label} definition`}>
                  i
                  <span className="metric-help-text">{metric.help}</span>
                </span>
              </h4>
              <p>{metric.value}</p>
            </div>
          ))}
        </div>
        {likelyAutoCreated > 0 && (
          <p className="helper-text" style={{ marginTop: "0.75rem" }}>
            {likelyAutoCreated.toLocaleString("en-US")} resource{likelyAutoCreated === 1 ? " is" : "s are"} left out of RUM Candidates because AWS or another resource normally
            creates {likelyAutoCreated === 1 ? "it" : "them"}, so {likelyAutoCreated === 1 ? "it is" : "they are"} unlikely to be in Terraform state. If you declare these as separate Terraform resources, the upper
            bound is {((summary?.rumCandidates ?? 0) + likelyAutoCreated).toLocaleString("en-US")}. The Likely Auto-Created table below gives the reason for each.
          </p>
        )}
        {serviceLevelMatches > 0 && (
          <p className="helper-text" style={{ marginTop: "0.75rem" }}>
            {serviceLevelMatches.toLocaleString("en-US")} resource{serviceLevelMatches === 1 ? " is" : "s are"} labelled with the default Terraform type for the service, because the
            resource carries no finer type or it is not in the mapping yet. They are counted; only the type label is approximate. The exports mark them with typeMatch = service.
          </p>
        )}
      </Tile>

      {discoveryInfo?.failedAccounts && discoveryInfo.failedAccounts.length > 0 && (
        <ActionableNotification
          kind="warning"
          title={`Tagging API scan failed for ${discoveryInfo.failedAccounts.length} account${discoveryInfo.failedAccounts.length === 1 ? "" : "s"}`}
          subtitle={`Totals for these accounts only include what AWS Config returned: ${discoveryInfo.failedAccounts.slice(0, 5).map((a) => a.accountId).join(", ")}${discoveryInfo.failedAccounts.length > 5 ? ", ..." : ""}. First error: ${discoveryInfo.failedAccounts[0].error}`}
          lowContrast
          inline
          actionButtonLabel="Re-run"
          onActionButtonClick={runEstimator}
          hideCloseButton
        />
      )}

      {discoveryInfo?.autoCreatedChecksFailed && discoveryInfo.autoCreatedChecksFailed.length > 0 && (
        <ActionableNotification
          kind="warning"
          title={`${discoveryInfo.autoCreatedChecksFailed.length} auto-created resource check${discoveryInfo.autoCreatedChecksFailed.length === 1 ? "" : "s"} could not run`}
          subtitle={`RUM Candidates may still include resources these checks would have moved out (${discoveryInfo.autoCreatedChecksFailed.map((c) => c.check).join(", ")}). First error: ${discoveryInfo.autoCreatedChecksFailed[0].error}`}
          lowContrast
          inline
          actionButtonLabel="Re-run"
          onActionButtonClick={runEstimator}
          hideCloseButton
        />
      )}

      {(discoveryInfo?.source === "config-aggregator" || discoveryInfo?.source === "combined") && (
        <Tile className="card table-card">
          <h3>Discovery Coverage</h3>
          <p className="helper-text">
            Queried aggregator <strong>{discoveryInfo.aggregatorName}</strong>: {(discoveryInfo.accountsObserved ?? 0).toLocaleString("en-US")} account{discoveryInfo.accountsObserved === 1 ? "" : "s"} and{" "}
            {(discoveryInfo.regionsObserved ?? []).length} region{(discoveryInfo.regionsObserved ?? []).length === 1 ? "" : "s"} returned resources.
          </p>
          <p className="helper-text">
            Excluded from the counts: {(discoveryInfo.skippedNonResourceItems ?? 0).toLocaleString("en-US")} compliance or inventory records,{" "}
            {(discoveryInfo.duplicateItems ?? 0).toLocaleString("en-US")} duplicates, and {(discoveryInfo.skippedUnidentifiableItems ?? 0).toLocaleString("en-US")} records with no usable identifier.
          </p>
          {discoveryInfo.source === "combined" ? (
            <>
              <p className="helper-text">
                Tagging API scanned {(discoveryInfo.taggingAccountsScanned ?? 0).toLocaleString("en-US")} account{discoveryInfo.taggingAccountsScanned === 1 ? "" : "s"} across{" "}
                {(discoveryInfo.taggingRegions ?? []).length} region{(discoveryInfo.taggingRegions ?? []).length === 1 ? "" : "s"}. Found by both sources:{" "}
                <strong>{(discoveryInfo.foundByBoth ?? 0).toLocaleString("en-US")}</strong>; only by AWS Config: <strong>{(discoveryInfo.foundByConfigOnly ?? 0).toLocaleString("en-US")}</strong>; only by the
                Tagging API: <strong>{(discoveryInfo.foundByTaggingOnly ?? 0).toLocaleString("en-US")}</strong>.
              </p>
              <p className="helper-text">
                Still not counted: resources that were never tagged and are of a type your AWS Config recorders do not record. Neither source can see those.
              </p>
            </>
          ) : (
            <p className="helper-text">
              These numbers only cover resource types your AWS Config recorders record. An account or region missing here is either empty, not recorded, or not part of the aggregator.
            </p>
          )}
        </Tile>
      )}

      {byAccount.length > 0 && (
        <Tile className="card table-card">
          <h3>By Account ({byAccount.length.toLocaleString("en-US")})</h3>
          <DataTable
            rows={byAccount.map((account) => ({
              id: account.accountId,
              accountId: account.accountId,
              discovered: account.discoveredResources.toLocaleString("en-US"),
              candidates: account.rumCandidates.toLocaleString("en-US"),
              autoCreated: (account.likelyAutoCreated ?? 0).toLocaleString("en-US"),
              nonManageable: account.nonManageable.toLocaleString("en-US"),
              unmapped: account.unmapped.toLocaleString("en-US")
            }))}
            headers={[
              { key: "accountId", header: "Account" },
              { key: "discovered", header: "Discovered" },
              { key: "candidates", header: "RUM Candidates" },
              { key: "autoCreated", header: "Likely Auto-Created" },
              { key: "nonManageable", header: "Non-Manageable" },
              { key: "unmapped", header: "Unmapped" }
            ]}
          >
            {({ rows, headers, getHeaderProps, getTableProps }) => (
              <TableContainer>
                <Table {...getTableProps()}>
                  <TableHead>
                    <TableRow>
                      {headers.map((header) => (
                        <TableHeader {...getHeaderProps({ header })}>{header.header}</TableHeader>
                      ))}
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {rows.map((row) => (
                      <TableRow key={row.id}>
                        {row.cells.map((cell) => (
                          <TableCell key={cell.id}>{cell.value}</TableCell>
                        ))}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            )}
          </DataTable>
        </Tile>
      )}

      <Tile className="card table-card">
        <h3>Estimator Run History</h3>
        <DataTable
          rows={history.map((run) => ({
            id: run.id,
            provider: run.provider,
            createdAt: run.createdAt,
            status: run.status,
            discovered: String(run.summary?.discoveredResources ?? 0),
            candidates: String(run.summary?.rumCandidates ?? 0),
            mappingVersion: run.mapping?.mappingVersion ?? "",
            error: run.errorMessage ?? ""
          }))}
          headers={[
            { key: "provider", header: "Provider" },
            { key: "createdAt", header: "Created At" },
            { key: "status", header: "Status" },
            { key: "discovered", header: "Discovered" },
            { key: "candidates", header: "RUM Candidates" },
            { key: "mappingVersion", header: "Mapping Version" },
            { key: "error", header: "Error" }
          ]}
        >
          {({ rows, headers, getHeaderProps, getTableProps }) => (
            <TableContainer>
              <Table {...getTableProps()}>
                <TableHead>
                  <TableRow>
                    {headers.map((header) => (
                      <TableHeader {...getHeaderProps({ header })}>{header.header}</TableHeader>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {rows.map((row) => (
                    <TableRow key={row.id}>
                      {row.cells.map((cell) => (
                        <TableCell key={cell.id}>{cell.value}</TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </DataTable>
      </Tile>

      {renderCategoryTable("RUM Candidate Resources", candidateRows, "candidates")}
      {renderCategoryTable(
        "Likely Auto-Created Resources",
        autoCreatedRows,
        "likely-auto-created",
        "Not counted as RUM candidates. Terraform could manage these, but AWS or another resource normally creates them, so they are rarely in Terraform state. Reason Detail says why each one is here."
      )}
      {renderCategoryTable("Non-Manageable Resources", nonManageableRows, "non-manageable")}
      {renderCategoryTable("Unmapped Resources", unmappedRows, "unmapped")}

      <Tile className="card table-card">
        <h3>Top Unmapped Prefixes</h3>
        {topUnmapped.length === 0 ? (
          <p className="helper-text">No unmapped prefixes for the selected run.</p>
        ) : (
          <DataTable
            rows={topUnmapped.map((row, index) => ({
              id: `unmapped-prefix-${index}`,
              key: row.key,
              count: String(row.count),
              sample: row.sampleResourceId
            }))}
            headers={[
              { key: "key", header: "Prefix" },
              { key: "count", header: "Count" },
              { key: "sample", header: "Sample Resource ID" }
            ]}
          >
            {({ rows, headers, getHeaderProps, getTableProps }) => (
              <TableContainer>
                <Table {...getTableProps()}>
                  <TableHead>
                    <TableRow>
                      {headers.map((header) => (
                        <TableHeader {...getHeaderProps({ header })}>{header.header}</TableHeader>
                      ))}
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {rows.map((row) => (
                      <TableRow key={row.id}>
                        {row.cells.map((cell) => (
                          <TableCell key={cell.id}>{cell.value}</TableCell>
                        ))}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            )}
          </DataTable>
        )}
      </Tile>

      <Tile className="card table-card">
        <h3>Top Missing Permissions</h3>
        {topMissingPermissions.length === 0 ? (
          <p className="helper-text">No permission-related classification blockers detected.</p>
        ) : (
          <DataTable
            rows={topMissingPermissions.map((row, index) => ({
              id: `missing-perm-${index}`,
              permission: row.permission,
              count: String(row.count)
            }))}
            headers={[
              { key: "permission", header: "Permission" },
              { key: "count", header: "Count" }
            ]}
          >
            {({ rows, headers, getHeaderProps, getTableProps }) => (
              <TableContainer>
                <Table {...getTableProps()}>
                  <TableHead>
                    <TableRow>
                      {headers.map((header) => (
                        <TableHeader {...getHeaderProps({ header })}>{header.header}</TableHeader>
                      ))}
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {rows.map((row) => (
                      <TableRow key={row.id}>
                        {row.cells.map((cell) => (
                          <TableCell key={cell.id}>{cell.value}</TableCell>
                        ))}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            )}
          </DataTable>
        )}
      </Tile>

      <Tile className="card table-card">
        <h3>IAM Remediation (Suggested)</h3>
        <p className="helper-text">
          Suggested read-only permissions for estimator discovery and classification based on current run diagnostics.
        </p>
        {suggestedPermissions.length > 0 && (
          <div className="review-card" style={{ marginBottom: "0.75rem" }}>
            <strong>Actions</strong>
            <p className="helper-text">{suggestedPermissions.join(", ")}</p>
          </div>
        )}
        <CodeSnippet
          type="multi"
          feedback="Policy JSON copied"
          copyButtonDescription="Copy policy JSON"
        >
          {suggestedPolicyJson}
        </CodeSnippet>
        <div className="table-actions" style={{ marginTop: "0.75rem" }}>
          <Button
            kind="tertiary"
            size="sm"
            disabled={!runId}
            onClick={() => {
              if (!runId) return;
              window.open(getEstimatorIamRemediationPolicyExportUrl(runId), "_blank", "noopener,noreferrer");
            }}
          >
            Export Policy JSON
          </Button>
        </div>
      </Tile>
    </div>
  );
}
