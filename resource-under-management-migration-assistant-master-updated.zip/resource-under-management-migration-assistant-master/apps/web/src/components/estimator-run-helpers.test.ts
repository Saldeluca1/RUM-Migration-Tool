import { describe, expect, it } from "vitest";
import { describeProgress, findInvalidAccountIds, formatElapsed, nextPollDelayMs, parseList } from "./estimator-run-helpers";
import type { EstimatorRunProgress } from "../lib/api";

const progress = (overrides: Partial<EstimatorRunProgress>): EstimatorRunProgress => ({
  phase: "discovering",
  resourcesDiscovered: 0,
  resourcesClassified: 0,
  pagesFetched: 0,
  retries: 0,
  startedAt: "2026-11-16T10:00:00.000Z",
  updatedAt: "2026-11-16T10:00:00.000Z",
  ...overrides
});

describe("parseList", () => {
  it("splits on commas, spaces and newlines and drops blanks and repeats", () => {
    expect(parseList("111111111111, 222222222222\n333333333333  111111111111,,")).toEqual([
      "111111111111",
      "222222222222",
      "333333333333"
    ]);
  });

  it("returns an empty list for blank input", () => {
    expect(parseList("  \n ")).toEqual([]);
  });
});

describe("findInvalidAccountIds", () => {
  it("flags anything that is not 12 digits", () => {
    expect(findInvalidAccountIds(["111111111111", "1234", "11111111111a", "1111111111111"])).toEqual(["1234", "11111111111a", "1111111111111"]);
  });
});

describe("nextPollDelayMs", () => {
  it("backs off as the run gets longer", () => {
    expect(nextPollDelayMs(0)).toBe(1000);
    expect(nextPollDelayMs(29_999)).toBe(1000);
    expect(nextPollDelayMs(30_000)).toBe(3000);
    expect(nextPollDelayMs(5 * 60_000)).toBe(5000);
  });
});

describe("formatElapsed", () => {
  it("formats seconds and minutes", () => {
    expect(formatElapsed(4_200)).toBe("4s");
    expect(formatElapsed(125_000)).toBe("2m 05s");
  });
});

describe("describeProgress", () => {
  it("handles a run that has not reported yet", () => {
    expect(describeProgress(undefined)).toBe("Waiting to start");
  });

  it("describes discovery with pages and units", () => {
    expect(describeProgress(progress({ resourcesDiscovered: 12345, pagesFetched: 13, unitsCompleted: 1, unitsTotal: 2 }))).toBe(
      "Discovering resources: 12,345 found · 13 pages fetched · 1 of 2 complete"
    );
    expect(describeProgress(progress({ resourcesDiscovered: 10, pagesFetched: 1 }))).toBe("Discovering resources: 10 found · 1 page fetched");
  });

  it("describes classification and finalizing", () => {
    expect(describeProgress(progress({ phase: "classifying", resourcesDiscovered: 2000, resourcesClassified: 500 }))).toBe(
      "Classifying resources: 500 of 2,000"
    );
    expect(describeProgress(progress({ phase: "finalizing", resourcesDiscovered: 2000 }))).toBe("Summarising 2,000 resources");
  });
});
