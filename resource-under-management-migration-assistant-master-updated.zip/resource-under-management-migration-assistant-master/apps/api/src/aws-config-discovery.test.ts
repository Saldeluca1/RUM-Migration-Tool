import { describe, expect, it } from "vitest";
import {
  buildConfigQueryArgs,
  buildConfigQueryExpressions,
  discoverViaConfigAggregator,
  parseConfigAggregators,
  parseConfigResultPage,
  toDiscoveredResource,
  type ConfigQueryItem
} from "./aws-config-discovery.js";

function page(items: ConfigQueryItem[], nextToken?: string): string {
  return JSON.stringify({ Results: items.map((item) => JSON.stringify(item)), NextToken: nextToken });
}

const instance = (id: string, account = "111111111111", region = "us-east-1"): ConfigQueryItem => ({
  arn: `arn:aws:ec2:${region}:${account}:instance/${id}`,
  resourceId: id,
  resourceType: "AWS::EC2::Instance",
  accountId: account,
  awsRegion: region
});

describe("buildConfigQueryExpressions", () => {
  const select = "SELECT arn, resourceId, resourceType, accountId, awsRegion";

  it("queries the whole aggregator when no filter is given", () => {
    expect(buildConfigQueryExpressions({})).toEqual([select]);
  });

  it("adds the global pseudo-region to a region filter", () => {
    expect(buildConfigQueryExpressions({ regions: ["us-east-1", "eu-west-1"] })).toEqual([
      `${select} WHERE awsRegion IN ('us-east-1', 'eu-west-1', 'global')`
    ]);
  });

  it("combines region and account filters", () => {
    expect(buildConfigQueryExpressions({ regions: ["us-east-1"], accountIds: ["111111111111"] })).toEqual([
      `${select} WHERE awsRegion IN ('us-east-1', 'global') AND accountId IN ('111111111111')`
    ]);
  });

  it("splits 190 accounts into batches that fit the 4096-character expression limit", () => {
    const accountIds = Array.from({ length: 190 }, (_, i) => String(100000000000 + i));
    const regions = ["us-east-1", "us-east-2", "us-west-1", "us-west-2", "eu-west-1", "eu-central-1", "ap-southeast-1", "ap-northeast-1"];
    const expressions = buildConfigQueryExpressions({ regions, accountIds });

    expect(expressions).toHaveLength(2);
    for (const expression of expressions) expect(expression.length).toBeLessThanOrEqual(4096);
    expect(expressions[0]).toContain("'100000000000'");
    expect(expressions[0]).toContain("'100000000099'");
    expect(expressions[0]).not.toContain("'100000000100'");
    expect(expressions[1]).toContain("'100000000100'");
    expect(expressions[1]).toContain("'100000000189'");
  });

  it("de-duplicates repeated values", () => {
    expect(buildConfigQueryExpressions({ accountIds: ["111111111111", "111111111111"] })).toEqual([
      `${select} WHERE accountId IN ('111111111111')`
    ]);
  });

  it("rejects values that could alter the query", () => {
    expect(() => buildConfigQueryExpressions({ regions: ["us-east-1') OR resourceType LIKE ('%"] })).toThrow(/Invalid region/);
    expect(() => buildConfigQueryExpressions({ accountIds: ["1234"] })).toThrow(/Invalid account ID/);
    expect(() => buildConfigQueryExpressions({ accountIds: ["111111111111' OR '1'='1"] })).toThrow(/Invalid account ID/);
  });
});

describe("buildConfigQueryArgs", () => {
  it("builds a paginated CLI call", () => {
    const args = buildConfigQueryArgs({ aggregatorName: "org-aggregator", expression: "SELECT arn" });
    expect(args).toEqual([
      "configservice",
      "select-aggregate-resource-config",
      "--configuration-aggregator-name",
      "org-aggregator",
      "--expression",
      "SELECT arn",
      "--page-size",
      "100",
      "--max-items",
      "1000",
      "--output",
      "json"
    ]);
  });

  it("adds the aggregator region and continuation token when given", () => {
    const args = buildConfigQueryArgs({
      aggregatorName: "agg",
      expression: "SELECT arn",
      aggregatorRegion: "eu-west-1",
      startingToken: "tok"
    });
    expect(args.slice(-4)).toEqual(["--region", "eu-west-1", "--starting-token", "tok"]);
  });

  it("honours ESTIMATOR_CONFIG_ITEMS_PER_CALL and ignores invalid values", () => {
    const original = process.env.ESTIMATOR_CONFIG_ITEMS_PER_CALL;
    try {
      process.env.ESTIMATOR_CONFIG_ITEMS_PER_CALL = "25";
      const small = buildConfigQueryArgs({ aggregatorName: "agg", expression: "SELECT arn" });
      expect(small[small.indexOf("--page-size") + 1]).toBe("25");
      expect(small[small.indexOf("--max-items") + 1]).toBe("25");

      process.env.ESTIMATOR_CONFIG_ITEMS_PER_CALL = "250";
      const medium = buildConfigQueryArgs({ aggregatorName: "agg", expression: "SELECT arn" });
      expect(medium[medium.indexOf("--page-size") + 1]).toBe("100");
      expect(medium[medium.indexOf("--max-items") + 1]).toBe("250");

      for (const bad of ["0", "-5", "abc", "1.5", "999999"]) {
        process.env.ESTIMATOR_CONFIG_ITEMS_PER_CALL = bad;
        const args = buildConfigQueryArgs({ aggregatorName: "agg", expression: "SELECT arn" });
        expect(args[args.indexOf("--max-items") + 1]).toBe("1000");
      }
    } finally {
      if (original === undefined) delete process.env.ESTIMATOR_CONFIG_ITEMS_PER_CALL;
      else process.env.ESTIMATOR_CONFIG_ITEMS_PER_CALL = original;
    }
  });

  it("rejects an invalid aggregator name", () => {
    expect(() => buildConfigQueryArgs({ aggregatorName: "bad name; rm", expression: "SELECT arn" })).toThrow(/Invalid AWS Config aggregator name/);
  });
});

describe("parseConfigResultPage", () => {
  it("decodes JSON-string results and the continuation token", () => {
    const parsed = parseConfigResultPage(page([instance("i-1")], "next"));
    expect(parsed.items).toHaveLength(1);
    expect(parsed.items[0].arn).toBe("arn:aws:ec2:us-east-1:111111111111:instance/i-1");
    expect(parsed.nextToken).toBe("next");
  });

  it("handles an empty result with no token", () => {
    expect(parseConfigResultPage(JSON.stringify({ Results: [] }))).toEqual({ items: [], nextToken: undefined });
    expect(parseConfigResultPage("{}")).toEqual({ items: [], nextToken: undefined });
  });
});

describe("toDiscoveredResource", () => {
  it("uses the ARN and carries account, region and Config type", () => {
    expect(toDiscoveredResource(instance("i-1", "222222222222", "eu-west-1"))).toEqual({
      kind: "resource",
      resource: {
        resourceId: "arn:aws:ec2:eu-west-1:222222222222:instance/i-1",
        accountId: "222222222222",
        region: "eu-west-1",
        sourceResourceType: "AWS::EC2::Instance"
      }
    });
  });

  it("leaves region empty for global resources", () => {
    const outcome = toDiscoveredResource({
      arn: "arn:aws:iam::111111111111:role/admin",
      resourceId: "AROAEXAMPLE",
      resourceType: "AWS::IAM::Role",
      accountId: "111111111111",
      awsRegion: "global"
    });
    expect(outcome.kind).toBe("resource");
    if (outcome.kind === "resource") expect(outcome.resource.region).toBeUndefined();
  });

  it("skips compliance and inventory items", () => {
    for (const resourceType of ["AWS::Config::ResourceCompliance", "AWS::SSM::ManagedInstanceInventory", "AWS::SSM::PatchCompliance"]) {
      expect(toDiscoveredResource({ resourceId: "x", resourceType, accountId: "111111111111", awsRegion: "us-east-1" })).toEqual({
        kind: "skipped-non-resource"
      });
    }
  });

  it("synthesises an ARN-shaped ID when Config returns no ARN", () => {
    const outcome = toDiscoveredResource({
      resourceId: "app/web/abc",
      resourceType: "AWS::ElasticLoadBalancingV2::LoadBalancer",
      accountId: "111111111111",
      awsRegion: "us-east-1"
    });
    expect(outcome).toEqual({
      kind: "resource",
      resource: {
        resourceId: "arn:aws:elasticloadbalancing:us-east-1:111111111111:loadbalancer/app/web/abc",
        accountId: "111111111111",
        region: "us-east-1",
        sourceResourceType: "AWS::ElasticLoadBalancingV2::LoadBalancer"
      }
    });
  });

  it("skips items with no ARN and no usable type or ID", () => {
    expect(toDiscoveredResource({ resourceType: "AWS::EC2::Instance", accountId: "111111111111" })).toEqual({ kind: "skipped-unidentifiable" });
    expect(toDiscoveredResource({ resourceId: "x", resourceType: "Custom::Thing" })).toEqual({ kind: "skipped-unidentifiable" });
  });
});

describe("discoverViaConfigAggregator", () => {
  it("follows continuation tokens, skips non-resources and de-duplicates", async () => {
    const calls: string[][] = [];
    const role: ConfigQueryItem = {
      arn: "arn:aws:iam::111111111111:role/admin",
      resourceId: "AROA1",
      resourceType: "AWS::IAM::Role",
      accountId: "111111111111",
      awsRegion: "global"
    };
    const responses = [
      page([instance("i-1"), instance("i-2", "222222222222", "eu-west-1"), role], "t1"),
      page([role, { resourceId: "c-1", resourceType: "AWS::Config::ResourceCompliance", accountId: "111111111111", awsRegion: "us-east-1" }], "t2"),
      page([instance("i-3")])
    ];
    const progress: number[] = [];

    const result = await discoverViaConfigAggregator({
      aggregatorName: "org-aggregator",
      aggregatorRegion: "us-east-1",
      scope: {},
      runQuery: async (args) => {
        calls.push(args);
        return responses[calls.length - 1];
      },
      onProgress: (p) => progress.push(p.resourcesDiscovered)
    });

    expect(calls).toHaveLength(3);
    expect(calls[0]).not.toContain("--starting-token");
    expect(calls[1].slice(-2)).toEqual(["--starting-token", "t1"]);
    expect(calls[2].slice(-2)).toEqual(["--starting-token", "t2"]);
    expect(result.resources.map((r) => r.resourceId)).toEqual([
      "arn:aws:ec2:us-east-1:111111111111:instance/i-1",
      "arn:aws:ec2:eu-west-1:222222222222:instance/i-2",
      "arn:aws:iam::111111111111:role/admin",
      "arn:aws:ec2:us-east-1:111111111111:instance/i-3"
    ]);
    expect(result).toMatchObject({
      queries: 1,
      pagesFetched: 3,
      itemsReturned: 6,
      skippedNonResourceItems: 1,
      skippedUnidentifiableItems: 0,
      duplicateItems: 1
    });
    expect(progress).toEqual([3, 3, 4]);
  });

  it("runs one query per account batch", async () => {
    const accountIds = Array.from({ length: 150 }, (_, i) => String(100000000000 + i));
    const expressions: string[] = [];

    const result = await discoverViaConfigAggregator({
      aggregatorName: "agg",
      scope: { accountIds },
      runQuery: async (args) => {
        expressions.push(args[args.indexOf("--expression") + 1]);
        return page([instance(`i-${expressions.length}`)]);
      }
    });

    expect(expressions).toHaveLength(2);
    expect(result.queries).toBe(2);
    expect(result.resources).toHaveLength(2);
  });

  it("propagates a failed query", async () => {
    await expect(
      discoverViaConfigAggregator({
        aggregatorName: "agg",
        scope: {},
        runQuery: async () => {
          throw new Error("AccessDeniedException");
        }
      })
    ).rejects.toThrow("AccessDeniedException");
  });
});

describe("parseConfigAggregators", () => {
  it("summarises organization and account aggregators", () => {
    const stdout = JSON.stringify({
      ConfigurationAggregators: [
        {
          ConfigurationAggregatorName: "team-aggregator",
          AccountAggregationSources: [
            { AccountIds: ["111111111111", "222222222222"], AllAwsRegions: false, AwsRegions: ["us-east-1", "eu-west-1"] }
          ]
        },
        {
          ConfigurationAggregatorName: "aws-controltower-ConfigAggregatorForOrganizations",
          OrganizationAggregationSource: { RoleArn: "arn:aws:iam::1:role/x", AllAwsRegions: true }
        },
        { ConfigurationAggregatorName: "empty" }
      ]
    });

    expect(parseConfigAggregators(stdout)).toEqual([
      { name: "aws-controltower-ConfigAggregatorForOrganizations", type: "organization", allRegions: true, regions: [] },
      { name: "empty", type: "unknown", allRegions: false, regions: [] },
      { name: "team-aggregator", type: "accounts", allRegions: false, regions: ["eu-west-1", "us-east-1"], accountCount: 2 }
    ]);
  });

  it("returns an empty list when there are none", () => {
    expect(parseConfigAggregators("{}")).toEqual([]);
  });
});
