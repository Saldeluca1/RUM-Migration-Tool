import type { DiscoveredResource } from "./estimator-types.js";
import type { AwsAutoCreatedRules, AwsConfigMarker } from "./estimator-mapping.js";
import { findAutoCreatedTagReason } from "./estimator-analysis.js";

/**
 * Discovery through an AWS Config aggregator.
 *
 * One advanced query against the aggregator returns resources for every account and
 * region it aggregates, whether or not they were ever tagged. That removes the two
 * limits of the Resource Groups Tagging API path: one account per run, and no
 * visibility of never-tagged resources.
 *
 * Coverage is bounded by what the customer's Config recorders record.
 */

export const AWS_REGION_PATTERN = /^[a-z]{2}(-[a-z]+)+-\d+$/;
export const AWS_ACCOUNT_ID_PATTERN = /^\d{12}$/;
export const CONFIG_AGGREGATOR_NAME_PATTERN = /^[\w-]{1,256}$/;
/** Tag keys interpolated into a query; anything with a quote or whitespace is rejected. */
export const CONFIG_TAG_KEY_PATTERN = /^[\w.:/=+@-]{1,128}$/;

/** Config's awsRegion value for resources that are not regional (IAM, Route 53, CloudFront...). */
export const CONFIG_GLOBAL_REGION = "global";

/** The query expression is capped at 4096 characters; 100 account IDs is ~1,500. */
const ACCOUNT_BATCH_SIZE = 100;
/** Largest page the SelectAggregateResourceConfig API returns. */
const API_PAGE_SIZE = 100;
/** Items fetched per CLI call. Each call is one progress update and one retry unit. */
const DEFAULT_ITEMS_PER_CALL = 1000;

/**
 * Items per CLI call, overridable with ESTIMATOR_CONFIG_ITEMS_PER_CALL. Lowering it lets a
 * small test environment exercise continuation tokens; there is no reason to change it in
 * normal use.
 */
export function getConfigItemsPerCall(): number {
  const raw = process.env.ESTIMATOR_CONFIG_ITEMS_PER_CALL;
  const value = raw ? Number(raw) : DEFAULT_ITEMS_PER_CALL;
  return Number.isInteger(value) && value > 0 && value <= 10_000 ? value : DEFAULT_ITEMS_PER_CALL;
}

/**
 * Configuration item types that describe compliance or inventory state rather than a
 * resource Terraform could manage. Config stores one of these per evaluated resource or
 * managed instance, so counting them would inflate the estimate.
 */
const NON_RESOURCE_CONFIG_TYPES = new Set([
  "AWS::Config::ResourceCompliance",
  "AWS::Config::ConformancePackCompliance",
  "AWS::SSM::ManagedInstanceInventory",
  "AWS::SSM::AssociationCompliance",
  "AWS::SSM::PatchCompliance",
  "AWS::SSM::FileData"
]);

/** Config type namespace -> ARN service code, where lowercasing the namespace is not enough. */
const SERVICE_ALIASES: Record<string, string> = {
  elasticloadbalancingv2: "elasticloadbalancing",
  opensearch: "es",
  elasticsearch: "es",
  certificatemanager: "acm",
  stepfunctions: "states",
  kinesisfirehose: "firehose",
  apigatewayv2: "apigateway",
  networkfirewall: "network-firewall",
  efs: "elasticfilesystem",
  msk: "kafka"
};

export type ConfigAggregatorScope = {
  regions?: string[];
  accountIds?: string[];
};

export type ConfigQueryItem = {
  arn?: string;
  resourceId?: string;
  resourceType?: string;
  accountId?: string;
  awsRegion?: string;
  /** Only present on the auto-created checks, which select them. */
  tags?: Array<{ key?: string }>;
  configuration?: { vpcId?: string; attachments?: Array<{ vpcId?: string }> };
};

const CONFIG_BASE_FIELDS = "arn, resourceId, resourceType, accountId, awsRegion";

function quoteList(values: string[]): string {
  return values.map((value) => `'${value}'`).join(", ");
}

function assertAll(values: string[], pattern: RegExp, label: string): void {
  for (const value of values) {
    if (!pattern.test(value)) {
      // Values are interpolated into the query expression, so anything that is not a
      // plain region or account ID is rejected rather than escaped.
      throw new Error(`Invalid ${label} for AWS Config query: ${JSON.stringify(value)}`);
    }
  }
}

/**
 * Builds one query per batch of accounts (a single query when no accounts are given).
 * A region filter always includes Config's "global" pseudo-region so IAM, Route 53 and
 * similar resources are not dropped when the caller scopes to specific regions.
 *
 * `options.where` adds a condition and `options.select` replaces the selected fields; both
 * must be built from trusted or pattern-validated values, never from request text.
 */
export function buildConfigQueryExpressions(scope: ConfigAggregatorScope, options: { select?: string; where?: string } = {}): string[] {
  const regions = [...new Set(scope.regions ?? [])];
  const accountIds = [...new Set(scope.accountIds ?? [])];
  assertAll(regions, AWS_REGION_PATTERN, "region");
  assertAll(accountIds, AWS_ACCOUNT_ID_PATTERN, "account ID");

  const select = `SELECT ${options.select ?? CONFIG_BASE_FIELDS}`;
  const regionClause = regions.length > 0 ? `awsRegion IN (${quoteList([...regions, CONFIG_GLOBAL_REGION])})` : undefined;

  const accountBatches: Array<string[] | undefined> = [];
  if (accountIds.length === 0) {
    accountBatches.push(undefined);
  } else {
    for (let start = 0; start < accountIds.length; start += ACCOUNT_BATCH_SIZE) {
      accountBatches.push(accountIds.slice(start, start + ACCOUNT_BATCH_SIZE));
    }
  }

  return accountBatches.map((batch) => {
    const clauses = [
      options.where ? `(${options.where})` : undefined,
      regionClause,
      batch ? `accountId IN (${quoteList(batch)})` : undefined
    ].filter(Boolean);
    return clauses.length > 0 ? `${select} WHERE ${clauses.join(" AND ")}` : select;
  });
}

export function buildConfigQueryArgs(options: {
  aggregatorName: string;
  expression: string;
  aggregatorRegion?: string;
  startingToken?: string;
}): string[] {
  if (!CONFIG_AGGREGATOR_NAME_PATTERN.test(options.aggregatorName)) {
    throw new Error(`Invalid AWS Config aggregator name: ${JSON.stringify(options.aggregatorName)}`);
  }
  const itemsPerCall = getConfigItemsPerCall();
  const args = [
    "configservice",
    "select-aggregate-resource-config",
    "--configuration-aggregator-name",
    options.aggregatorName,
    "--expression",
    options.expression,
    "--page-size",
    String(Math.min(API_PAGE_SIZE, itemsPerCall)),
    "--max-items",
    String(itemsPerCall),
    "--output",
    "json"
  ];
  if (options.aggregatorRegion) args.push("--region", options.aggregatorRegion);
  if (options.startingToken) args.push("--starting-token", options.startingToken);
  return args;
}

/** Parses one CLI response. Each entry of Results is itself a JSON-encoded string. */
export function parseConfigResultPage(stdout: string): { items: ConfigQueryItem[]; nextToken?: string } {
  const payload = JSON.parse(stdout) as { Results?: unknown[]; NextToken?: string };
  const items: ConfigQueryItem[] = [];
  for (const raw of payload.Results ?? []) {
    const item = typeof raw === "string" ? (JSON.parse(raw) as ConfigQueryItem) : (raw as ConfigQueryItem);
    if (item && typeof item === "object") items.push(item);
  }
  return { items, nextToken: payload.NextToken || undefined };
}

function serviceFromConfigType(resourceType: string): { service: string; typeName: string } | undefined {
  const parts = resourceType.split("::");
  if (parts.length !== 3 || parts[0] !== "AWS") return undefined;
  const namespace = parts[1].toLowerCase();
  return { service: SERVICE_ALIASES[namespace] ?? namespace, typeName: parts[2].toLowerCase() };
}

export type ConfigItemOutcome =
  | { kind: "resource"; resource: DiscoveredResource }
  | { kind: "skipped-non-resource" }
  | { kind: "skipped-unidentifiable" };

/**
 * Converts a Config query row to a discovered resource. Most rows carry an ARN, which is
 * what the classifier matches on. A few resource types have none; for those an ARN-shaped
 * identifier is synthesised from the Config type so they still classify by service.
 */
export function toDiscoveredResource(item: ConfigQueryItem): ConfigItemOutcome {
  const resourceType = item.resourceType ?? "";
  if (NON_RESOURCE_CONFIG_TYPES.has(resourceType)) return { kind: "skipped-non-resource" };

  const region = item.awsRegion && item.awsRegion !== CONFIG_GLOBAL_REGION ? item.awsRegion : undefined;
  const common = {
    accountId: item.accountId || undefined,
    region,
    sourceResourceType: resourceType || undefined
  };

  if (item.arn) return { kind: "resource", resource: { resourceId: item.arn, ...common } };

  const parsedType = serviceFromConfigType(resourceType);
  if (!parsedType || !item.resourceId) return { kind: "skipped-unidentifiable" };
  const syntheticArn = `arn:aws:${parsedType.service}:${region ?? ""}:${item.accountId ?? ""}:${parsedType.typeName}/${item.resourceId}`;
  return { kind: "resource", resource: { resourceId: syntheticArn, ...common } };
}

export type ConfigDiscoveryProgress = {
  batchIndex: number;
  batchCount: number;
  pagesFetched: number;
  resourcesDiscovered: number;
};

export type ConfigDiscoveryResult = {
  resources: DiscoveredResource[];
  queries: number;
  pagesFetched: number;
  itemsReturned: number;
  skippedNonResourceItems: number;
  skippedUnidentifiableItems: number;
  duplicateItems: number;
};

/**
 * Runs the aggregator queries to completion. `runQuery` executes one CLI call and returns
 * its stdout; retries and timeouts are the caller's concern.
 */
export async function discoverViaConfigAggregator(options: {
  aggregatorName: string;
  aggregatorRegion?: string;
  scope: ConfigAggregatorScope;
  runQuery: (args: string[]) => Promise<string>;
  onProgress?: (progress: ConfigDiscoveryProgress) => void;
}): Promise<ConfigDiscoveryResult> {
  const expressions = buildConfigQueryExpressions(options.scope);
  const byId = new Map<string, DiscoveredResource>();
  const result: ConfigDiscoveryResult = {
    resources: [],
    queries: expressions.length,
    pagesFetched: 0,
    itemsReturned: 0,
    skippedNonResourceItems: 0,
    skippedUnidentifiableItems: 0,
    duplicateItems: 0
  };

  for (const [batchIndex, expression] of expressions.entries()) {
    let token: string | undefined;
    do {
      const stdout = await options.runQuery(
        buildConfigQueryArgs({
          aggregatorName: options.aggregatorName,
          aggregatorRegion: options.aggregatorRegion,
          expression,
          startingToken: token
        })
      );
      const page = parseConfigResultPage(stdout);
      result.pagesFetched += 1;
      result.itemsReturned += page.items.length;

      for (const item of page.items) {
        const outcome = toDiscoveredResource(item);
        if (outcome.kind === "skipped-non-resource") {
          result.skippedNonResourceItems += 1;
        } else if (outcome.kind === "skipped-unidentifiable") {
          result.skippedUnidentifiableItems += 1;
        } else if (byId.has(outcome.resource.resourceId)) {
          // Global resources can be recorded by more than one regional recorder.
          result.duplicateItems += 1;
        } else {
          byId.set(outcome.resource.resourceId, outcome.resource);
        }
      }

      token = page.nextToken;
      options.onProgress?.({
        batchIndex,
        batchCount: expressions.length,
        pagesFetched: result.pagesFetched,
        resourcesDiscovered: byId.size
      });
    } while (token);
  }

  result.resources = [...byId.values()];
  return result;
}

export type AutoCreatedCheckResult = {
  /** Resource ID (as discovery reports it) -> why it is considered auto-created. */
  reasons: Map<string, string>;
  pagesFetched: number;
  failed: Array<{ check: string; error: string }>;
};

const TAG_CHECK_ID = "controller-tags";

function firstLine(error: unknown): string {
  const message = error instanceof Error ? error.message : String(error);
  const line = message.split("\n").map((part) => part.trim()).find(Boolean) ?? "unknown error";
  return line.length > 300 ? `${line.slice(0, 297)}...` : line;
}

function vpcIdsOf(item: ConfigQueryItem): string[] {
  const ids = [item.configuration?.vpcId, ...(item.configuration?.attachments ?? []).map((attachment) => attachment.vpcId)];
  return ids.filter(Boolean) as string[];
}

/**
 * Finds resources that AWS or a controller created, which the main query cannot tell apart
 * from deliberately declared ones: default VPCs and their parts, AWS managed keys, and
 * anything carrying a controller's tag (Auto Scaling, EKS node groups, Kubernetes load
 * balancers). Each check is a narrow query, so the main query stays small.
 *
 * A check that fails is reported and skipped: its resources stay counted as candidates,
 * which is the behaviour without this step.
 */
export async function findAutoCreatedViaConfig(options: {
  aggregatorName: string;
  aggregatorRegion?: string;
  scope: ConfigAggregatorScope;
  rules: AwsAutoCreatedRules;
  runQuery: (args: string[]) => Promise<string>;
  onProgress?: (progress: { checkIndex: number; checkCount: number; pagesFetched: number }) => void;
}): Promise<AutoCreatedCheckResult> {
  const result: AutoCreatedCheckResult = { reasons: new Map(), pagesFetched: 0, failed: [] };

  const runCheck = async (where: string, select: string): Promise<ConfigQueryItem[]> => {
    const items: ConfigQueryItem[] = [];
    for (const expression of buildConfigQueryExpressions(options.scope, { select, where })) {
      let token: string | undefined;
      do {
        const stdout = await options.runQuery(
          buildConfigQueryArgs({ aggregatorName: options.aggregatorName, aggregatorRegion: options.aggregatorRegion, expression, startingToken: token })
        );
        const page = parseConfigResultPage(stdout);
        result.pagesFetched += 1;
        items.push(...page.items);
        token = page.nextToken;
      } while (token);
    }
    return items;
  };

  const mark = (item: ConfigQueryItem, reason: string) => {
    const outcome = toDiscoveredResource(item);
    if (outcome.kind === "resource" && !result.reasons.has(outcome.resource.resourceId)) result.reasons.set(outcome.resource.resourceId, reason);
  };

  // Default VPCs first: the "member" checks need their IDs.
  const order = (marker: AwsConfigMarker) => (marker.defaultVpc === "defines" ? 0 : 1);
  const markers = [...options.rules.configMarkers].sort((a, b) => order(a) - order(b));
  const tagKeys = options.rules.tags.map((rule) => rule.key);
  const checkCount = markers.length + (tagKeys.length > 0 ? 1 : 0);
  const defaultVpcIds = new Set<string>();
  let defaultVpcsKnown = !markers.some((marker) => marker.defaultVpc === "defines");

  for (const [checkIndex, marker] of markers.entries()) {
    options.onProgress?.({ checkIndex, checkCount, pagesFetched: result.pagesFetched });
    if (marker.defaultVpc === "member" && !defaultVpcsKnown) {
      result.failed.push({ check: marker.id, error: "Skipped: the default VPCs could not be listed" });
      continue;
    }
    try {
      const items = await runCheck(marker.where, `${CONFIG_BASE_FIELDS}, configuration.vpcId, configuration.attachments.vpcId`);
      // A check may only mark the resource type it asks about, whatever the query returns.
      const expectedType = /^resourceType = '([^']+)'/.exec(marker.where)?.[1];
      for (const item of items) {
        if (expectedType && item.resourceType !== expectedType) continue;
        if (marker.defaultVpc === "defines") {
          if (item.resourceId) defaultVpcIds.add(item.resourceId);
          mark(item, marker.reason);
        } else if (marker.defaultVpc === "member") {
          if (vpcIdsOf(item).some((vpcId) => defaultVpcIds.has(vpcId))) mark(item, marker.reason);
        } else {
          mark(item, marker.reason);
        }
      }
      if (marker.defaultVpc === "defines") defaultVpcsKnown = true;
    } catch (error) {
      result.failed.push({ check: marker.id, error: firstLine(error) });
    }
  }

  if (tagKeys.length > 0) {
    options.onProgress?.({ checkIndex: markers.length, checkCount, pagesFetched: result.pagesFetched });
    try {
      assertAll(tagKeys, CONFIG_TAG_KEY_PATTERN, "tag key");
      const items = await runCheck(`tags.key IN (${quoteList(tagKeys)})`, `${CONFIG_BASE_FIELDS}, tags`);
      for (const item of items) {
        const outcome = toDiscoveredResource(item);
        if (outcome.kind !== "resource") continue;
        const keys = (item.tags ?? []).map((tag) => tag.key).filter(Boolean) as string[];
        const reason = findAutoCreatedTagReason(options.rules, outcome.resource.resourceId, keys);
        if (reason && !result.reasons.has(outcome.resource.resourceId)) result.reasons.set(outcome.resource.resourceId, reason);
      }
    } catch (error) {
      result.failed.push({ check: TAG_CHECK_ID, error: firstLine(error) });
    }
  }

  return result;
}

export type ConfigAggregatorSummary = {
  name: string;
  /** "organization" aggregators follow AWS Organizations; "accounts" list accounts explicitly. */
  type: "organization" | "accounts" | "unknown";
  allRegions: boolean;
  regions: string[];
  /** Only known for "accounts" aggregators; an organization aggregator covers the whole org. */
  accountCount?: number;
};

export function parseConfigAggregators(stdout: string): ConfigAggregatorSummary[] {
  const payload = JSON.parse(stdout) as {
    ConfigurationAggregators?: Array<{
      ConfigurationAggregatorName?: string;
      AccountAggregationSources?: Array<{ AccountIds?: string[]; AllAwsRegions?: boolean; AwsRegions?: string[] }>;
      OrganizationAggregationSource?: { AllAwsRegions?: boolean; AwsRegions?: string[] };
    }>;
  };
  const summaries: ConfigAggregatorSummary[] = [];
  for (const aggregator of payload.ConfigurationAggregators ?? []) {
    if (!aggregator.ConfigurationAggregatorName) continue;
    const org = aggregator.OrganizationAggregationSource;
    const accountSources = aggregator.AccountAggregationSources ?? [];
    if (org) {
      summaries.push({
        name: aggregator.ConfigurationAggregatorName,
        type: "organization",
        allRegions: org.AllAwsRegions === true,
        regions: org.AwsRegions ?? []
      });
    } else if (accountSources.length > 0) {
      summaries.push({
        name: aggregator.ConfigurationAggregatorName,
        type: "accounts",
        allRegions: accountSources.every((source) => source.AllAwsRegions === true),
        regions: [...new Set(accountSources.flatMap((source) => source.AwsRegions ?? []))].sort(),
        accountCount: new Set(accountSources.flatMap((source) => source.AccountIds ?? [])).size
      });
    } else {
      summaries.push({ name: aggregator.ConfigurationAggregatorName, type: "unknown", allRegions: false, regions: [] });
    }
  }
  return summaries.sort((a, b) => a.name.localeCompare(b.name));
}

export function buildListAggregatorsArgs(aggregatorRegion?: string): string[] {
  const args = ["configservice", "describe-configuration-aggregators", "--output", "json"];
  if (aggregatorRegion) args.push("--region", aggregatorRegion);
  return args;
}
