import { updateEstimatorRun } from "./estimator-store.js";
import type {
  AwsEstimatorRequest,
  AzureEstimatorRequest,
  DiscoveredResource,
  EstimatorDiscoveryInfo,
  EstimatorProvider,
  EstimatorResourceRow,
  EstimatorRunProgress,
  GcpEstimatorRequest
} from "./estimator-types.js";
import { loadMapping, type AwsAutoCreatedRules, type LoadedMapping } from "./estimator-mapping.js";
import {
  awsAccountIdFromArn,
  bucketSupersededTaskDefinitions,
  buildDiagnostics,
  classifyWithMapping,
  findAutoCreatedTagReason,
  parseResourceIdentity,
  summarizeByAccount,
  summarizeRows
} from "./estimator-analysis.js";
import {
  buildListAggregatorsArgs,
  discoverViaConfigAggregator,
  findAutoCreatedViaConfig,
  parseConfigAggregators,
  type ConfigAggregatorSummary
} from "./aws-config-discovery.js";
import { runCliWithRetry, type CliCommand, type CliRetryEvent, type CliRunOptions } from "./cli-runner.js";
import { logger } from "./logger.js";
import {
  DEFAULT_ACCOUNT_CONCURRENCY,
  MAX_ACCOUNT_CONCURRENCY,
  buildAssumeRoleArgs,
  describeAccountError,
  mergeDiscoveries,
  parseAssumedRoleEnv,
  runPool,
  scanTaggingRegions
} from "./aws-tagging-discovery.js";

/**
 * All cloud CLI calls go through the shared runner: each call has a time limit and
 * throttling/transient failures are retried with exponential backoff.
 */
async function runCli(
  command: CliCommand,
  args: string[],
  envOverrides: Record<string, string>,
  options: CliRunOptions = {}
): Promise<string> {
  return runCliWithRetry(command, args, envOverrides, {
    ...options,
    onRetry: (event) => {
      logger.warn(
        { command: event.command, operation: args.slice(0, 2).join(" "), attempt: event.attempt, kind: event.kind, delayMs: event.delayMs },
        "Cloud CLI call failed; retrying"
      );
      options.onRetry?.(event);
    }
  });
}

export type ProgressReporter = {
  update(patch: Partial<Omit<EstimatorRunProgress, "startedAt" | "updatedAt" | "retries" | "lastRetryReason">>): void;
  noteRetry(event: CliRetryEvent): void;
  snapshot(): EstimatorRunProgress;
};

/**
 * Tracks live progress for one run. Updates are written to the in-memory store only
 * (persist:false) so a long discovery does not rewrite the store file on every page.
 */
export function createProgressReporter(runId: string): ProgressReporter {
  const startedAt = new Date().toISOString();
  let current: EstimatorRunProgress = {
    phase: "discovering",
    resourcesDiscovered: 0,
    resourcesClassified: 0,
    pagesFetched: 0,
    retries: 0,
    startedAt,
    updatedAt: startedAt
  };
  const flush = () => {
    updateEstimatorRun(runId, (run) => ({ ...run, progress: current }), { persist: false });
  };
  flush();
  return {
    update(patch) {
      current = { ...current, ...patch, updatedAt: new Date().toISOString() };
      flush();
    },
    noteRetry(event) {
      current = {
        ...current,
        retries: current.retries + 1,
        lastRetryReason: `${event.kind} on ${event.command} call (attempt ${event.attempt} of ${event.maxAttempts})`,
        updatedAt: new Date().toISOString()
      };
      flush();
    },
    snapshot() {
      return current;
    }
  };
}

/** CLI runner bound to a run's progress, so retries show up in the status response. */
type JobCli = (command: CliCommand, args: string[], envOverrides: Record<string, string>) => Promise<string>;

function createJobCli(progress: ProgressReporter): JobCli {
  return (command, args, envOverrides) => runCli(command, args, envOverrides, { onRetry: (event) => progress.noteRetry(event) });
}

const CLASSIFY_CHUNK_SIZE = 500;

function yieldToEventLoop(): Promise<void> {
  return new Promise((resolve) => setImmediate(resolve));
}

function buildAwsEnvOverrides(request: AwsEstimatorRequest): Record<string, string> {
  const execution = request.executionEnv;
  if (!execution) return {};
  const env: Record<string, string> = {};
  if (execution.awsRegion) {
    env.AWS_REGION = execution.awsRegion;
    env.AWS_DEFAULT_REGION = execution.awsRegion;
  }
  if (execution.awsProfile) env.AWS_PROFILE = execution.awsProfile;
  if (execution.awsAccessKeyId) env.AWS_ACCESS_KEY_ID = execution.awsAccessKeyId;
  if (execution.awsSecretAccessKey) env.AWS_SECRET_ACCESS_KEY = execution.awsSecretAccessKey;
  if (execution.awsSessionToken) env.AWS_SESSION_TOKEN = execution.awsSessionToken;
  return env;
}

function buildAzureEnvOverrides(request: AzureEstimatorRequest): Record<string, string> {
  const execution = request.executionEnv;
  if (!execution) return {};
  const env: Record<string, string> = {};
  if (execution.azureSubscriptionId) env.AZURE_SUBSCRIPTION_ID = execution.azureSubscriptionId;
  if (execution.azureTenantId) env.AZURE_TENANT_ID = execution.azureTenantId;
  return env;
}

function buildGcpEnvOverrides(request: GcpEstimatorRequest): Record<string, string> {
  const execution = request.executionEnv;
  if (!execution) return {};
  const env: Record<string, string> = {};
  if (execution.gcpProjectId) env.CLOUDSDK_CORE_PROJECT = execution.gcpProjectId;
  if (execution.googleApplicationCredentials) {
    env.GOOGLE_APPLICATION_CREDENTIALS = execution.googleApplicationCredentials;
  }
  return env;
}

function isPermissionDenied(message: string): boolean {
  return (
    message.includes("AccessDenied") ||
    message.includes("AccessDeniedException") ||
    message.includes("UnauthorizedOperation") ||
    message.includes("is not authorized to perform") ||
    message.includes("does not have authorization") ||
    message.includes("permission denied")
  );
}

async function resolveAwsServiceDiscoveryNamespace(
  resourceArn: string,
  envOverrides: Record<string, string>,
  cli: JobCli
): Promise<{ terraformType?: string; permissionDenied?: boolean; reasonDetail?: string }> {
  const parsed = parseResourceIdentity("aws", resourceArn);
  if (parsed.service !== "servicediscovery") return {};
  const resourcePath = resourceArn.split(":")[5] ?? "";
  if (!resourcePath.startsWith("namespace/")) return {};
  const namespaceId = resourcePath.split("/")[1];
  if (!namespaceId) return {};

  const args = ["servicediscovery", "get-namespace", "--id", namespaceId, "--output", "json"];
  if (parsed.region) args.push("--region", parsed.region);

  try {
    const stdout = await cli("aws", args, envOverrides);
    const payload = JSON.parse(stdout) as { Namespace?: { Type?: string } };
    if (payload.Namespace?.Type === "DNS_PRIVATE") return { terraformType: "aws_service_discovery_private_dns_namespace" };
    if (payload.Namespace?.Type === "DNS_PUBLIC") return { terraformType: "aws_service_discovery_public_dns_namespace" };
    if (payload.Namespace?.Type === "HTTP") return { terraformType: "aws_service_discovery_http_namespace" };
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    if (isPermissionDenied(message)) {
      return { permissionDenied: true, reasonDetail: "Missing permission for servicediscovery:GetNamespace" };
    }
  }
  return {};
}

async function classifyAwsResource(
  resource: DiscoveredResource,
  mapping: LoadedMapping,
  envOverrides: Record<string, string>,
  cli: JobCli
): Promise<EstimatorResourceRow> {
  const resourceId = resource.resourceId;
  const base = classifyWithMapping("aws", resourceId, mapping.entries, {
    typeIndex: mapping.typeIndex,
    autoCreatedReason: resource.autoCreatedReason
  });
  if (base.reasonCode !== "UNMAPPED_TYPE") return base;

  const resolved = await resolveAwsServiceDiscoveryNamespace(resourceId, envOverrides, cli);
  if (resolved.terraformType) {
    return {
      ...base,
      classification: "rum_candidate",
      reasonCode: "MAPPED_MANAGEABLE",
      terraformResourceType: resolved.terraformType,
      typeMatch: "exact"
    };
  }
  if (resolved.permissionDenied) {
    return {
      ...base,
      reasonCode: "PERMISSION_DENIED",
      reasonDetail: resolved.reasonDetail
    };
  }
  return base;
}

type DiscoveryContext = {
  cli: JobCli;
  progress: ProgressReporter;
  mapping: LoadedMapping;
};

function tagReasonFinder(rules: AwsAutoCreatedRules | undefined) {
  return rules ? (arn: string, tagKeys: string[]) => findAutoCreatedTagReason(rules, arn, tagKeys) : undefined;
}

type DiscoveryResult = {
  resources: DiscoveredResource[];
  info: EstimatorDiscoveryInfo;
};

function fromIds(ids: string[], info: EstimatorDiscoveryInfo): DiscoveryResult {
  return { resources: ids.map((resourceId) => ({ resourceId })), info };
}

async function discoverAwsViaConfigAggregator(
  request: AwsEstimatorRequest,
  envOverrides: Record<string, string>,
  ctx: DiscoveryContext
): Promise<DiscoveryResult> {
  const aggregator = request.scope.configAggregator;
  if (!aggregator?.name) {
    throw new Error("configAggregator.name is required when discoverySource is config-aggregator");
  }
  ctx.progress.update({ detail: `Querying AWS Config aggregator ${aggregator.name}` });

  const result = await discoverViaConfigAggregator({
    aggregatorName: aggregator.name,
    aggregatorRegion: aggregator.region,
    scope: { regions: request.scope.regions, accountIds: aggregator.accountIds },
    runQuery: (args) => ctx.cli("aws", args, envOverrides),
    onProgress: (progress) =>
      ctx.progress.update({
        detail:
          progress.batchCount > 1
            ? `Querying AWS Config aggregator ${aggregator.name} (account batch ${progress.batchIndex + 1} of ${progress.batchCount})`
            : `Querying AWS Config aggregator ${aggregator.name}`,
        pagesFetched: progress.pagesFetched,
        resourcesDiscovered: progress.resourcesDiscovered,
        unitsCompleted: progress.batchCount > 1 ? progress.batchIndex : undefined,
        unitsTotal: progress.batchCount > 1 ? progress.batchCount : undefined
      })
  });

  // Narrow follow-up queries for resources AWS or a controller created (default VPCs,
  // Auto Scaling instances...), which the main query cannot tell from declared ones.
  const rules = ctx.mapping.typeIndex?.autoCreated;
  let resources = result.resources;
  let pagesFetched = result.pagesFetched;
  let autoCreatedMarked: number | undefined;
  let autoCreatedChecksFailed: Array<{ check: string; error: string }> | undefined;
  if (rules && (rules.configMarkers.length > 0 || rules.tags.length > 0)) {
    const checks = await findAutoCreatedViaConfig({
      aggregatorName: aggregator.name,
      aggregatorRegion: aggregator.region,
      scope: { regions: request.scope.regions, accountIds: aggregator.accountIds },
      rules,
      runQuery: (args) => ctx.cli("aws", args, envOverrides),
      onProgress: (progress) =>
        ctx.progress.update({
          detail: `Checking for resources AWS creates automatically (${progress.checkIndex + 1} of ${progress.checkCount})`,
          pagesFetched: result.pagesFetched + progress.pagesFetched,
          unitsCompleted: undefined,
          unitsTotal: undefined
        })
    });
    pagesFetched += checks.pagesFetched;
    autoCreatedMarked = 0;
    resources = resources.map((resource) => {
      const autoCreatedReason = checks.reasons.get(resource.resourceId);
      if (!autoCreatedReason) return resource;
      autoCreatedMarked = (autoCreatedMarked ?? 0) + 1;
      return { ...resource, autoCreatedReason };
    });
    if (checks.failed.length > 0) {
      autoCreatedChecksFailed = checks.failed;
      logger.warn({ failed: checks.failed.map((entry) => entry.check) }, "Some auto-created resource checks could not run");
    }
  }

  return {
    resources,
    info: {
      source: "config-aggregator",
      aggregatorName: aggregator.name,
      aggregatorRegion: aggregator.region,
      queries: result.queries,
      pagesFetched,
      skippedNonResourceItems: result.skippedNonResourceItems,
      skippedUnidentifiableItems: result.skippedUnidentifiableItems,
      duplicateItems: result.duplicateItems,
      autoCreatedMarked,
      autoCreatedChecksFailed
    }
  };
}

async function discoverAwsResources(
  request: AwsEstimatorRequest,
  envOverrides: Record<string, string>,
  ctx: DiscoveryContext
): Promise<DiscoveryResult> {
  const configuredRegions =
    request.scope.regions && request.scope.regions.length > 0
      ? request.scope.regions
      : [envOverrides.AWS_REGION ?? process.env.AWS_REGION ?? "us-east-1"];

  const scan = await scanTaggingRegions({
    regions: configuredRegions,
    tagFilters: request.scope.tagFilters,
    autoCreatedReasonFor: tagReasonFinder(ctx.mapping.typeIndex?.autoCreated),
    runQuery: (args) => ctx.cli("aws", args, envOverrides),
    onRegionStart: (region, index, total) =>
      ctx.progress.update({ detail: `Region ${index + 1} of ${total} (${region})`, unitsCompleted: index, unitsTotal: total }),
    onPage: (pagesFetched, resourcesDiscovered) => ctx.progress.update({ pagesFetched, resourcesDiscovered }),
    onRegionDone: (index) => ctx.progress.update({ unitsCompleted: index + 1 })
  });
  return {
    resources: scan.arns.map((resourceId) => ({ resourceId, autoCreatedReason: scan.autoCreated.get(resourceId) })),
    info: { source: "tagging-api", pagesFetched: scan.pagesFetched }
  };
}

/**
 * Config aggregator query plus a Tagging API scan of every account, merged by ARN.
 * An account whose scan fails is recorded and skipped; the run does not fail for it.
 */
async function discoverAwsCombined(
  request: AwsEstimatorRequest,
  envOverrides: Record<string, string>,
  ctx: DiscoveryContext
): Promise<DiscoveryResult> {
  const config = await discoverAwsViaConfigAggregator(request, envOverrides, ctx);
  const tagging = request.scope.tagging ?? {};

  const configAccounts = [...new Set(config.resources.map((resource) => resource.accountId).filter(Boolean) as string[])].sort();
  const regions =
    request.scope.regions && request.scope.regions.length > 0
      ? request.scope.regions
      : // us-east-1 is where the Tagging API returns global resources.
        [...new Set([...(config.resources.map((resource) => resource.region).filter(Boolean) as string[]), "us-east-1"])].sort();

  // With a role, every account is scanned through that role. Without one, only the account
  // the supplied credentials belong to can be scanned.
  const targets: Array<{ accountId?: string }> = tagging.roleName
    ? (tagging.accountIds ?? request.scope.configAggregator?.accountIds ?? configAccounts).map((accountId) => ({ accountId }))
    : [{}];
  const concurrency = Math.min(MAX_ACCOUNT_CONCURRENCY, tagging.concurrency ?? DEFAULT_ACCOUNT_CONCURRENCY);

  let accountsDone = 0;
  let taggingPages = 0;
  const describe = () => `Tagging API: ${accountsDone} of ${targets.length} account${targets.length === 1 ? "" : "s"} scanned`;
  ctx.progress.update({ detail: describe(), unitsCompleted: 0, unitsTotal: targets.length });

  const outcomes = await runPool(targets, concurrency, async (target) => {
    try {
      let env = envOverrides;
      if (target.accountId && tagging.roleName) {
        // Assumed just before the scan so the credentials cannot expire while queued.
        const stdout = await ctx.cli("aws", buildAssumeRoleArgs(target.accountId, tagging.roleName, tagging.externalId), envOverrides);
        env = { ...envOverrides, ...parseAssumedRoleEnv(stdout) };
      }
      const scan = await scanTaggingRegions({
        regions,
        autoCreatedReasonFor: tagReasonFinder(ctx.mapping.typeIndex?.autoCreated),
        runQuery: (args) => ctx.cli("aws", args, env)
      });
      taggingPages += scan.pagesFetched;
      return scan;
    } finally {
      accountsDone += 1;
      ctx.progress.update({
        detail: describe(),
        unitsCompleted: accountsDone,
        // resourcesDiscovered stays at the Config count until the merge: adding raw Tagging
        // API counts here would double-count everything both sources return.
        pagesFetched: (config.info.pagesFetched ?? 0) + taggingPages
      });
    }
  });

  const taggingArns: string[] = [];
  const failedAccounts: Array<{ accountId: string; error: string }> = [];
  const taggingAutoCreated = new Map<string, string>();
  outcomes.forEach((outcome, index) => {
    if (outcome.ok) {
      taggingArns.push(...outcome.value.arns);
      for (const [arn, reason] of outcome.value.autoCreated) taggingAutoCreated.set(arn, reason);
    } else failedAccounts.push({ accountId: targets[index].accountId ?? "credentials account", error: describeAccountError(outcome.error) });
  });
  if (failedAccounts.length > 0) {
    logger.warn({ failed: failedAccounts.length, total: targets.length }, "Tagging API scan failed for some accounts");
  }

  const merged = mergeDiscoveries(config.resources, taggingArns, taggingAutoCreated);
  return {
    resources: merged.resources,
    info: {
      ...config.info,
      source: "combined",
      pagesFetched: (config.info.pagesFetched ?? 0) + taggingPages,
      foundByBoth: merged.foundByBoth,
      foundByConfigOnly: merged.foundByConfigOnly,
      foundByTaggingOnly: merged.foundByTaggingOnly,
      taggingAccountsScanned: targets.length - failedAccounts.length,
      taggingRegions: regions,
      failedAccounts: failedAccounts.length > 0 ? failedAccounts : undefined
    }
  };
}

async function discoverAzureResources(
  request: AzureEstimatorRequest,
  envOverrides: Record<string, string>,
  ctx: DiscoveryContext
): Promise<DiscoveryResult> {
  const args = ["resource", "list", "--output", "json"];
  const subscriptionId = request.scope.subscriptionId ?? request.executionEnv?.azureSubscriptionId;
  if (subscriptionId) args.push("--subscription", subscriptionId);
  if (request.scope.resourceGroup) args.push("--resource-group", request.scope.resourceGroup);

  const stdout = await ctx.cli("az", args, envOverrides);
  const parsed = JSON.parse(stdout) as Array<{ id?: string }>;
  const ids = parsed.map((item) => item.id).filter(Boolean) as string[];
  ctx.progress.update({ pagesFetched: 1, resourcesDiscovered: ids.length });
  return fromIds(ids, { source: "azure-resource-list", pagesFetched: 1 });
}

async function discoverGcpResources(
  request: GcpEstimatorRequest,
  envOverrides: Record<string, string>,
  ctx: DiscoveryContext
): Promise<DiscoveryResult> {
  const projectId = request.scope.projectId || request.executionEnv?.gcpProjectId;
  if (!projectId) {
    throw new Error("gcp projectId is required for GCP estimator runs");
  }
  const args = ["asset", "search-all-resources", `--scope=projects/${projectId}`, "--format=json"];
  const stdout = await ctx.cli("gcloud", args, envOverrides);
  const parsed = JSON.parse(stdout) as Array<{ name?: string }>;
  const names = parsed.map((item) => item.name).filter(Boolean) as string[];
  ctx.progress.update({ pagesFetched: 1, resourcesDiscovered: names.length });
  return fromIds(names, { source: "gcp-asset-search", pagesFetched: 1 });
}

async function runEstimatorJob(
  provider: EstimatorProvider,
  runId: string,
  discover: (ctx: DiscoveryContext) => Promise<DiscoveryResult>,
  classify: (resource: DiscoveredResource, mapping: LoadedMapping, ctx: DiscoveryContext) => Promise<EstimatorResourceRow> | EstimatorResourceRow
): Promise<void> {
  updateEstimatorRun(runId, (run) => ({ ...run, status: "running", errorMessage: undefined }));
  const progress = createProgressReporter(runId);
  try {
    const enableVar =
      provider === "aws"
        ? process.env.ENABLE_AWS_UNMANAGED_ESTIMATOR
        : provider === "azure"
          ? process.env.ENABLE_AZURE_UNMANAGED_ESTIMATOR
          : process.env.ENABLE_GCP_UNMANAGED_ESTIMATOR;
    if (enableVar !== "true") {
      throw new Error(`${provider.toUpperCase()} unmanaged estimator is disabled. Set ENABLE_${provider.toUpperCase()}_UNMANAGED_ESTIMATOR=true`);
    }

    const mapping = await loadMapping(provider);
    const ctx: DiscoveryContext = { cli: createJobCli(progress), progress, mapping };
    const discovery = await discover(ctx);
    const discovered = discovery.resources;

    progress.update({ phase: "classifying", detail: undefined, resourcesDiscovered: discovered.length });
    let classified: EstimatorResourceRow[] = [];
    for (let start = 0; start < discovered.length; start += CLASSIFY_CHUNK_SIZE) {
      const chunk = discovered.slice(start, start + CLASSIFY_CHUNK_SIZE);
      classified.push(...(await Promise.all(chunk.map((resource) => classify(resource, mapping, ctx)))));
      progress.update({ resourcesClassified: classified.length });
      // Let pending status requests through while a very large run is classified.
      await yieldToEventLoop();
    }

    progress.update({ phase: "finalizing" });
    if (provider === "aws") classified = bucketSupersededTaskDefinitions(classified);
    const summary = summarizeRows(classified);
    const byAccount = summarizeByAccount(classified);
    const diagnostics = buildDiagnostics(classified);
    const regionsObserved = [...new Set(classified.map((row) => row.region).filter(Boolean) as string[])].sort();
    const discoveryInfo: EstimatorDiscoveryInfo = {
      ...discovery.info,
      accountsObserved: byAccount.length > 0 ? byAccount.length : undefined,
      regionsObserved: regionsObserved.length > 0 ? regionsObserved : undefined
    };

    updateEstimatorRun(runId, (run) => ({
      ...run,
      status: "completed",
      progress: progress.snapshot(),
      summary,
      byAccount: byAccount.length > 0 ? byAccount : undefined,
      discovery: discoveryInfo,
      diagnostics,
      mapping: mapping.metadata,
      resources: classified
    }));
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    // Progress is kept on failure so the record shows how far the run got.
    updateEstimatorRun(runId, (run) => ({ ...run, status: "failed", errorMessage: message, progress: progress.snapshot() }));
  }
}

/** Adds account, region and source type from discovery to a classified AWS row. */
function withAwsDiscoveryFields(row: EstimatorResourceRow, resource: DiscoveredResource): EstimatorResourceRow {
  return {
    ...row,
    region: resource.region ?? row.region,
    accountId: resource.accountId ?? awsAccountIdFromArn(resource.resourceId),
    sourceResourceType: resource.sourceResourceType,
    discoveredBy: resource.discoveredBy
  };
}

export async function runAwsEstimatorJob(runId: string, request: AwsEstimatorRequest): Promise<void> {
  const envOverrides = buildAwsEnvOverrides(request);
  const source = request.scope.discoverySource ?? "tagging-api";
  const useConfig = source !== "tagging-api";
  await runEstimatorJob(
    "aws",
    runId,
    (ctx) =>
      source === "combined"
        ? discoverAwsCombined(request, envOverrides, ctx)
        : source === "config-aggregator"
          ? discoverAwsViaConfigAggregator(request, envOverrides, ctx)
          : discoverAwsResources(request, envOverrides, ctx),
    async (resource, mapping, ctx) => {
      // The per-resource Cloud Map lookup needs credentials in the resource's own account,
      // which aggregator credentials do not have, so it only runs on the tagging path.
      const row = useConfig
        ? classifyWithMapping("aws", resource.resourceId, mapping.entries, {
            typeIndex: mapping.typeIndex,
            sourceResourceType: resource.sourceResourceType,
            autoCreatedReason: resource.autoCreatedReason
          })
        : await classifyAwsResource(resource, mapping, envOverrides, ctx.cli);
      return withAwsDiscoveryFields(row, resource);
    }
  );
}

export async function runAzureEstimatorJob(runId: string, request: AzureEstimatorRequest): Promise<void> {
  const envOverrides = buildAzureEnvOverrides(request);
  await runEstimatorJob(
    "azure",
    runId,
    (ctx) => discoverAzureResources(request, envOverrides, ctx),
    (resource, mapping) => classifyWithMapping("azure", resource.resourceId, mapping.entries)
  );
}

export async function runGcpEstimatorJob(runId: string, request: GcpEstimatorRequest): Promise<void> {
  const envOverrides = buildGcpEnvOverrides(request);
  await runEstimatorJob(
    "gcp",
    runId,
    (ctx) => discoverGcpResources(request, envOverrides, ctx),
    (resource, mapping) => classifyWithMapping("gcp", resource.resourceId, mapping.entries)
  );
}

/** Lists the AWS Config aggregators visible to the given credentials. */
export async function listAwsConfigAggregators(
  executionEnv: AwsEstimatorRequest["executionEnv"],
  aggregatorRegion?: string
): Promise<ConfigAggregatorSummary[]> {
  if (process.env.ENABLE_AWS_UNMANAGED_ESTIMATOR !== "true") {
    throw new Error("AWS unmanaged estimator is disabled. Set ENABLE_AWS_UNMANAGED_ESTIMATOR=true");
  }
  const envOverrides = buildAwsEnvOverrides({ scope: {}, executionEnv });
  const stdout = await runCli("aws", buildListAggregatorsArgs(aggregatorRegion), envOverrides);
  return parseConfigAggregators(stdout);
}
