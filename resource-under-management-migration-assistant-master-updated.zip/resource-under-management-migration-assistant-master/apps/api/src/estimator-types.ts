export type EstimatorRunStatus = "queued" | "running" | "completed" | "failed";
export type EstimatorProvider = "aws" | "azure" | "gcp";

/**
 * How AWS resources are discovered.
 * - "tagging-api": Resource Groups Tagging API. One account per run; only sees resources
 *   that are or were tagged. The default, and the original behaviour.
 * - "config-aggregator": one AWS Config aggregator query covering every account and
 *   region the aggregator collects, tagged or not. Limited to the types Config records.
 * - "combined": the aggregator query plus a Tagging API scan of each account, merged by
 *   ARN. The most complete option; each source covers gaps in the other.
 */
export type AwsDiscoverySource = "tagging-api" | "config-aggregator" | "combined";

export type AwsEstimatorRequest = {
  scope: {
    /** tagging-api: regions to scan (default: one). config-aggregator: optional filter (default: all). */
    regions?: string[];
    /** tagging-api only. */
    tagFilters?: Array<{ key: string; values?: string[] }>;
    discoverySource?: AwsDiscoverySource;
    /** Required when discoverySource is "config-aggregator". */
    configAggregator?: {
      name: string;
      /** Region the aggregator lives in, when it differs from the credentials' default region. */
      region?: string;
      /** Optional filter; omit to include every account in the aggregator. */
      accountIds?: string[];
    };
    /** Tagging API settings for the "combined" source. */
    tagging?: {
      /**
       * Role to assume in each account for the Tagging API scan. Without it, only the
       * account the supplied credentials belong to is scanned.
       */
      roleName?: string;
      externalId?: string;
      /** Accounts to scan. Defaults to the aggregator account filter, else every account Config returned. */
      accountIds?: string[];
      /** Accounts scanned in parallel (default 5). */
      concurrency?: number;
    };
  };
  executionEnv?: {
    awsRegion?: string;
    awsProfile?: string;
    awsAccessKeyId?: string;
    awsSecretAccessKey?: string;
    awsSessionToken?: string;
  };
};

export type AzureEstimatorRequest = {
  scope: {
    subscriptionId?: string;
    resourceGroup?: string;
  };
  executionEnv?: {
    azureSubscriptionId?: string;
    azureTenantId?: string;
  };
};

export type GcpEstimatorRequest = {
  scope: {
    projectId: string;
  };
  executionEnv?: {
    gcpProjectId?: string;
    googleApplicationCredentials?: string;
  };
};

/** A resource found by discovery, before classification. */
export type DiscoveredResource = {
  resourceId: string;
  accountId?: string;
  region?: string;
  /** Type name from the discovery source, e.g. the AWS Config type "AWS::EC2::Instance". */
  sourceResourceType?: string;
  /** Which source returned it, for the "combined" discovery source. */
  discoveredBy?: "config" | "tagging" | "both";
  /**
   * Set when discovery found evidence that AWS or another resource created this one (a
   * controller's tag, membership of the default VPC). See EstimatorResourceRow.classification.
   */
  autoCreatedReason?: string;
};

export type EstimatorResourceRow = {
  resourceId: string;
  service: string;
  resourceType: string;
  region?: string;
  accountId?: string;
  sourceResourceType?: string;
  discoveredBy?: "config" | "tagging" | "both";
  /**
   * How the Terraform type was chosen (AWS only). "exact": from the resource's own type.
   * "service": no entry for this resource type, so the service's default type was used and
   * the label may be wrong even though the resource is counted.
   */
  typeMatch?: "exact" | "service";
  /**
   * "likely_auto_created": Terraform could manage it, but it is normally created by AWS or by
   * another resource (an instance's network interface, an Auto Scaling group's instances, the
   * default VPC), so it is rarely in Terraform state. Reported separately and left out of the
   * RUM candidate count; reasonDetail says why.
   */
  classification: "rum_candidate" | "likely_auto_created" | "excluded" | "not_manageable" | "unmapped";
  reasonCode:
    | "MAPPED_MANAGEABLE"
    | "LIKELY_AUTO_CREATED"
    | "MAPPED_EXCLUDED"
    | "NOT_SUPPORTED_BY_PROVIDER"
    | "UNMAPPED_TYPE"
    | "PERMISSION_DENIED";
  reasonDetail?: string;
  terraformResourceType?: string;
};

export type EstimatorMappingMetadata = {
  provider: EstimatorProvider;
  mappingVersion: string;
  updatedAt: string;
  source?: string;
  providerVersionConstraint?: string;
  providerVersionResolved?: string;
  totalMappings: number;
  /** AWS only: entries in the resource-type-level mapping. */
  resourceTypeMappings?: number;
  staleThresholdDays: number;
  ageDays: number;
  isStale: boolean;
};

export type EstimatorRunDiagnostics = {
  mappedResources: number;
  coveragePct: number;
  /** Resources labelled with their service's default Terraform type rather than their own. */
  serviceLevelMatches?: number;
  permissionDenied: number;
  topMissingPermissions: Array<{
    permission: string;
    count: number;
  }>;
  topUnmappedPrefixes: Array<{
    key: string;
    count: number;
    sampleResourceId: string;
  }>;
};

/**
 * Live progress for a queued/running run. Held in memory while the job runs and
 * returned by the status endpoint so clients can poll long runs cheaply.
 */
export type EstimatorRunProgress = {
  phase: "discovering" | "classifying" | "finalizing";
  /** Human-readable note about the current step, e.g. "Region 3 of 8 (eu-west-1)". */
  detail?: string;
  resourcesDiscovered: number;
  resourcesClassified: number;
  pagesFetched: number;
  /** Coarse units of work (regions or query batches), when the total is known up front. */
  unitsCompleted?: number;
  unitsTotal?: number;
  /** CLI calls retried so far because of throttling, timeouts or transient errors. */
  retries: number;
  lastRetryReason?: string;
  startedAt: string;
  updatedAt: string;
};

export type EstimatorSummary = {
  discoveredResources: number;
  rumCandidates: number;
  /** Manageable in principle but probably not in Terraform state; not part of rumCandidates. */
  likelyAutoCreated: number;
  nonManageable: number;
  unmapped: number;
};

export type EstimatorAccountSummary = EstimatorSummary & {
  accountId: string;
};

/** What discovery did, so a reader can judge how complete the numbers are. */
export type EstimatorDiscoveryInfo = {
  source: AwsDiscoverySource | "azure-resource-list" | "gcp-asset-search";
  aggregatorName?: string;
  aggregatorRegion?: string;
  queries?: number;
  pagesFetched?: number;
  /** Config items that are compliance/inventory records, not resources; excluded from counts. */
  skippedNonResourceItems?: number;
  /** Config items with neither an ARN nor a usable type and ID; excluded from counts. */
  skippedUnidentifiableItems?: number;
  duplicateItems?: number;
  accountsObserved?: number;
  regionsObserved?: string[];
  /** Combined source: how the two sources overlapped. */
  foundByBoth?: number;
  foundByConfigOnly?: number;
  foundByTaggingOnly?: number;
  taggingAccountsScanned?: number;
  taggingRegions?: string[];
  /**
   * Accounts whose Tagging API scan failed. The run still completes with what the other
   * accounts and AWS Config returned, so the totals are a lower bound for these accounts.
   */
  failedAccounts?: Array<{ accountId: string; error: string }>;
  /** Resources the extra AWS Config checks (controller tags, default VPC) marked as auto-created. */
  autoCreatedMarked?: number;
  /**
   * Auto-created checks that could not run. The run still completes, but resources those
   * checks would have moved out are still counted as RUM candidates.
   */
  autoCreatedChecksFailed?: Array<{ check: string; error: string }>;
};

export type EstimatorRunRecord = {
  id: string;
  provider: EstimatorProvider;
  status: EstimatorRunStatus;
  createdAt: string;
  updatedAt: string;
  request: AwsEstimatorRequest | AzureEstimatorRequest | GcpEstimatorRequest;
  errorMessage?: string;
  progress?: EstimatorRunProgress;
  summary?: EstimatorSummary;
  /** Per-account breakdown, present when resources carry an account ID (AWS). */
  byAccount?: EstimatorAccountSummary[];
  discovery?: EstimatorDiscoveryInfo;
  diagnostics?: EstimatorRunDiagnostics;
  mapping?: EstimatorMappingMetadata;
  resources?: EstimatorResourceRow[];
};

/** Run record as returned by status/list endpoints: everything except the resource rows. */
export type EstimatorRunView = Omit<EstimatorRunRecord, "resources"> & {
  resourceCount: number;
};
