import { readFileSync } from "node:fs";
import { join } from "node:path";
import { describe, expect, it } from "vitest";
import { findAutoCreatedViaConfig, type ConfigQueryItem } from "./aws-config-discovery.js";
import { mergeDiscoveries, scanTaggingRegions } from "./aws-tagging-discovery.js";
import {
  bucketSupersededTaskDefinitions,
  classifyWithMapping,
  findAutoCreatedReason,
  findAutoCreatedTagReason,
  summarizeRows
} from "./estimator-analysis.js";
import { buildAwsTypeIndex, type AwsTypeMappingFile, type MappingEntry } from "./estimator-mapping.js";
import type { EstimatorResourceRow } from "./estimator-types.js";
import { getWorkspaceRoot } from "./workspace-root.js";

const root = getWorkspaceRoot();
const typeFile = JSON.parse(readFileSync(join(root, "data", "mappings", "aws_resource_type_to_tf.json"), "utf-8")) as AwsTypeMappingFile;
const serviceFile = JSON.parse(readFileSync(join(root, "data", "mappings", "aws_resource_to_tf.json"), "utf-8")) as { mappings: MappingEntry[] };
const typeIndex = buildAwsTypeIndex(typeFile);
const rules = typeIndex.autoCreated;
const classify = (arn: string, sourceResourceType?: string, autoCreatedReason?: string) =>
  classifyWithMapping("aws", arn, serviceFile.mappings, { typeIndex, sourceResourceType, autoCreatedReason });

describe("likelyAutoCreated rules in the mapping file", () => {
  it("only lists kinds that would otherwise be RUM candidates", () => {
    const section = typeFile.likelyAutoCreated ?? {};
    for (const configType of Object.keys(section.configTypes ?? {})) {
      expect(typeFile.configTypes?.[configType], configType).toBeDefined();
      expect(typeFile.notManageable?.configTypes ?? []).not.toContain(configType);
    }
    for (const arnKey of Object.keys(section.arnTypes ?? {})) {
      expect(arnKey).toMatch(/^[a-z0-9-]+:[A-Za-z0-9-]+(\/[A-Za-z0-9-]+)?$/);
      expect(typeFile.notManageable?.arnTypes ?? []).not.toContain(arnKey);
    }
  });

  it("has a reason for every rule, unique check IDs and query-safe tag keys", () => {
    const section = typeFile.likelyAutoCreated ?? {};
    const reasons = [
      ...Object.values(section.configTypes ?? {}),
      ...Object.values(section.arnTypes ?? {}),
      ...(section.arnPatterns ?? []).map((entry) => entry.reason),
      ...(section.tags ?? []).map((entry) => entry.reason),
      ...(section.configMarkers ?? []).map((entry) => entry.reason)
    ];
    for (const reason of reasons) expect(reason.length).toBeGreaterThan(10);
    const ids = (section.configMarkers ?? []).map((marker) => marker.id);
    expect(new Set(ids).size).toBe(ids.length);
    for (const marker of section.configMarkers ?? []) expect(marker.where).toMatch(/^resourceType = 'AWS::[A-Za-z0-9]+::[A-Za-z0-9]+'/);
    for (const tag of section.tags ?? []) expect(tag.key).toMatch(/^[\w.:/=+@-]{1,128}$/);
  });
});

describe("findAutoCreatedReason", () => {
  it.each([
    ["arn:aws:ec2:us-east-1:1:network-interface/eni-1", "AWS::EC2::NetworkInterface"],
    ["arn:aws:ec2:us-east-1:1:volume/vol-1", "AWS::EC2::Volume"],
    ["arn:aws:ec2:us-east-1:1:snapshot/snap-1", undefined],
    ["arn:aws:ec2:us-east-1::image/ami-1", undefined],
    ["arn:aws:rds:us-east-1:1:snapshot:rds:orders-2026-11-01", "AWS::RDS::DBSnapshot"],
    ["arn:aws:rds:us-east-1:1:cluster-snapshot:rds:aurora-2026-11-01", undefined],
    ["arn:aws:iam::1:role/aws-service-role/ecs.amazonaws.com/AWSServiceRoleForECS", "AWS::IAM::Role"],
    ["arn:aws:iam::1:role/aws-reserved/sso.amazonaws.com/AWSReservedSSO_Admin_abc", "AWS::IAM::Role"],
    ["arn:aws:config:us-east-1:1:config-rule/aws-service-rule/securityhub.amazonaws.com/config-rule-abc", undefined],
    ["arn:aws:events:us-east-1:1:event-bus/default", "AWS::Events::EventBus"],
    ["arn:aws:athena:us-east-1:1:workgroup/primary", "AWS::Athena::WorkGroup"],
    ["arn:aws:codedeploy:us-east-1:1:deploymentconfig:CodeDeployDefault.OneAtATime", "AWS::CodeDeploy::DeploymentConfig"],
    ["arn:aws:rds:us-east-1:1:pg:default.mysql8.0", undefined],
    ["arn:aws:rds:us-east-1:1:og:default:mysql-8-0", undefined],
    ["arn:aws:kms:us-east-1:1:alias/aws/ebs", undefined],
    ["arn:aws:iam::1:role/aws-controltower-AdministratorExecutionRole", "AWS::IAM::Role"],
    ["arn:aws:sns:us-east-1:1:aws-controltower-SecurityNotifications", "AWS::SNS::Topic"]
  ])("flags %s", (arn, configType) => {
    expect(findAutoCreatedReason(rules, arn, configType)).toBeTruthy();
    // With or without the Config type, so the Tagging API path reaches the same answer.
    expect(findAutoCreatedReason(rules, arn)).toBeTruthy();
    expect(classify(arn, configType)).toMatchObject({ classification: "likely_auto_created", reasonCode: "LIKELY_AUTO_CREATED" });
  });

  it.each([
    ["arn:aws:ec2:us-east-1:1:instance/i-1", "AWS::EC2::Instance"],
    ["arn:aws:ec2:us-east-1:1:vpc/vpc-1", "AWS::EC2::VPC"],
    ["arn:aws:iam::1:role/app-role", "AWS::IAM::Role"],
    ["arn:aws:iam::1:role/service-role/lambda-exec", "AWS::IAM::Role"],
    ["arn:aws:events:us-east-1:1:event-bus/orders", "AWS::Events::EventBus"],
    ["arn:aws:athena:us-east-1:1:workgroup/analytics", "AWS::Athena::WorkGroup"],
    ["arn:aws:rds:us-east-1:1:pg:orders-mysql8", undefined],
    ["arn:aws:kms:us-east-1:1:alias/orders", undefined],
    ["arn:aws:codedeploy:us-east-1:1:deploymentconfig:Canary10Percent", "AWS::CodeDeploy::DeploymentConfig"],
    ["arn:aws:s3:::my-bucket", "AWS::S3::Bucket"]
  ])("leaves %s as a candidate", (arn, configType) => {
    expect(findAutoCreatedReason(rules, arn, configType)).toBeUndefined();
    expect(classify(arn, configType).classification).toBe("rum_candidate");
  });

  it("keeps the Terraform type on a moved row and explains why", () => {
    const row = classify("arn:aws:ec2:us-east-1:1:volume/vol-1", "AWS::EC2::Volume");
    expect(row.terraformResourceType).toBe("aws_ebs_volume");
    expect(row.reasonDetail).toMatch(/inline on the instance/);
  });

  it("does not move a resource that Terraform cannot manage anyway", () => {
    expect(classify("arn:aws:ecs:us-east-1:1:task/cluster/abc", undefined, "tagged by a controller").classification).toBe("not_manageable");
  });
});

describe("findAutoCreatedTagReason", () => {
  const instance = "arn:aws:ec2:us-east-1:1:instance/i-1";

  it("flags instances launched by an Auto Scaling group", () => {
    expect(findAutoCreatedTagReason(rules, instance, ["Name", "aws:autoscaling:groupName"])).toMatch(/Auto Scaling group/);
  });

  it("flags the group, launch template and instances of an EKS managed node group, but not the node group", () => {
    const tags = ["eks:cluster-name", "eks:nodegroup-name"];
    expect(findAutoCreatedTagReason(rules, instance, tags)).toBeTruthy();
    expect(findAutoCreatedTagReason(rules, "arn:aws:autoscaling:us-east-1:1:autoScalingGroup:uuid:autoScalingGroupName/eks-ng", tags)).toBeTruthy();
    expect(findAutoCreatedTagReason(rules, "arn:aws:ec2:us-east-1:1:launch-template/lt-1", tags)).toBeTruthy();
    expect(findAutoCreatedTagReason(rules, "arn:aws:eks:us-east-1:1:nodegroup/cluster/ng/abc", tags)).toBeUndefined();
  });

  it("flags load balancers made by a Kubernetes controller", () => {
    expect(findAutoCreatedTagReason(rules, "arn:aws:elasticloadbalancing:us-east-1:1:loadbalancer/app/k8s-web/abc", ["elbv2.k8s.aws/cluster"])).toBeTruthy();
  });

  it("limits Elastic Beanstalk to what the environment creates", () => {
    const tags = ["elasticbeanstalk:environment-id"];
    expect(findAutoCreatedTagReason(rules, instance, tags)).toBeTruthy();
    expect(findAutoCreatedTagReason(rules, "arn:aws:elasticbeanstalk:us-east-1:1:environment/app/env", tags)).toBeUndefined();
  });

  it("ignores ordinary tags", () => {
    expect(findAutoCreatedTagReason(rules, instance, ["Name", "Environment", "aws:cloudformation:stack-id"])).toBeUndefined();
    expect(findAutoCreatedTagReason(rules, instance, [])).toBeUndefined();
  });

  it("moves a candidate when discovery supplies a reason", () => {
    const reason = findAutoCreatedTagReason(rules, instance, ["aws:autoscaling:groupName"]);
    expect(classify(instance, "AWS::EC2::Instance", reason)).toMatchObject({
      classification: "likely_auto_created",
      terraformResourceType: "aws_instance",
      reasonDetail: reason
    });
  });
});

describe("bucketSupersededTaskDefinitions", () => {
  const taskDef = (family: string, revision: number, region = "us-east-1"): EstimatorResourceRow => ({
    resourceId: `arn:aws:ecs:${region}:111111111111:task-definition/${family}:${revision}`,
    service: "ecs",
    resourceType: "task-definition",
    classification: "rum_candidate",
    reasonCode: "MAPPED_MANAGEABLE",
    terraformResourceType: "aws_ecs_task_definition"
  });

  it("keeps the newest revision per family and region", () => {
    const rows = bucketSupersededTaskDefinitions([taskDef("web", 2), taskDef("web", 10), taskDef("web", 9), taskDef("api", 1), taskDef("web", 3, "us-west-2")]);
    expect(rows.map((row) => row.classification)).toEqual(["likely_auto_created", "rum_candidate", "likely_auto_created", "rum_candidate", "rum_candidate"]);
    expect(summarizeRows(rows)).toMatchObject({ rumCandidates: 3, likelyAutoCreated: 2 });
  });

  it("returns the same rows when there are no task definitions", () => {
    const rows = [classify("arn:aws:s3:::bucket")];
    expect(bucketSupersededTaskDefinitions(rows)).toBe(rows);
  });
});

describe("findAutoCreatedViaConfig", () => {
  const page = (items: ConfigQueryItem[], nextToken?: string) => JSON.stringify({ Results: items.map((item) => JSON.stringify(item)), NextToken: nextToken });
  const item = (kind: string, id: string, type: string, extra: Partial<ConfigQueryItem> = {}): ConfigQueryItem => ({
    arn: `arn:aws:ec2:us-east-1:111111111111:${kind}/${id}`,
    resourceId: id,
    resourceType: type,
    accountId: "111111111111",
    awsRegion: "us-east-1",
    ...extra
  });
  const expressionOf = (args: string[]) => args[args.indexOf("--expression") + 1];

  /** Answers each check from a table keyed by a fragment of its WHERE clause. */
  function fakeConfig(table: Record<string, ConfigQueryItem[] | Error>) {
    const expressions: string[] = [];
    const runQuery = async (args: string[]) => {
      const expression = expressionOf(args);
      expressions.push(expression);
      const key = Object.keys(table).find((fragment) => expression.includes(fragment));
      const answer = key ? table[key] : [];
      if (answer instanceof Error) throw answer;
      return page(answer);
    };
    return { runQuery, expressions };
  }

  const defaultVpc = item("vpc", "vpc-default", "AWS::EC2::VPC");
  const table = {
    "AWS::EC2::VPC": [defaultVpc],
    "AWS::EC2::Subnet": [item("subnet", "subnet-d1", "AWS::EC2::Subnet")],
    "AWS::EC2::SecurityGroup": [
      item("security-group", "sg-default-vpc", "AWS::EC2::SecurityGroup", { configuration: { vpcId: "vpc-default" } }),
      item("security-group", "sg-app-vpc", "AWS::EC2::SecurityGroup", { configuration: { vpcId: "vpc-app" } })
    ],
    "AWS::EC2::InternetGateway": [
      item("internet-gateway", "igw-default", "AWS::EC2::InternetGateway", { configuration: { attachments: [{ vpcId: "vpc-default" }] } }),
      item("internet-gateway", "igw-app", "AWS::EC2::InternetGateway", { configuration: { attachments: [{ vpcId: "vpc-app" }] } })
    ],
    "AWS::KMS::Key": [{ arn: "arn:aws:kms:us-east-1:111111111111:key/k-1", resourceId: "k-1", resourceType: "AWS::KMS::Key" }],
    "tags.key IN": [
      item("instance", "i-asg", "AWS::EC2::Instance", { tags: [{ key: "aws:autoscaling:groupName" }, { key: "Name" }] }),
      // Carries a listed tag, but the rule for it does not apply to this kind.
      item("vpc", "vpc-tagged", "AWS::EC2::VPC", { tags: [{ key: "aws:autoscaling:groupName" }] })
    ]
  };

  it("marks default VPC parts, AWS managed keys and controller-tagged resources", async () => {
    const { runQuery, expressions } = fakeConfig(table);
    const result = await findAutoCreatedViaConfig({ aggregatorName: "org", scope: {}, rules, runQuery });

    expect([...result.reasons.keys()].sort()).toEqual([
      "arn:aws:ec2:us-east-1:111111111111:instance/i-asg",
      "arn:aws:ec2:us-east-1:111111111111:internet-gateway/igw-default",
      "arn:aws:ec2:us-east-1:111111111111:security-group/sg-default-vpc",
      "arn:aws:ec2:us-east-1:111111111111:subnet/subnet-d1",
      "arn:aws:ec2:us-east-1:111111111111:vpc/vpc-default",
      "arn:aws:kms:us-east-1:111111111111:key/k-1"
    ]);
    expect(result.failed).toEqual([]);
    expect(result.pagesFetched).toBe(expressions.length);
    // The default VPC query runs first; the others depend on it.
    expect(expressions[0]).toContain("configuration.isDefault = true");
    expect(expressions.at(-1)).toContain("tags.key IN ('aws:autoscaling:groupName'");
  });

  it("applies the run's region and account filters to every check", async () => {
    const { runQuery, expressions } = fakeConfig({});
    await findAutoCreatedViaConfig({ aggregatorName: "org", scope: { regions: ["eu-west-1"], accountIds: ["111111111111"] }, rules, runQuery });
    for (const expression of expressions) {
      expect(expression).toContain("awsRegion IN ('eu-west-1', 'global')");
      expect(expression).toContain("accountId IN ('111111111111')");
      expect(expression).toMatch(/WHERE \(.+\) AND awsRegion/);
    }
  });

  it("follows continuation tokens", async () => {
    let calls = 0;
    const runQuery = async (args: string[]) => {
      if (!expressionOf(args).includes("AWS::KMS::Key")) return page([]);
      calls += 1;
      const key = (id: string) => ({ arn: `arn:aws:kms:us-east-1:1:key/${id}`, resourceId: id, resourceType: "AWS::KMS::Key" });
      return args.includes("--starting-token") ? page([key("k-2")]) : page([key("k-1")], "next");
    };
    const result = await findAutoCreatedViaConfig({ aggregatorName: "org", scope: {}, rules, runQuery });
    expect(calls).toBe(2);
    expect(result.reasons.size).toBe(2);
  });

  it("reports a failed check and carries on with the rest", async () => {
    const { runQuery } = fakeConfig({ ...table, "AWS::KMS::Key": new Error("An error occurred (ValidationException): bad expression\nmore") });
    const result = await findAutoCreatedViaConfig({ aggregatorName: "org", scope: {}, rules, runQuery });
    expect(result.failed).toEqual([{ check: "aws-managed-kms-keys", error: "An error occurred (ValidationException): bad expression" }]);
    expect(result.reasons.has("arn:aws:ec2:us-east-1:111111111111:instance/i-asg")).toBe(true);
  });

  it("skips the default VPC member checks when default VPCs cannot be listed", async () => {
    const { runQuery, expressions } = fakeConfig({ ...table, "AWS::EC2::VPC": new Error("throttled") });
    const result = await findAutoCreatedViaConfig({ aggregatorName: "org", scope: {}, rules, runQuery });
    expect(result.failed.map((entry) => entry.check)).toEqual([
      "default-vpc",
      "default-vpc-security-group",
      "default-vpc-route-table",
      "default-vpc-network-acl",
      "default-vpc-internet-gateway"
    ]);
    expect(expressions.some((expression) => expression.includes("AWS::EC2::InternetGateway"))).toBe(false);
    // Default subnets do not depend on the VPC list.
    expect(result.reasons.has("arn:aws:ec2:us-east-1:111111111111:subnet/subnet-d1")).toBe(true);
  });

  it("ignores rows of a type a check did not ask for", async () => {
    // Every query answers with the same unrelated rows, as if the condition were ignored.
    const runQuery = async () => page([item("instance", "i-1", "AWS::EC2::Instance"), item("vpc", "vpc-1", "AWS::EC2::VPC")]);
    const result = await findAutoCreatedViaConfig({ aggregatorName: "org", scope: {}, rules, runQuery });
    expect([...result.reasons.keys()]).toEqual(["arn:aws:ec2:us-east-1:111111111111:vpc/vpc-1"]);
  });

  it("refuses a tag key that could alter the query", async () => {
    const unsafe = { ...rules, configMarkers: [], tags: [{ key: "x') OR resourceType LIKE ('%", reason: "should never be sent" }] };
    const { runQuery, expressions } = fakeConfig({});
    const result = await findAutoCreatedViaConfig({ aggregatorName: "org", scope: {}, rules: unsafe, runQuery });
    expect(expressions).toEqual([]);
    expect(result.failed[0].check).toBe("controller-tags");
  });
});

describe("Tagging API auto-created detection", () => {
  const response = JSON.stringify({
    ResourceTagMappingList: [
      { ResourceARN: "arn:aws:ec2:us-east-1:1:instance/i-asg", Tags: [{ Key: "aws:autoscaling:groupName", Value: "web" }] },
      { ResourceARN: "arn:aws:ec2:us-east-1:1:instance/i-own", Tags: [{ Key: "Name", Value: "bastion" }] },
      { ResourceARN: "arn:aws:sqs:us-east-1:1:orders" }
    ]
  });

  it("records a reason from tag keys and keeps no tag values", async () => {
    const scan = await scanTaggingRegions({
      regions: ["us-east-1"],
      runQuery: async () => response,
      autoCreatedReasonFor: (arn, tagKeys) => findAutoCreatedTagReason(rules, arn, tagKeys)
    });
    expect(scan.arns).toHaveLength(3);
    expect([...scan.autoCreated.keys()]).toEqual(["arn:aws:ec2:us-east-1:1:instance/i-asg"]);
    expect(JSON.stringify([...scan.autoCreated])).not.toContain("web");
  });

  it("carries the reason through the merge with Config results, from either source", () => {
    const merged = mergeDiscoveries(
      [
        { resourceId: "arn:aws:ec2:us-east-1:1:instance/i-asg", sourceResourceType: "AWS::EC2::Instance" },
        { resourceId: "arn:aws:ec2:us-east-1:1:vpc/vpc-default", sourceResourceType: "AWS::EC2::VPC", autoCreatedReason: "Default VPC" }
      ],
      ["arn:aws:ec2:us-east-1:1:instance/i-asg", "arn:aws:ec2:us-east-1:1:instance/i-eks"],
      new Map([
        ["arn:aws:ec2:us-east-1:1:instance/i-asg", "Launched by an Auto Scaling group"],
        ["arn:aws:ec2:us-east-1:1:instance/i-eks", "Created by an EKS managed node group"]
      ])
    );
    const reasons = Object.fromEntries(merged.resources.map((resource) => [resource.resourceId.split("/")[1], resource.autoCreatedReason]));
    expect(reasons).toEqual({
      "i-asg": "Launched by an Auto Scaling group",
      "vpc-default": "Default VPC",
      "i-eks": "Created by an EKS managed node group"
    });
  });
});
