import { readFile } from "node:fs/promises";
import { join } from "node:path";
import type { EstimatorMappingMetadata, EstimatorProvider } from "./estimator-types.js";
import { getWorkspaceRoot } from "./workspace-root.js";

export type MappingEntry = {
  matchPrefix: string;
  terraformType: string;
  rumEligible: boolean;
};

type MappingFileV2 = {
  mappingVersion: string;
  updatedAt: string;
  source?: string;
  providerVersionConstraint?: string;
  providerVersionResolved?: string;
  mappings: MappingEntry[];
};

/** One resource kind: its Terraform type, or not manageable by Terraform at all. */
export type AwsTypeEntry = { terraformType?: string; manageable: boolean };

/**
 * Resource-type-level AWS mapping. The service-level mapping gives every resource of a
 * service the same Terraform type (every EC2 ARN became aws_instance); this index resolves
 * the actual type from the AWS Config resource type or from the ARN's resource segment.
 */
export type AwsTypeIndex = {
  byConfigType: Map<string, AwsTypeEntry>;
  byArnKey: Map<string, AwsTypeEntry>;
  total: number;
  autoCreated: AwsAutoCreatedRules;
};

export type AwsAutoCreatedTagRule = { key: string; reason: string; onlyArnTypes?: string[] };

/** An extra AWS Config query whose results are auto-created resources. */
export type AwsConfigMarker = {
  id: string;
  /** Config query condition. Comes from the mapping file, never from a request. */
  where: string;
  reason: string;
  /** "defines": results are default VPCs. "member": keep only results inside a default VPC. */
  defaultVpc?: "defines" | "member";
};

/**
 * Resource kinds that are rarely declared as their own Terraform resource because AWS or
 * another resource creates them. Counting them as RUM candidates overstates the estimate.
 */
export type AwsAutoCreatedRules = {
  byConfigType: Map<string, string>;
  byArnKey: Map<string, string>;
  patterns: Array<{ pattern: RegExp; reason: string }>;
  tags: AwsAutoCreatedTagRule[];
  configMarkers: AwsConfigMarker[];
};

export type AwsTypeMappingFile = {
  configTypes?: Record<string, string>;
  arnTypes?: Record<string, string>;
  notManageable?: { configTypes?: string[]; arnTypes?: string[] };
  likelyAutoCreated?: {
    configTypes?: Record<string, string>;
    arnTypes?: Record<string, string>;
    arnPatterns?: Array<{ pattern: string; reason: string }>;
    tags?: AwsAutoCreatedTagRule[];
    configMarkers?: AwsConfigMarker[];
  };
};

export function buildAwsAutoCreatedRules(file: AwsTypeMappingFile["likelyAutoCreated"] = {}): AwsAutoCreatedRules {
  return {
    byConfigType: new Map(Object.entries(file.configTypes ?? {})),
    byArnKey: new Map(Object.entries(file.arnTypes ?? {})),
    patterns: (file.arnPatterns ?? []).map((entry) => ({ pattern: new RegExp(entry.pattern), reason: entry.reason })),
    tags: file.tags ?? [],
    configMarkers: file.configMarkers ?? []
  };
}

export function buildAwsTypeIndex(file: AwsTypeMappingFile): AwsTypeIndex {
  const byConfigType = new Map<string, AwsTypeEntry>();
  const byArnKey = new Map<string, AwsTypeEntry>();
  for (const [configType, terraformType] of Object.entries(file.configTypes ?? {})) {
    byConfigType.set(configType, { terraformType, manageable: true });
  }
  for (const [arnKey, terraformType] of Object.entries(file.arnTypes ?? {})) {
    byArnKey.set(arnKey, { terraformType, manageable: true });
  }
  for (const configType of file.notManageable?.configTypes ?? []) byConfigType.set(configType, { manageable: false });
  for (const arnKey of file.notManageable?.arnTypes ?? []) byArnKey.set(arnKey, { manageable: false });
  return { byConfigType, byArnKey, total: byConfigType.size + byArnKey.size, autoCreated: buildAwsAutoCreatedRules(file.likelyAutoCreated) };
}

const AWS_TYPE_MAPPING_FILE = "aws_resource_type_to_tf.json";

/** Returns undefined when the file is absent, so classification falls back to service level. */
export async function loadAwsTypeIndex(): Promise<AwsTypeIndex | undefined> {
  const filePath = join(getWorkspaceRoot(), "data", "mappings", AWS_TYPE_MAPPING_FILE);
  let raw: string;
  try {
    raw = await readFile(filePath, "utf-8");
  } catch {
    return undefined;
  }
  return buildAwsTypeIndex(JSON.parse(raw) as AwsTypeMappingFile);
}

function getStaleThresholdDays(): number {
  const raw = process.env.ESTIMATOR_MAPPING_STALE_DAYS;
  const value = raw ? Number(raw) : 30;
  return Number.isFinite(value) && value > 0 ? value : 30;
}

function calculateAgeDays(updatedAt: string): number {
  const updated = new Date(updatedAt).getTime();
  if (Number.isNaN(updated)) return 9999;
  const ageMs = Date.now() - updated;
  return Math.max(0, Math.floor(ageMs / (1000 * 60 * 60 * 24)));
}

const MAPPING_FILE_BY_PROVIDER: Record<EstimatorProvider, string> = {
  aws: "aws_resource_to_tf.json",
  azure: "azure_resource_to_tf.json",
  gcp: "gcp_resource_to_tf.json"
};

export type LoadedMapping = {
  entries: MappingEntry[];
  metadata: EstimatorMappingMetadata;
  typeIndex?: AwsTypeIndex;
};

export async function loadMapping(provider: EstimatorProvider): Promise<LoadedMapping> {
  const workspaceRoot = getWorkspaceRoot();
  const filePath = join(workspaceRoot, "data", "mappings", MAPPING_FILE_BY_PROVIDER[provider]);
  const raw = await readFile(filePath, "utf-8");
  const parsed = JSON.parse(raw) as MappingFileV2 | MappingEntry[];

  let entries: MappingEntry[];
  let mappingVersion = "legacy";
  let updatedAt = "1970-01-01T00:00:00.000Z";
  let source: string | undefined;
  let providerVersionConstraint: string | undefined;
  let providerVersionResolved: string | undefined;

  if (Array.isArray(parsed)) {
    entries = parsed;
  } else {
    entries = parsed.mappings ?? [];
    mappingVersion = parsed.mappingVersion;
    updatedAt = parsed.updatedAt;
    source = parsed.source;
    providerVersionConstraint = parsed.providerVersionConstraint;
    providerVersionResolved = parsed.providerVersionResolved;
  }

  const typeIndex = provider === "aws" ? await loadAwsTypeIndex() : undefined;
  const staleThresholdDays = getStaleThresholdDays();
  const ageDays = calculateAgeDays(updatedAt);
  const metadata: EstimatorMappingMetadata = {
    provider,
    mappingVersion,
    updatedAt,
    source,
    providerVersionConstraint,
    providerVersionResolved,
    totalMappings: entries.length,
    resourceTypeMappings: typeIndex?.total,
    staleThresholdDays,
    ageDays,
    isStale: ageDays > staleThresholdDays
  };

  return { entries, metadata, typeIndex };
}

export async function loadAwsMapping(): Promise<LoadedMapping> {
  return loadMapping("aws");
}
