import { readFileSync } from "node:fs";
import { join } from "node:path";
import { describe, expect, it } from "vitest";
import { awsArnTypeKeys, buildDiagnostics, classifyWithMapping } from "./estimator-analysis.js";
import { buildAwsTypeIndex, type AwsTypeMappingFile, type MappingEntry } from "./estimator-mapping.js";
import { getWorkspaceRoot } from "./workspace-root.js";

const root = getWorkspaceRoot();
const typeFile = JSON.parse(readFileSync(join(root, "data", "mappings", "aws_resource_type_to_tf.json"), "utf-8")) as AwsTypeMappingFile;
const serviceFile = JSON.parse(readFileSync(join(root, "data", "mappings", "aws_resource_to_tf.json"), "utf-8")) as { mappings: MappingEntry[] };
const typeIndex = buildAwsTypeIndex(typeFile);
const classify = (arn: string, sourceResourceType?: string) => classifyWithMapping("aws", arn, serviceFile.mappings, { typeIndex, sourceResourceType });

describe("aws_resource_type_to_tf.json", () => {
  it("has well-formed keys and Terraform type names", () => {
    for (const [configType, terraformType] of Object.entries(typeFile.configTypes ?? {})) {
      expect(configType).toMatch(/^AWS::[A-Za-z0-9]+::[A-Za-z0-9]+$/);
      expect(terraformType).toMatch(/^aws_[a-z0-9_]+$/);
    }
    for (const [arnKey, terraformType] of Object.entries(typeFile.arnTypes ?? {})) {
      expect(arnKey).toMatch(/^[a-z0-9-]+:[A-Za-z0-9-]+(\/[A-Za-z0-9-]+)?$/);
      expect(terraformType).toMatch(/^aws_[a-z0-9_]+$/);
    }
    expect(Object.keys(typeFile.configTypes ?? {}).length).toBeGreaterThan(300);
    expect(Object.keys(typeFile.arnTypes ?? {}).length).toBeGreaterThan(150);
  });

  it("does not list a kind as both mapped and not manageable", () => {
    for (const configType of typeFile.notManageable?.configTypes ?? []) expect(typeFile.configTypes?.[configType]).toBeUndefined();
    for (const arnKey of typeFile.notManageable?.arnTypes ?? []) expect(typeFile.arnTypes?.[arnKey]).toBeUndefined();
  });
});

describe("awsArnTypeKeys", () => {
  it("derives service and resource kind, most specific first", () => {
    expect(awsArnTypeKeys("arn:aws:ec2:us-east-1:111111111111:subnet/subnet-1")).toEqual(["ec2:subnet/subnet-1", "ec2:subnet"]);
    expect(awsArnTypeKeys("arn:aws:elasticloadbalancing:us-east-1:1:loadbalancer/app/web/abc")).toEqual([
      "elasticloadbalancing:loadbalancer/app",
      "elasticloadbalancing:loadbalancer"
    ]);
    expect(awsArnTypeKeys("arn:aws:rds:us-east-1:1:db:orders")).toEqual(["rds:db/orders", "rds:db"]);
    expect(awsArnTypeKeys("arn:aws:logs:us-east-1:1:log-group:/app:*")).toEqual(["logs:log-group/", "logs:log-group"]);
  });

  it("returns nothing for bare-name ARNs and non-ARNs", () => {
    expect(awsArnTypeKeys("arn:aws:sqs:us-east-1:1:orders")).toEqual([]);
    expect(awsArnTypeKeys("arn:aws:s3:::my-bucket")).toEqual([]);
    expect(awsArnTypeKeys("arn:aws:apigateway:us-east-1::/restapis/abc")).toEqual([]);
    expect(awsArnTypeKeys("not-an-arn")).toEqual([]);
  });
});

describe("AWS classification with the resource-type mapping", () => {
  // The exact rows that were mislabelled aws_instance in live testing.
  it.each([
    ["arn:aws:ec2:us-east-1:1:subnet/subnet-1", "AWS::EC2::Subnet", "aws_subnet"],
    ["arn:aws:ec2:us-east-1:1:route-table/rtb-1", "AWS::EC2::RouteTable", "aws_route_table"],
    ["arn:aws:ec2:us-east-1:1:security-group/sg-1", "AWS::EC2::SecurityGroup", "aws_security_group"],
    ["arn:aws:ec2:us-east-1:1:elastic-ip/eipalloc-1", "AWS::EC2::EIP", "aws_eip"],
    ["arn:aws:ec2:us-east-1:1:internet-gateway/igw-1", "AWS::EC2::InternetGateway", "aws_internet_gateway"],
    ["arn:aws:ec2:us-east-1:1:vpc/vpc-1", "AWS::EC2::VPC", "aws_vpc"],
    ["arn:aws:ec2:us-east-1:1:instance/i-1", "AWS::EC2::Instance", "aws_instance"],
    ["arn:aws:iam::1:role/admin", "AWS::IAM::Role", "aws_iam_role"],
    ["arn:aws:iam::1:policy/p", "AWS::IAM::Policy", "aws_iam_policy"],
    ["arn:aws:iam::1:user/u", "AWS::IAM::User", "aws_iam_user"]
  ])("%s (%s) -> %s", (arn, configType, terraformType) => {
    const fromConfig = classify(arn, configType);
    expect(fromConfig).toMatchObject({ classification: "rum_candidate", terraformResourceType: terraformType, typeMatch: "exact" });
    // The Tagging API gives no Config type; the ARN alone must reach the same answer.
    expect(classify(arn)).toMatchObject({ classification: "rum_candidate", terraformResourceType: terraformType, typeMatch: "exact" });
  });

  it("prefers the Config type over the ARN", () => {
    expect(classify("arn:aws:elasticloadbalancing:us-east-1:1:loadbalancer/classic-lb", "AWS::ElasticLoadBalancing::LoadBalancer").terraformResourceType).toBe("aws_elb");
    expect(classify("arn:aws:elasticloadbalancing:us-east-1:1:loadbalancer/app/web/abc").terraformResourceType).toBe("aws_lb");
    expect(classify("arn:aws:elasticloadbalancing:us-east-1:1:loadbalancer/classic-lb").terraformResourceType).toBe("aws_elb");
  });

  it("marks kinds with no Terraform resource as not manageable", () => {
    expect(classify("arn:aws:ecs:us-east-1:1:task/cluster/abc")).toMatchObject({
      classification: "not_manageable",
      reasonCode: "NOT_SUPPORTED_BY_PROVIDER",
      typeMatch: "exact"
    });
    expect(classify("arn:aws:backup:us-east-1:1:recovery-point:abc", "AWS::Backup::RecoveryPoint").classification).toBe("not_manageable");
  });

  it("falls back to the service default and flags it", () => {
    const row = classify("arn:aws:ec2:us-east-1:1:some-future-kind/x-1");
    expect(row).toMatchObject({ classification: "rum_candidate", terraformResourceType: "aws_instance", typeMatch: "service" });
  });

  it("treats bare-name ARNs as exact: their service has one common kind", () => {
    expect(classify("arn:aws:sqs:us-east-1:1:orders")).toMatchObject({ terraformResourceType: "aws_sqs_queue", typeMatch: "exact" });
    expect(classify("arn:aws:sns:us-east-1:1:alerts")).toMatchObject({ terraformResourceType: "aws_sns_topic", typeMatch: "exact" });
    expect(classify("arn:aws:s3:::my-bucket")).toMatchObject({ terraformResourceType: "aws_s3_bucket", typeMatch: "exact" });
    // An SNS subscription ARN has an extra segment, so the topic label is only a guess.
    expect(classify("arn:aws:sns:us-east-1:1:alerts:6b0e71bd-7e97-4d97-80ce-4a0994e55286").typeMatch).toBe("service");
    expect(classify("arn:aws:apigateway:us-east-1::/restapis/abc").typeMatch).toBe("service");
  });

  it("keeps unknown services unmapped", () => {
    expect(classify("arn:aws:madeupservice:us-east-1:1:widget/w")).toMatchObject({ classification: "unmapped", reasonCode: "UNMAPPED_TYPE" });
  });

  it("counts service-level matches in diagnostics", () => {
    const rows = [classify("arn:aws:ec2:us-east-1:1:subnet/s", "AWS::EC2::Subnet"), classify("arn:aws:ec2:us-east-1:1:some-future-kind/x"), classify("arn:aws:sqs:us-east-1:1:q")];
    expect(buildDiagnostics(rows).serviceLevelMatches).toBe(1);
  });

  it("leaves classification without a type index unchanged", () => {
    const row = classifyWithMapping("aws", "arn:aws:ec2:us-east-1:1:subnet/s", serviceFile.mappings);
    expect(row.terraformResourceType).toBe("aws_instance");
    expect(row.typeMatch).toBeUndefined();
  });
});
