import { describe, expect, it, vi } from "vitest";
import {
  CliError,
  classifyCliError,
  computeBackoffDelayMs,
  createCliRunner,
  isRetryableKind,
  type CliExec,
  type CliRetryEvent
} from "./cli-runner.js";

function failure(stderr: string, extra: Record<string, unknown> = {}): Error {
  return Object.assign(new Error(`Command failed: aws something\n${stderr}`), { stderr, ...extra });
}

function harness(exec: CliExec) {
  const sleeps: number[] = [];
  const run = createCliRunner({
    exec,
    sleep: async (ms) => {
      sleeps.push(ms);
    },
    random: () => 1
  });
  return { run, sleeps };
}

describe("classifyCliError", () => {
  it("treats a killed call as a timeout regardless of message", () => {
    expect(classifyCliError("AccessDenied", true)).toBe("timeout");
  });

  it("recognises throttling", () => {
    expect(classifyCliError("An error occurred (ThrottlingException) when calling X: Rate exceeded", false)).toBe("throttled");
    expect(classifyCliError("An error occurred (TooManyRequestsException)", false)).toBe("throttled");
  });

  it("recognises transient network and service errors", () => {
    expect(classifyCliError('Could not connect to the endpoint URL: "https://config.us-east-1.amazonaws.com/"', false)).toBe("transient");
    expect(classifyCliError("An error occurred (ServiceUnavailable)", false)).toBe("transient");
  });

  it("recognises permission and credential errors", () => {
    expect(classifyCliError("An error occurred (AccessDeniedException) when calling SelectAggregateResourceConfig", false)).toBe("permission");
    expect(classifyCliError("An error occurred (ExpiredToken)", false)).toBe("permission");
    expect(classifyCliError("Unable to locate credentials. You can configure credentials by running \"aws configure\".", false)).toBe("permission");
  });

  it("prefers permission over transient when both appear", () => {
    expect(classifyCliError("AccessDenied ... InternalError", false)).toBe("permission");
  });

  it("falls back to fatal", () => {
    expect(classifyCliError("An error occurred (NoSuchConfigurationAggregatorException)", false)).toBe("fatal");
  });

  it("only retries timeout, throttled and transient", () => {
    expect(isRetryableKind("timeout")).toBe(true);
    expect(isRetryableKind("throttled")).toBe(true);
    expect(isRetryableKind("transient")).toBe(true);
    expect(isRetryableKind("permission")).toBe(false);
    expect(isRetryableKind("fatal")).toBe(false);
  });
});

describe("computeBackoffDelayMs", () => {
  it("doubles each attempt and caps at the maximum", () => {
    expect(computeBackoffDelayMs(1, 1000, 30000, 1)).toBe(1000);
    expect(computeBackoffDelayMs(2, 1000, 30000, 1)).toBe(2000);
    expect(computeBackoffDelayMs(3, 1000, 30000, 1)).toBe(4000);
    expect(computeBackoffDelayMs(10, 1000, 30000, 1)).toBe(30000);
  });

  it("jitters between half and the full delay", () => {
    expect(computeBackoffDelayMs(3, 1000, 30000, 0)).toBe(2000);
    expect(computeBackoffDelayMs(3, 1000, 30000, 0.5)).toBe(3000);
  });
});

describe("createCliRunner", () => {
  it("returns stdout on first success and passes env overrides and timeout", async () => {
    const exec = vi.fn<CliExec>(async () => ({ stdout: "ok" }));
    const { run, sleeps } = harness(exec);

    const out = await run("aws", ["sts", "get-caller-identity"], { AWS_PROFILE: "audit" }, { timeoutMs: 5000 });

    expect(out).toBe("ok");
    expect(sleeps).toEqual([]);
    const [command, args, options] = exec.mock.calls[0];
    expect(command).toBe("aws");
    expect(args).toEqual(["sts", "get-caller-identity"]);
    expect(options.timeout).toBe(5000);
    expect(options.env.AWS_PROFILE).toBe("audit");
  });

  it("retries throttling with exponential backoff then succeeds", async () => {
    let calls = 0;
    const exec: CliExec = async () => {
      calls += 1;
      if (calls < 3) throw failure("An error occurred (ThrottlingException): Rate exceeded");
      return { stdout: "done" };
    };
    const { run, sleeps } = harness(exec);
    const retries: CliRetryEvent[] = [];

    const out = await run("aws", ["x"], {}, { onRetry: (event) => retries.push(event) });

    expect(out).toBe("done");
    expect(calls).toBe(3);
    expect(sleeps).toEqual([1000, 2000]);
    expect(retries.map((r) => [r.attempt, r.kind])).toEqual([
      [1, "throttled"],
      [2, "throttled"]
    ]);
  });

  it("retries a timed-out call", async () => {
    let calls = 0;
    const exec: CliExec = async () => {
      calls += 1;
      if (calls === 1) throw failure("", { killed: true, signal: "SIGTERM" });
      return { stdout: "late" };
    };
    const { run, sleeps } = harness(exec);

    expect(await run("aws", ["x"], {}, { timeoutMs: 100 })).toBe("late");
    expect(sleeps).toHaveLength(1);
  });

  it("does not retry permission errors", async () => {
    const exec = vi.fn<CliExec>(async () => {
      throw failure("An error occurred (AccessDeniedException): not authorized");
    });
    const { run, sleeps } = harness(exec);

    await expect(run("aws", ["x"], {})).rejects.toMatchObject({ name: "CliError", kind: "permission", attempts: 1 });
    expect(exec).toHaveBeenCalledTimes(1);
    expect(sleeps).toEqual([]);
  });

  it("does not retry fatal errors", async () => {
    const exec = vi.fn<CliExec>(async () => {
      throw failure("An error occurred (ValidationException): bad expression");
    });
    const { run } = harness(exec);

    await expect(run("aws", ["x"], {})).rejects.toMatchObject({ kind: "fatal" });
    expect(exec).toHaveBeenCalledTimes(1);
  });

  it("gives up after maxAttempts and reports the attempt count", async () => {
    const exec = vi.fn<CliExec>(async () => {
      throw failure("An error occurred (ThrottlingException): Rate exceeded");
    });
    const { run, sleeps } = harness(exec);

    const error = await run("aws", ["x"], {}, { maxAttempts: 3 }).catch((e: unknown) => e);

    expect(error).toBeInstanceOf(CliError);
    expect((error as CliError).kind).toBe("throttled");
    expect((error as CliError).attempts).toBe(3);
    expect((error as CliError).message).toContain("after 3 attempts");
    expect(exec).toHaveBeenCalledTimes(3);
    expect(sleeps).toEqual([1000, 2000]);
  });

  it("reports stderr rather than the echoed command line", async () => {
    const exec: CliExec = async () => {
      throw failure("An error occurred (ValidationException): bad expression");
    };
    const { run } = harness(exec);

    const error = (await run("aws", ["x"], {}).catch((e: unknown) => e)) as CliError;
    expect(error.message).toBe("An error occurred (ValidationException): bad expression");
  });
});
