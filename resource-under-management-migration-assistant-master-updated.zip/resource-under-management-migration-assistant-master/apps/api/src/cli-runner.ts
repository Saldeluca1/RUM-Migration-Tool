import { execFile as execFileCb } from "node:child_process";
import { promisify } from "node:util";

const execFileAsync = promisify(execFileCb);

export type CliCommand = "aws" | "az" | "gcloud";

/**
 * Why a CLI call failed. Only `timeout`, `throttled` and `transient` are retried:
 * permission and fatal errors will not fix themselves on a second attempt.
 */
export type CliErrorKind = "timeout" | "throttled" | "transient" | "permission" | "fatal";

export class CliError extends Error {
  readonly kind: CliErrorKind;
  readonly attempts: number;

  constructor(message: string, kind: CliErrorKind, attempts: number) {
    super(message);
    this.name = "CliError";
    this.kind = kind;
    this.attempts = attempts;
  }
}

export type CliRetryEvent = {
  command: CliCommand;
  attempt: number;
  maxAttempts: number;
  kind: CliErrorKind;
  delayMs: number;
};

export type CliRunOptions = {
  /** Kill the call and treat it as a retryable timeout after this long. */
  timeoutMs?: number;
  /** Total attempts including the first one. */
  maxAttempts?: number;
  /** First backoff delay; doubles each retry up to maxDelayMs. */
  baseDelayMs?: number;
  maxDelayMs?: number;
  onRetry?: (event: CliRetryEvent) => void;
};

export type CliExec = (
  command: string,
  args: string[],
  options: { env: NodeJS.ProcessEnv; maxBuffer: number; timeout: number }
) => Promise<{ stdout: string }>;

export type CliRunnerDeps = {
  exec?: CliExec;
  sleep?: (ms: number) => Promise<void>;
  random?: () => number;
};

export type CliRun = (
  command: CliCommand,
  args: string[],
  envOverrides: Record<string, string>,
  options?: CliRunOptions
) => Promise<string>;

const DEFAULT_TIMEOUT_MS = 120_000;
const DEFAULT_MAX_ATTEMPTS = 5;
const DEFAULT_BASE_DELAY_MS = 1_000;
const DEFAULT_MAX_DELAY_MS = 30_000;
const MAX_BUFFER_BYTES = 30 * 1024 * 1024;

const THROTTLE_PATTERNS = [
  "Throttling",
  "ThrottledException",
  "TooManyRequestsException",
  "RequestLimitExceeded",
  "Rate exceeded",
  "SlowDown",
  "ProvisionedThroughputExceeded",
  "RESOURCE_EXHAUSTED",
  "Too Many Requests"
];

const TRANSIENT_PATTERNS = [
  "ServiceUnavailable",
  "InternalFailure",
  "InternalError",
  "InternalServerError",
  "RequestTimeout",
  "Could not connect to the endpoint URL",
  "Connection was closed",
  "Connection reset",
  "Read timeout",
  "Connect timeout",
  "ECONNRESET",
  "EAI_AGAIN",
  "ETIMEDOUT",
  "Bad Gateway",
  "Gateway Timeout"
];

const PERMISSION_PATTERNS = [
  "AccessDenied",
  "UnauthorizedOperation",
  "is not authorized to perform",
  "does not have authorization",
  "permission denied",
  "PERMISSION_DENIED",
  "AuthorizationFailed",
  "ExpiredToken",
  "InvalidClientTokenId",
  "UnrecognizedClientException",
  "AuthFailure",
  "Unable to locate credentials"
];

export function isPermissionDenied(message: string): boolean {
  return PERMISSION_PATTERNS.some((pattern) => message.includes(pattern));
}

export function classifyCliError(message: string, timedOut: boolean): CliErrorKind {
  if (timedOut) return "timeout";
  // Permission is checked first: an access-denied body can also mention a request ID
  // or other text that looks transient, and retrying it only delays the real error.
  if (isPermissionDenied(message)) return "permission";
  if (THROTTLE_PATTERNS.some((pattern) => message.includes(pattern))) return "throttled";
  if (TRANSIENT_PATTERNS.some((pattern) => message.includes(pattern))) return "transient";
  return "fatal";
}

export function isRetryableKind(kind: CliErrorKind): boolean {
  return kind === "timeout" || kind === "throttled" || kind === "transient";
}

/** Exponential backoff with jitter: between half and all of the capped exponential delay. */
export function computeBackoffDelayMs(attempt: number, baseDelayMs: number, maxDelayMs: number, random: number): number {
  const exponential = Math.min(maxDelayMs, baseDelayMs * 2 ** (attempt - 1));
  return Math.round(exponential / 2 + (exponential / 2) * random);
}

function positiveIntFromEnv(name: string, fallback: number): number {
  const raw = process.env[name];
  if (!raw) return fallback;
  const value = Number(raw);
  return Number.isInteger(value) && value > 0 ? value : fallback;
}

export function getCliRunDefaults(): Required<Omit<CliRunOptions, "onRetry">> {
  return {
    timeoutMs: positiveIntFromEnv("ESTIMATOR_CLI_TIMEOUT_MS", DEFAULT_TIMEOUT_MS),
    maxAttempts: positiveIntFromEnv("ESTIMATOR_CLI_MAX_ATTEMPTS", DEFAULT_MAX_ATTEMPTS),
    baseDelayMs: DEFAULT_BASE_DELAY_MS,
    maxDelayMs: DEFAULT_MAX_DELAY_MS
  };
}

function didTimeOut(error: unknown): boolean {
  if (!error || typeof error !== "object") return false;
  const candidate = error as { killed?: boolean; code?: unknown };
  return candidate.killed === true || candidate.code === "ETIMEDOUT";
}

function describeError(error: unknown): string {
  if (!error || typeof error !== "object") return String(error);
  const candidate = error as { message?: string; stderr?: string };
  const stderr = typeof candidate.stderr === "string" ? candidate.stderr.trim() : "";
  // Prefer stderr: it carries the cloud error code without echoing the full command line.
  return stderr || candidate.message || String(error);
}

export function createCliRunner(deps: CliRunnerDeps = {}): CliRun {
  const exec: CliExec = deps.exec ?? ((command, args, options) => execFileAsync(command, args, options));
  const sleep = deps.sleep ?? ((ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms)));
  const random = deps.random ?? Math.random;

  return async function runCli(command, args, envOverrides, options = {}) {
    const defaults = getCliRunDefaults();
    const timeoutMs = options.timeoutMs ?? defaults.timeoutMs;
    const maxAttempts = options.maxAttempts ?? defaults.maxAttempts;
    const baseDelayMs = options.baseDelayMs ?? defaults.baseDelayMs;
    const maxDelayMs = options.maxDelayMs ?? defaults.maxDelayMs;

    for (let attempt = 1; ; attempt += 1) {
      try {
        const result = await exec(command, args, {
          maxBuffer: MAX_BUFFER_BYTES,
          timeout: timeoutMs,
          env: { ...process.env, ...envOverrides }
        });
        return result.stdout;
      } catch (error) {
        const timedOut = didTimeOut(error);
        const detail = timedOut ? `${command} call timed out after ${timeoutMs}ms` : describeError(error);
        const kind = classifyCliError(detail, timedOut);

        if (!isRetryableKind(kind) || attempt >= maxAttempts) {
          const suffix = attempt > 1 ? ` (after ${attempt} attempts)` : "";
          throw new CliError(`${detail}${suffix}`, kind, attempt);
        }

        const delayMs = computeBackoffDelayMs(attempt, baseDelayMs, maxDelayMs, random());
        options.onRetry?.({ command, attempt, maxAttempts, kind, delayMs });
        await sleep(delayMs);
      }
    }
  };
}

export const runCliWithRetry: CliRun = createCliRunner();
