import type {
  AwsDiscoverySource,
  EstimatorAccountSummary,
  EstimatorProvider,
  EstimatorResourceRow,
  EstimatorRunDiagnostics,
  EstimatorSummary
} from "./estimator-types.js";
import type { AwsAutoCreatedRules, AwsTypeEntry, AwsTypeIndex, MappingEntry } from "./estimator-mapping.js";

function parseAwsArn(resourceId: string): { service: string; region?: string; resourceType: string } {
  const arnParts = resourceId.split(":");
  return {
    service: arnParts[2] ?? "unknown",
    region: arnParts[3] || undefined,
    resourceType: arnParts[5] ?? "unknown"
  };
}

function parseAzureResourceId(resourceId: string): { service: string; region?: string; resourceType: string } {
  const parts = resourceId.split("/").filter(Boolean);
  const providerIndex = parts.findIndex((part) => part.toLowerCase() === "providers");
  if (providerIndex >= 0 && parts[providerIndex + 1]) {
    const providerNs = parts[providerIndex + 1];
    const type = parts[providerIndex + 2] ?? "unknown";
    return { service: providerNs.toLowerCase(), resourceType: type };
  }
  return { service: "azure", resourceType: "unknown" };
}

function parseGcpResourceName(resourceId: string): { service: string; region?: string; resourceType: string } {
  const normalized = resourceId.replace(/^\/\//, "");
  const [host, ...rest] = normalized.split("/");
  const service = host.split(".")[0] || "gcp";
  const resourceType = rest[0] ?? "unknown";
  return { service, resourceType };
}

export function parseResourceIdentity(
  provider: EstimatorProvider,
  resourceId: string
): { service: string; region?: string; resourceType: string } {
  if (provider === "aws") return parseAwsArn(resourceId);
  if (provider === "azure") return parseAzureResourceId(resourceId);
  return parseGcpResourceName(resourceId);
}

function findMapping(resourceId: string, mapping: MappingEntry[]): MappingEntry | undefined {
  const matches = mapping.filter((entry) => resourceId.startsWith(entry.matchPrefix) || resourceId.includes(entry.matchPrefix));
  matches.sort((a, b) => b.matchPrefix.length - a.matchPrefix.length);
  return matches[0];
}

/**
 * Lookup keys for an AWS ARN's resource kind, most specific first:
 *   arn:aws:ec2:r:a:subnet/subnet-1                      -> ["ec2:subnet/subnet-1", "ec2:subnet"]
 *   arn:aws:elasticloadbalancing:r:a:loadbalancer/app/x  -> ["elasticloadbalancing:loadbalancer/app", "elasticloadbalancing:loadbalancer"]
 *   arn:aws:rds:r:a:db:orders                            -> ["rds:db/orders", "rds:db"]
 * ARNs whose resource part is a bare name (SQS queues, SNS topics, S3 buckets) carry no
 * kind and return no keys; those services have a single common type anyway.
 */
export function awsArnTypeKeys(arn: string): string[] {
  const parts = arn.split(":");
  if (parts.length < 6 || parts[0] !== "arn") return [];
  const service = parts[2];
  const resource = parts.slice(5).join(":");
  const segments = resource.split(/[/:]/);
  if (segments.length < 2 || !segments[0]) return [];
  return [`${service}:${segments[0]}/${segments[1]}`, `${service}:${segments[0]}`];
}

/** True when the ARN's resource part is just a name, with no kind segment or path. */
export function isBareNameArn(arn: string): boolean {
  const parts = arn.split(":");
  return parts.length === 6 && parts[0] === "arn" && parts[5].length > 0 && !parts[5].includes("/");
}

export type AwsTypeHint = {
  typeIndex?: AwsTypeIndex;
  /** AWS Config resource type, when discovery supplied one. */
  sourceResourceType?: string;
  /** Evidence from discovery (a controller's tag, the default VPC) that the resource was auto-created. */
  autoCreatedReason?: string;
};

/**
 * Why a resource of this kind is probably not in Terraform state, from its type or ARN
 * alone. Undefined when nothing about the kind suggests it.
 */
export function findAutoCreatedReason(rules: AwsAutoCreatedRules, resourceId: string, sourceResourceType?: string): string | undefined {
  if (sourceResourceType) {
    const byConfig = rules.byConfigType.get(sourceResourceType);
    if (byConfig) return byConfig;
  }
  for (const key of awsArnTypeKeys(resourceId)) {
    const byArn = rules.byArnKey.get(key);
    if (byArn) return byArn;
  }
  return rules.patterns.find((entry) => entry.pattern.test(resourceId))?.reason;
}

/**
 * Why a resource's tags say a controller or AWS service created it (an Auto Scaling group's
 * instances, a load balancer made by a Kubernetes controller). Both discovery sources use it.
 */
export function findAutoCreatedTagReason(rules: AwsAutoCreatedRules, resourceId: string, tagKeys: string[]): string | undefined {
  if (tagKeys.length === 0 || rules.tags.length === 0) return undefined;
  const present = new Set(tagKeys);
  let arnKeys: string[] | undefined;
  for (const rule of rules.tags) {
    if (!present.has(rule.key)) continue;
    if (!rule.onlyArnTypes) return rule.reason;
    arnKeys ??= awsArnTypeKeys(resourceId);
    if (arnKeys.some((key) => rule.onlyArnTypes?.includes(key))) return rule.reason;
  }
  return undefined;
}

/** Moves a RUM candidate to the likely-auto-created category when there is a reason to. */
function applyAutoCreated(row: EstimatorResourceRow, hint: AwsTypeHint): EstimatorResourceRow {
  if (row.classification !== "rum_candidate") return row;
  const reason =
    hint.autoCreatedReason ?? (hint.typeIndex ? findAutoCreatedReason(hint.typeIndex.autoCreated, row.resourceId, hint.sourceResourceType) : undefined);
  return reason ? { ...row, classification: "likely_auto_created", reasonCode: "LIKELY_AUTO_CREATED", reasonDetail: reason } : row;
}

const ECS_TASK_DEFINITION_ARN = /^(arn:[^:]+:ecs:[^:]*:[^:]*:task-definition\/[^:]+):(\d+)$/;

/**
 * Every revision of an ECS task definition is a separate object in AWS, but Terraform
 * tracks one per family. Keeps the newest revision of each family as the candidate and
 * moves the older ones to likely-auto-created.
 */
export function bucketSupersededTaskDefinitions(rows: EstimatorResourceRow[]): EstimatorResourceRow[] {
  const newest = new Map<string, number>();
  for (const row of rows) {
    if (row.classification !== "rum_candidate") continue;
    const match = ECS_TASK_DEFINITION_ARN.exec(row.resourceId);
    if (match) newest.set(match[1], Math.max(newest.get(match[1]) ?? 0, Number(match[2])));
  }
  if (newest.size === 0) return rows;
  return rows.map((row) => {
    if (row.classification !== "rum_candidate") return row;
    const match = ECS_TASK_DEFINITION_ARN.exec(row.resourceId);
    if (!match || Number(match[2]) === newest.get(match[1])) return row;
    return {
      ...row,
      classification: "likely_auto_created",
      reasonCode: "LIKELY_AUTO_CREATED",
      reasonDetail: "Older revision of a task definition; Terraform tracks one revision per family"
    };
  });
}

function findAwsTypeEntry(resourceId: string, hint: AwsTypeHint): AwsTypeEntry | undefined {
  if (!hint.typeIndex) return undefined;
  if (hint.sourceResourceType) {
    const byConfig = hint.typeIndex.byConfigType.get(hint.sourceResourceType);
    if (byConfig) return byConfig;
  }
  for (const key of awsArnTypeKeys(resourceId)) {
    const byArn = hint.typeIndex.byArnKey.get(key);
    if (byArn) return byArn;
  }
  return undefined;
}

export function classifyWithMapping(
  provider: EstimatorProvider,
  resourceId: string,
  mapping: MappingEntry[],
  awsHint: AwsTypeHint = {}
): EstimatorResourceRow {
  const parsed = parseResourceIdentity(provider, resourceId);

  // AWS: resolve the resource's own type first. The service-level mapping below gives every
  // resource of a service one type, which mislabels subnets, security groups and the like.
  const exact = provider === "aws" ? findAwsTypeEntry(resourceId, awsHint) : undefined;
  if (exact) {
    const base = { resourceId, service: parsed.service, resourceType: parsed.resourceType, region: parsed.region, typeMatch: "exact" as const };
    return exact.manageable
      ? applyAutoCreated({ ...base, classification: "rum_candidate", reasonCode: "MAPPED_MANAGEABLE", terraformResourceType: exact.terraformType }, awsHint)
      : { ...base, classification: "not_manageable", reasonCode: "NOT_SUPPORTED_BY_PROVIDER", reasonDetail: "No Terraform resource manages this kind of object" };
  }

  const matched = findMapping(resourceId, mapping);
  // A bare-name ARN (SQS queue, SNS topic, S3 bucket) belongs to a service with one common
  // resource kind, so its service default is the right type, not an approximation.
  const typeMatch =
    provider === "aws" && awsHint.typeIndex ? (isBareNameArn(resourceId) ? ("exact" as const) : ("service" as const)) : undefined;

  if (!matched) {
    return {
      resourceId,
      service: parsed.service,
      resourceType: parsed.resourceType,
      region: parsed.region,
      classification: "unmapped",
      reasonCode: "UNMAPPED_TYPE"
    };
  }

  if (!matched.rumEligible) {
    return {
      resourceId,
      service: parsed.service,
      resourceType: parsed.resourceType,
      region: parsed.region,
      classification: "excluded",
      reasonCode: "MAPPED_EXCLUDED",
      terraformResourceType: matched.terraformType,
      typeMatch
    };
  }

  const candidate: EstimatorResourceRow = {
    resourceId,
    service: parsed.service,
    resourceType: parsed.resourceType,
    region: parsed.region,
    classification: "rum_candidate",
    reasonCode: "MAPPED_MANAGEABLE",
    terraformResourceType: matched.terraformType,
    typeMatch
  };
  return provider === "aws" ? applyAutoCreated(candidate, awsHint) : candidate;
}

export function summarizeRows(rows: EstimatorResourceRow[]): EstimatorSummary {
  const summary: EstimatorSummary = { discoveredResources: rows.length, rumCandidates: 0, likelyAutoCreated: 0, nonManageable: 0, unmapped: 0 };
  for (const row of rows) {
    if (row.classification === "rum_candidate") summary.rumCandidates += 1;
    else if (row.classification === "likely_auto_created") summary.likelyAutoCreated += 1;
    else if (row.classification === "unmapped") summary.unmapped += 1;
    else summary.nonManageable += 1;
  }
  return summary;
}

/** The 12-digit account ID from an AWS ARN, if it has one (S3 bucket ARNs, for example, do not). */
export function awsAccountIdFromArn(resourceId: string): string | undefined {
  const account = resourceId.split(":")[4];
  return account && /^\d{12}$/.test(account) ? account : undefined;
}

export const UNKNOWN_ACCOUNT_ID = "unknown";

/**
 * Per-account totals, largest first. Rows without an account ID are grouped under
 * "unknown" so the breakdown always adds up to the run summary. Returns an empty list
 * when no row has an account ID (Azure, GCP).
 */
export function summarizeByAccount(rows: EstimatorResourceRow[]): EstimatorAccountSummary[] {
  if (!rows.some((row) => row.accountId)) return [];
  const grouped = new Map<string, EstimatorResourceRow[]>();
  for (const row of rows) {
    const key = row.accountId ?? UNKNOWN_ACCOUNT_ID;
    const bucket = grouped.get(key);
    if (bucket) bucket.push(row);
    else grouped.set(key, [row]);
  }
  return [...grouped.entries()]
    .map(([accountId, accountRows]) => ({ accountId, ...summarizeRows(accountRows) }))
    .sort((a, b) => b.rumCandidates - a.rumCandidates || a.accountId.localeCompare(b.accountId));
}

export function buildDiagnostics(classified: EstimatorResourceRow[]): EstimatorRunDiagnostics {
  const discovered = classified.length;
  const unmappedRows = classified.filter((row) => row.classification === "unmapped");
  const mappedResources = discovered - unmappedRows.length;
  const coveragePct = discovered === 0 ? 0 : Number(((mappedResources / discovered) * 100).toFixed(2));
  const permissionDeniedRows = classified.filter((row) => row.reasonCode === "PERMISSION_DENIED");
  const permissionCounts = new Map<string, number>();

  for (const row of permissionDeniedRows) {
    const permission = row.reasonDetail?.replace("Missing permission for ", "") || "unknown_permission";
    permissionCounts.set(permission, (permissionCounts.get(permission) ?? 0) + 1);
  }

  const topMissingPermissions = [...permissionCounts.entries()]
    .map(([permission, count]) => ({ permission, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 10);

  const unmappedCounts = new Map<string, { count: number; sampleResourceId: string }>();
  for (const row of unmappedRows) {
    const resourceRoot = row.resourceType.split(/[/:]/)[0] || "unknown";
    const key = `${row.service}:${resourceRoot}`;
    const existing = unmappedCounts.get(key);
    if (existing) {
      existing.count += 1;
    } else {
      unmappedCounts.set(key, { count: 1, sampleResourceId: row.resourceId });
    }
  }

  const topUnmappedPrefixes = [...unmappedCounts.entries()]
    .map(([key, value]) => ({ key, count: value.count, sampleResourceId: value.sampleResourceId }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 10);

  return {
    mappedResources,
    coveragePct,
    serviceLevelMatches: classified.filter((row) => row.typeMatch === "service").length,
    permissionDenied: permissionDeniedRows.length,
    topMissingPermissions,
    topUnmappedPrefixes
  };
}

export function buildIamRemediation(
  provider: EstimatorProvider,
  diagnostics: EstimatorRunDiagnostics,
  awsDiscoverySource: AwsDiscoverySource = "tagging-api"
) {
  const basePermissions =
    provider === "aws"
      ? awsDiscoverySource === "config-aggregator"
        ? ["config:SelectAggregateResourceConfig", "config:DescribeConfigurationAggregators"]
        : awsDiscoverySource === "combined"
          ? [
              "config:SelectAggregateResourceConfig",
              "config:DescribeConfigurationAggregators",
              "resourcegroupstaggingapi:GetResources",
              "sts:AssumeRole"
            ]
          : ["resourcegroupstaggingapi:GetResources"]
      : provider === "azure"
        ? ["Microsoft.Resources/subscriptions/resources/read"]
        : ["cloudasset.assets.searchAllResources"];
  const actions = new Set<string>(basePermissions);
  for (const item of diagnostics.topMissingPermissions) {
    actions.add(item.permission);
  }
  const sortedActions = [...actions].sort();
  return {
    actions: sortedActions,
    policy: {
      Version: "2012-10-17",
      Statement: [
        {
          Sid: "RumEstimatorReadOnly",
          Effect: "Allow",
          Action: sortedActions,
          Resource: "*"
        }
      ]
    }
  };
}
