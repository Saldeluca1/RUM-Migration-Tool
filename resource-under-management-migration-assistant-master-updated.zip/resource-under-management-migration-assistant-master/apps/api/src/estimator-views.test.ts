import { describe, expect, it } from "vitest";
import { INTERRUPTED_RUN_MESSAGE, markInterruptedRun, toEstimatorRunView } from "./estimator-views.js";
import type { EstimatorRunRecord } from "./estimator-types.js";

function run(overrides: Partial<EstimatorRunRecord> = {}): EstimatorRunRecord {
  return {
    id: "run-1",
    provider: "aws",
    status: "completed",
    createdAt: "2026-11-16T10:00:00.000Z",
    updatedAt: "2026-11-16T10:05:00.000Z",
    request: { scope: {} },
    ...overrides
  };
}

describe("toEstimatorRunView", () => {
  it("drops resource rows and reports their count", () => {
    const view = toEstimatorRunView(
      run({
        summary: { discoveredResources: 2, rumCandidates: 1, likelyAutoCreated: 0, nonManageable: 0, unmapped: 1 },
        resources: [
          { resourceId: "a", service: "ec2", resourceType: "instance", classification: "rum_candidate", reasonCode: "MAPPED_MANAGEABLE" },
          { resourceId: "b", service: "x", resourceType: "y", classification: "unmapped", reasonCode: "UNMAPPED_TYPE" }
        ]
      })
    );
    expect("resources" in view).toBe(false);
    expect(view.resourceCount).toBe(2);
    expect(view.summary?.rumCandidates).toBe(1);
  });

  it("reports zero resources for a run that has not finished", () => {
    const view = toEstimatorRunView(
      run({
        status: "running",
        progress: {
          phase: "discovering",
          resourcesDiscovered: 500,
          resourcesClassified: 0,
          pagesFetched: 1,
          retries: 0,
          startedAt: "2026-11-16T10:00:00.000Z",
          updatedAt: "2026-11-16T10:00:05.000Z"
        }
      })
    );
    expect(view.resourceCount).toBe(0);
    expect(view.progress?.resourcesDiscovered).toBe(500);
  });
});

describe("markInterruptedRun", () => {
  const now = "2026-11-16T12:00:00.000Z";

  it("fails runs left queued or running and clears stale progress", () => {
    for (const status of ["queued", "running"] as const) {
      const recovered = markInterruptedRun(
        run({
          status,
          progress: {
            phase: "discovering",
            resourcesDiscovered: 10,
            resourcesClassified: 0,
            pagesFetched: 1,
            retries: 0,
            startedAt: now,
            updatedAt: now
          }
        }),
        now
      );
      expect(recovered.status).toBe("failed");
      expect(recovered.errorMessage).toBe(INTERRUPTED_RUN_MESSAGE);
      expect(recovered.updatedAt).toBe(now);
      expect(recovered.progress).toBeUndefined();
    }
  });

  it("returns finished runs untouched", () => {
    const completed = run({ status: "completed" });
    const failed = run({ status: "failed", errorMessage: "boom" });
    expect(markInterruptedRun(completed, now)).toBe(completed);
    expect(markInterruptedRun(failed, now)).toBe(failed);
  });
});
