import type { DiscoveredResource } from "./estimator-types.js";
import { awsAccountIdFromArn } from "./estimator-analysis.js";

/**
 * Tagging API discovery across accounts, and merging it with AWS Config results.
 *
 * Live testing showed neither source is complete alone: Config only returns the resource
 * types its recorders record, and the Tagging API only returns resources that were tagged
 * at some point (and omits some types, such as IAM roles). The combined mode takes the
 * union of both.
 */

export const IAM_ROLE_NAME_PATTERN = /^[\w+=,.@-]{1,64}$/;
export const DEFAULT_ACCOUNT_CONCURRENCY = 5;
export const MAX_ACCOUNT_CONCURRENCY = 20;

export type TagFilter = { key: string; values?: string[] };

export function buildTaggingArgs(region: string, tagFilters: TagFilter[] = [], paginationToken?: string): string[] {
  const args = ["resourcegroupstaggingapi", "get-resources", "--region", region, "--output", "json"];
  for (const filter of tagFilters) {
    args.push("--tag-filters", `Key=${filter.key}${filter.values && filter.values.length > 0 ? `,Values=${filter.values.join(",")}` : ""}`);
  }
  if (paginationToken) args.push("--pagination-token", paginationToken);
  return args;
}

export type TaggedResource = { arn: string; tagKeys: string[] };

export function parseTaggingPage(stdout: string): { arns: string[]; resources: TaggedResource[]; nextToken?: string } {
  const parsed = JSON.parse(stdout) as {
    ResourceTagMappingList?: Array<{ ResourceARN?: string; Tags?: Array<{ Key?: string }> }>;
    PaginationToken?: string;
  };
  const resources: TaggedResource[] = [];
  for (const entry of parsed.ResourceTagMappingList ?? []) {
    if (!entry.ResourceARN) continue;
    resources.push({ arn: entry.ResourceARN, tagKeys: (entry.Tags ?? []).map((tag) => tag.Key).filter(Boolean) as string[] });
  }
  return { arns: resources.map((resource) => resource.arn), resources, nextToken: parsed.PaginationToken || undefined };
}

/** Scans the given regions of one account. `runQuery` executes one CLI call with that account's credentials. */
export async function scanTaggingRegions(options: {
  regions: string[];
  tagFilters?: TagFilter[];
  runQuery: (args: string[]) => Promise<string>;
  /**
   * Returns why a resource's tags mark it as created by a controller or AWS service, if they
   * do. Tag values are never read or kept; only the reason is stored.
   */
  autoCreatedReasonFor?: (arn: string, tagKeys: string[]) => string | undefined;
  onRegionStart?: (region: string, index: number, total: number) => void;
  onPage?: (pagesFetched: number, resourcesDiscovered: number) => void;
  onRegionDone?: (index: number, total: number) => void;
}): Promise<{ arns: string[]; pagesFetched: number; autoCreated: Map<string, string> }> {
  const discovered = new Set<string>();
  const autoCreated = new Map<string, string>();
  let pagesFetched = 0;
  for (const [index, region] of options.regions.entries()) {
    options.onRegionStart?.(region, index, options.regions.length);
    let token: string | undefined;
    do {
      const page = parseTaggingPage(await options.runQuery(buildTaggingArgs(region, options.tagFilters, token)));
      for (const resource of page.resources) {
        discovered.add(resource.arn);
        const reason = options.autoCreatedReasonFor?.(resource.arn, resource.tagKeys);
        if (reason) autoCreated.set(resource.arn, reason);
      }
      token = page.nextToken;
      pagesFetched += 1;
      options.onPage?.(pagesFetched, discovered.size);
    } while (token);
    options.onRegionDone?.(index, options.regions.length);
  }
  return { arns: [...discovered], pagesFetched, autoCreated };
}

export function buildAssumeRoleArgs(accountId: string, roleName: string, externalId?: string): string[] {
  if (!/^\d{12}$/.test(accountId)) throw new Error(`Invalid account ID for role assumption: ${JSON.stringify(accountId)}`);
  if (!IAM_ROLE_NAME_PATTERN.test(roleName)) throw new Error(`Invalid IAM role name: ${JSON.stringify(roleName)}`);
  const args = [
    "sts",
    "assume-role",
    "--role-arn",
    `arn:aws:iam::${accountId}:role/${roleName}`,
    "--role-session-name",
    "rum-estimator",
    "--output",
    "json"
  ];
  if (externalId) args.push("--external-id", externalId);
  return args;
}

/** Turns an assume-role response into environment overrides for subsequent CLI calls. */
export function parseAssumedRoleEnv(stdout: string): Record<string, string> {
  const credentials = (JSON.parse(stdout) as { Credentials?: { AccessKeyId?: string; SecretAccessKey?: string; SessionToken?: string } }).Credentials;
  if (!credentials?.AccessKeyId || !credentials.SecretAccessKey || !credentials.SessionToken) {
    throw new Error("assume-role response did not include credentials");
  }
  return {
    AWS_ACCESS_KEY_ID: credentials.AccessKeyId,
    AWS_SECRET_ACCESS_KEY: credentials.SecretAccessKey,
    AWS_SESSION_TOKEN: credentials.SessionToken,
    // A profile in the base environment would otherwise take precedence over these keys.
    AWS_PROFILE: ""
  };
}

/**
 * Runs `worker` over `items` with at most `concurrency` in flight. A failing item does not
 * stop the others; results come back in input order as settled outcomes.
 */
export async function runPool<T, R>(
  items: T[],
  concurrency: number,
  worker: (item: T, index: number) => Promise<R>
): Promise<Array<{ ok: true; value: R } | { ok: false; error: unknown }>> {
  const results = new Array<{ ok: true; value: R } | { ok: false; error: unknown }>(items.length);
  let next = 0;
  const lanes = Array.from({ length: Math.max(1, Math.min(concurrency, items.length)) }, async () => {
    while (next < items.length) {
      const index = next;
      next += 1;
      try {
        results[index] = { ok: true, value: await worker(items[index], index) };
      } catch (error) {
        results[index] = { ok: false, error };
      }
    }
  });
  await Promise.all(lanes);
  return results;
}

/**
 * The same resource can be spelled slightly differently by the two sources: Config reports
 * log groups with a trailing ":*" that the Tagging API omits.
 */
export function normalizeArnForMerge(arn: string): string {
  return arn.endsWith(":*") ? arn.slice(0, -2) : arn;
}

export type MergeResult = {
  resources: DiscoveredResource[];
  foundByBoth: number;
  foundByConfigOnly: number;
  foundByTaggingOnly: number;
};

/** Union of both sources by ARN. Config's row wins when both have one (it carries account, region and type). */
export function mergeDiscoveries(
  configResources: DiscoveredResource[],
  taggingArns: string[],
  taggingAutoCreated: Map<string, string> = new Map()
): MergeResult {
  const merged = new Map<string, DiscoveredResource>();
  for (const resource of configResources) {
    merged.set(normalizeArnForMerge(resource.resourceId), { ...resource, discoveredBy: "config" });
  }
  let foundByBoth = 0;
  let foundByTaggingOnly = 0;
  for (const arn of new Set(taggingArns)) {
    const key = normalizeArnForMerge(arn);
    const existing = merged.get(key);
    const autoCreatedReason = taggingAutoCreated.get(arn);
    if (existing) {
      if (existing.discoveredBy === "config") {
        existing.discoveredBy = "both";
        foundByBoth += 1;
      }
      existing.autoCreatedReason ??= autoCreatedReason;
    } else {
      merged.set(key, { resourceId: arn, accountId: awsAccountIdFromArn(arn), discoveredBy: "tagging", autoCreatedReason });
      foundByTaggingOnly += 1;
    }
  }
  const resources = [...merged.values()];
  return {
    resources,
    foundByBoth,
    foundByConfigOnly: resources.filter((resource) => resource.discoveredBy === "config").length,
    foundByTaggingOnly
  };
}

/** Short, single-line reason for a failed account, safe to store and show. */
export function describeAccountError(error: unknown): string {
  const message = error instanceof Error ? error.message : String(error);
  const firstLine = message.split("\n").map((line) => line.trim()).find(Boolean) ?? "unknown error";
  return firstLine.length > 300 ? `${firstLine.slice(0, 297)}...` : firstLine;
}
