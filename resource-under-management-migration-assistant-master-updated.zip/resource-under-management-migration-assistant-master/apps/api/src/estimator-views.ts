import type { EstimatorRunRecord, EstimatorRunView } from "./estimator-types.js";

/**
 * Status/list view of a run: summary, progress and diagnostics without the resource rows.
 * Rows can number in the hundreds of thousands, and clients poll this once a second or so;
 * they fetch rows from the category endpoints (or ?include=resources) when they need them.
 */
export function toEstimatorRunView(run: EstimatorRunRecord): EstimatorRunView {
  const { resources, ...rest } = run;
  return {
    ...rest,
    resourceCount: resources?.length ?? run.summary?.discoveredResources ?? 0
  };
}

export const INTERRUPTED_RUN_MESSAGE =
  "Run was interrupted because the API process restarted before it finished. Start the run again.";

/**
 * Jobs live only in the API process. A run still marked queued/running when the store is
 * loaded from disk belongs to a process that no longer exists and would otherwise be polled
 * forever. Returns the same object when no change is needed.
 */
export function markInterruptedRun(run: EstimatorRunRecord, nowIso: string): EstimatorRunRecord {
  if (run.status !== "queued" && run.status !== "running") return run;
  const { progress: _progress, ...rest } = run;
  return {
    ...rest,
    status: "failed",
    errorMessage: INTERRUPTED_RUN_MESSAGE,
    updatedAt: nowIso
  };
}
