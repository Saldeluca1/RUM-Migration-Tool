import { describe, expect, it } from "vitest";
import {
  buildAssumeRoleArgs,
  buildTaggingArgs,
  describeAccountError,
  mergeDiscoveries,
  normalizeArnForMerge,
  parseAssumedRoleEnv,
  runPool,
  scanTaggingRegions
} from "./aws-tagging-discovery.js";

const page = (arns: string[], token?: string) =>
  JSON.stringify({ ResourceTagMappingList: arns.map((ResourceARN) => ({ ResourceARN })), PaginationToken: token ?? "" });

describe("buildTaggingArgs", () => {
  it("builds a region-scoped call with optional filters and token", () => {
    expect(buildTaggingArgs("eu-west-1")).toEqual(["resourcegroupstaggingapi", "get-resources", "--region", "eu-west-1", "--output", "json"]);
    expect(buildTaggingArgs("us-east-1", [{ key: "Env", values: ["prod", "dev"] }, { key: "Owner" }], "tok").slice(6)).toEqual([
      "--tag-filters",
      "Key=Env,Values=prod,dev",
      "--tag-filters",
      "Key=Owner",
      "--pagination-token",
      "tok"
    ]);
  });
});

describe("scanTaggingRegions", () => {
  it("walks every region, follows tokens and de-duplicates", async () => {
    const calls: string[][] = [];
    const responses: Record<string, string[]> = {
      "us-east-1|": [page(["arn:a", "arn:b"], "t1")],
      "us-east-1|t1": [page(["arn:b", "arn:c"])],
      "us-west-2|": [page(["arn:d"])]
    };
    const regionsStarted: string[] = [];
    const result = await scanTaggingRegions({
      regions: ["us-east-1", "us-west-2"],
      runQuery: async (args) => {
        calls.push(args);
        const region = args[args.indexOf("--region") + 1];
        const tokenIndex = args.indexOf("--pagination-token");
        return responses[`${region}|${tokenIndex >= 0 ? args[tokenIndex + 1] : ""}`][0];
      },
      onRegionStart: (region) => regionsStarted.push(region)
    });
    expect(calls).toHaveLength(3);
    expect(result).toEqual({ arns: ["arn:a", "arn:b", "arn:c", "arn:d"], pagesFetched: 3, autoCreated: new Map() });
    expect(regionsStarted).toEqual(["us-east-1", "us-west-2"]);
  });
});

describe("assume role", () => {
  it("builds the role ARN from account and role name", () => {
    expect(buildAssumeRoleArgs("111111111111", "RumEstimatorReadOnly")).toEqual([
      "sts",
      "assume-role",
      "--role-arn",
      "arn:aws:iam::111111111111:role/RumEstimatorReadOnly",
      "--role-session-name",
      "rum-estimator",
      "--output",
      "json"
    ]);
    expect(buildAssumeRoleArgs("111111111111", "r", "ext-1").slice(-2)).toEqual(["--external-id", "ext-1"]);
  });

  it("rejects malformed accounts and role names", () => {
    expect(() => buildAssumeRoleArgs("123", "role")).toThrow(/Invalid account ID/);
    expect(() => buildAssumeRoleArgs("111111111111", "bad role/../x")).toThrow(/Invalid IAM role name/);
  });

  it("converts credentials to environment overrides and clears any profile", () => {
    const env = parseAssumedRoleEnv(JSON.stringify({ Credentials: { AccessKeyId: "ASIAX", SecretAccessKey: "s", SessionToken: "t" } }));
    expect(env).toEqual({ AWS_ACCESS_KEY_ID: "ASIAX", AWS_SECRET_ACCESS_KEY: "s", AWS_SESSION_TOKEN: "t", AWS_PROFILE: "" });
  });

  it("rejects a response without credentials", () => {
    expect(() => parseAssumedRoleEnv("{}")).toThrow(/did not include credentials/);
  });
});

describe("runPool", () => {
  it("limits concurrency, keeps input order and isolates failures", async () => {
    let inFlight = 0;
    let peak = 0;
    const results = await runPool([1, 2, 3, 4, 5, 6], 2, async (n) => {
      inFlight += 1;
      peak = Math.max(peak, inFlight);
      await new Promise((resolve) => setTimeout(resolve, 5));
      inFlight -= 1;
      if (n === 3) throw new Error("boom");
      return n * 10;
    });
    expect(peak).toBe(2);
    expect(results.map((r) => (r.ok ? r.value : "failed"))).toEqual([10, 20, "failed", 40, 50, 60]);
  });

  it("handles an empty list", async () => {
    expect(await runPool([], 5, async () => 1)).toEqual([]);
  });
});

describe("mergeDiscoveries", () => {
  it("takes the union and records which source found each resource", () => {
    const merged = mergeDiscoveries(
      [
        { resourceId: "arn:aws:dynamodb:us-east-1:111111111111:table/t1", accountId: "111111111111", region: "us-east-1", sourceResourceType: "AWS::DynamoDB::Table" },
        { resourceId: "arn:aws:iam::111111111111:role/r1", accountId: "111111111111", sourceResourceType: "AWS::IAM::Role" }
      ],
      ["arn:aws:dynamodb:us-east-1:111111111111:table/t1", "arn:aws:sqs:us-east-1:222222222222:q1", "arn:aws:sqs:us-east-1:222222222222:q1"]
    );
    expect(merged.resources).toEqual([
      { resourceId: "arn:aws:dynamodb:us-east-1:111111111111:table/t1", accountId: "111111111111", region: "us-east-1", sourceResourceType: "AWS::DynamoDB::Table", discoveredBy: "both" },
      { resourceId: "arn:aws:iam::111111111111:role/r1", accountId: "111111111111", sourceResourceType: "AWS::IAM::Role", discoveredBy: "config" },
      { resourceId: "arn:aws:sqs:us-east-1:222222222222:q1", accountId: "222222222222", discoveredBy: "tagging" }
    ]);
    expect(merged).toMatchObject({ foundByBoth: 1, foundByConfigOnly: 1, foundByTaggingOnly: 1 });
  });

  it("matches log groups despite Config's trailing wildcard", () => {
    expect(normalizeArnForMerge("arn:aws:logs:us-east-1:1:log-group:/app:*")).toBe("arn:aws:logs:us-east-1:1:log-group:/app");
    const merged = mergeDiscoveries(
      [{ resourceId: "arn:aws:logs:us-east-1:111111111111:log-group:/app:*", accountId: "111111111111" }],
      ["arn:aws:logs:us-east-1:111111111111:log-group:/app"]
    );
    expect(merged.resources).toHaveLength(1);
    expect(merged.foundByBoth).toBe(1);
  });
});

describe("describeAccountError", () => {
  it("keeps the first non-empty line and truncates long messages", () => {
    expect(describeAccountError(new Error("\nAn error occurred (AccessDenied): nope\nmore detail"))).toBe("An error occurred (AccessDenied): nope");
    expect(describeAccountError(new Error("x".repeat(400))).length).toBe(300);
  });
});
