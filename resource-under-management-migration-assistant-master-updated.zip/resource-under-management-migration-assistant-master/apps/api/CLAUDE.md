# API Server (apps/api)

Express.js backend serving three domains: managed state scanning, unmanaged estimation, and TFE migration.

## Route Structure

| Prefix | Domain | Job File |
|---|---|---|
| `/scans/*` | Managed state scanning | `rum-job.ts` |
| `/estimator/*` | Unmanaged resource estimation | `estimator-job.ts` |
| `/tfe/*` | TFE-to-TFC migration | `tfe-job.ts` |

## Adding a New Domain (Pattern)

1. Create types in `xxx-types.ts`
2. Create store in `xxx-store.ts` (copy `store.ts` pattern: Map + JSON persistence)
3. Create job in `xxx-job.ts` (async function, updates store on completion/failure)
4. Add Zod schema + routes in `server.ts`
5. Add credential redaction function if the request includes sensitive fields

## Job Lifecycle

```
POST → Zod validate → createRecord(redactedRequest) → void runJob(id, originalRequest) → 202
Job: updateRecord(id, {status: "running"}) → do work → updateRecord(id, {status: "completed", summary, ...})
Client: poll GET /xxx/:id every 1s until status !== "queued" && status !== "running"
```

Estimator specifics:

- Runs report a `progress` object while running. Progress updates use `updateEstimatorRun(..., { persist: false })` so they do not rewrite the store file; only status changes persist.
- `GET /estimator/runs` and `GET /estimator/runs/:id` return `toEstimatorRunView(run)` (no resource rows). Rows come from the category endpoints or `?include=resources`.
- Runs found `queued`/`running` at startup are marked `failed` (their process is gone).
- Every cloud CLI call goes through `cli-runner.ts`: per-call timeout plus retry with backoff for throttling, timeouts and transient errors. Permission and validation errors are not retried.
- AWS has three discovery sources (`scope.discoverySource`): `tagging-api` (default, one account), `config-aggregator` (all accounts in an AWS Config aggregator) and `combined` (aggregator plus a per-account Tagging API scan through an assumed role, merged by ARN; a failed account is recorded in `discovery.failedAccounts`, not fatal). Values interpolated into the Config query expression (regions, account IDs) must stay pattern-validated in both the Zod schema and `aws-config-discovery.ts`.

- AWS rows that Terraform could manage but that AWS or another resource normally creates (network interfaces, volumes, snapshots, Auto Scaling instances, the default VPC...) are classified `likely_auto_created`, not `rum_candidate`. Rules are data, in the `likelyAutoCreated` section of `aws_resource_type_to_tf.json`: by kind, by ARN pattern, by tag key, and by extra Config queries (`findAutoCreatedViaConfig`). A failed extra query is recorded in `discovery.autoCreatedChecksFailed`, not fatal. Tag values must never be stored; only the matched reason is kept.

## Store Pattern

Each store module exports: `create*`, `update*`, `get*`, `list*`. Backed by in-memory `Map<string, Record>` with JSON file sync to `data/`.

## Key Files

- `server.ts` — All routes, Zod schemas, redaction functions
- `types.ts` — Managed scan types
- `estimator-types.ts` — Unmanaged estimator types
- `store.ts` / `estimator-store.ts` — Persistence layers
- `rum-job.ts` — Managed state scanning (cloud CLI → download → rum-engine)
- `estimator-job.ts` — Unmanaged resource discovery (cloud CLI → classify → diagnostics), progress reporting
- `aws-config-discovery.ts` — AWS Config aggregator query building, paging and result parsing (pure, unit-tested)
- `aws-tagging-discovery.ts` — Tagging API scan, per-account role assumption, account worker pool, and merge with Config results
- `cli-runner.ts` — Cloud CLI execution with timeout and retry/backoff
- `estimator-views.ts` — Lightweight run view and interrupted-run recovery
- `estimator-analysis.ts` — Pure classification/diagnostic functions
- `estimator-mapping.ts` — Mapping file loading with freshness tracking. AWS has two files: `aws_resource_to_tf.json` (one default type per service) and `aws_resource_type_to_tf.json` (per resource type, by AWS Config type or ARN segment; tried first). After editing the latter run `node scripts/mappings/validate_aws_type_mapping.mjs`
