#!/usr/bin/env bash
# Smoke test for the AWS Config aggregator discovery path of the unmanaged estimator.
#
# Usage: aws_config_aggregator_estimator_smoke.sh <aggregator-name> [aggregator-region] [regions-csv]
#
# Requires the API running with ENABLE_AWS_UNMANAGED_ESTIMATOR=true and AWS credentials
# (environment or AWS_PROFILE) for the account that owns the aggregator.
set -euo pipefail

for tool in curl node; do
  if ! command -v "$tool" >/dev/null 2>&1; then
    echo "$tool is required." >&2
    exit 1
  fi
done

API_BASE="${API_BASE:-http://localhost:8080}"
AGGREGATOR="${1:-}"
AGGREGATOR_REGION="${2:-}"
REGIONS="${3:-}"
TIMEOUT_SECONDS="${TIMEOUT_SECONDS:-3600}"

if [[ -z "$AGGREGATOR" ]]; then
  echo "Usage: $0 <aggregator-name> [aggregator-region] [regions-csv]" >&2
  exit 1
fi

REQUEST_PAYLOAD=$(AGGREGATOR="$AGGREGATOR" AGGREGATOR_REGION="$AGGREGATOR_REGION" REGIONS="$REGIONS" node -e '
const regions = (process.env.REGIONS || "").split(",").map((r) => r.trim()).filter(Boolean);
const scope = {
  discoverySource: "config-aggregator",
  configAggregator: { name: process.env.AGGREGATOR }
};
if (process.env.AGGREGATOR_REGION) scope.configAggregator.region = process.env.AGGREGATOR_REGION;
if (regions.length > 0) scope.regions = regions;
process.stdout.write(JSON.stringify({ scope }));
')

RUN_JSON=$(curl -sS -X POST "$API_BASE/estimator/aws/runs" -H 'Content-Type: application/json' -d "$REQUEST_PAYLOAD")
RUN_ID=$(echo "$RUN_JSON" | node -e "const fs=require('fs');const d=JSON.parse(fs.readFileSync(0,'utf8'));process.stdout.write(d.id||'')")

if [[ -z "$RUN_ID" ]]; then
  echo "FAIL estimator run not created: $RUN_JSON" >&2
  exit 1
fi
echo "Created estimator run: $RUN_ID"

STARTED=$(date +%s)
while true; do
  STATUS_JSON=$(curl -sS "$API_BASE/estimator/runs/$RUN_ID")
  LINE=$(echo "$STATUS_JSON" | node -e "
const fs=require('fs');const d=JSON.parse(fs.readFileSync(0,'utf8'));const p=d.progress||{};
process.stdout.write([d.status||'', p.phase||'', p.resourcesDiscovered??0, p.pagesFetched??0, p.retries??0].join(' '));")
  read -r STATUS PHASE DISCOVERED PAGES RETRIES <<<"$LINE"

  if [[ "$STATUS" == "completed" ]]; then
    echo "$STATUS_JSON" | node -e "
const fs=require('fs');const d=JSON.parse(fs.readFileSync(0,'utf8'));
const s=d.summary||{}, v=d.discovery||{};
if (s.discoveredResources === undefined || !d.mapping?.mappingVersion) { console.error('FAIL estimator summary incomplete'); process.exit(1); }
const accountTotal=(d.byAccount||[]).reduce((n,a)=>n+a.rumCandidates,0);
if ((d.byAccount||[]).length > 0 && accountTotal !== s.rumCandidates) { console.error('FAIL per-account candidates ('+accountTotal+') do not add up to summary ('+s.rumCandidates+')'); process.exit(1); }
console.log('PASS config aggregator smoke: discovered='+s.discoveredResources+' candidates='+s.rumCandidates+' unmapped='+s.unmapped
  +' accounts='+(v.accountsObserved??0)+' regions='+((v.regionsObserved||[]).length)
  +' skippedNonResource='+(v.skippedNonResourceItems??0)+' duplicates='+(v.duplicateItems??0)
  +' retries='+((d.progress||{}).retries??0)+' mappingVersion='+d.mapping.mappingVersion);"
    exit $?
  fi

  if [[ "$STATUS" == "failed" ]]; then
    echo "FAIL estimator run failed: $(echo "$STATUS_JSON" | node -e "const fs=require('fs');process.stdout.write(JSON.parse(fs.readFileSync(0,'utf8')).errorMessage||'unknown error')")" >&2
    exit 1
  fi

  if (( $(date +%s) - STARTED > TIMEOUT_SECONDS )); then
    echo "FAIL estimator run still $STATUS after ${TIMEOUT_SECONDS}s (run continues on the server)" >&2
    exit 1
  fi

  echo "  $STATUS/$PHASE discovered=$DISCOVERED pages=$PAGES retries=$RETRIES"
  sleep 3
done
