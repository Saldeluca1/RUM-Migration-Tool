#!/usr/bin/env node
// Validates the unmanaged estimator against the Terraform lab in infra/aws-config-lab.
//
// Usage: node scripts/tests/aws_config_lab_validation.mjs
//
// Needs: the lab applied, the API running with ENABLE_AWS_UNMANAGED_ESTIMATOR=true, and AWS
// credentials in the environment that may assume the two lab roles. Start the API with
// ESTIMATOR_CONFIG_ITEMS_PER_CALL=25 so paging is exercised by a small lab.
//
// The estimator itself only ever receives short-lived credentials for the lab's
// least-privilege role, passed in the request body (never written to disk by this script).
import { execFile } from "node:child_process";
import { promisify } from "node:util";

const run = promisify(execFile);
const API_BASE = process.env.API_BASE ?? "http://localhost:8080";
const LAB_DIR = process.env.LAB_DIR ?? "infra/aws-config-lab";
// AWS Config records new resources asynchronously and the aggregator lags behind that.
const SETTLE_MINUTES = Number(process.env.SETTLE_MINUTES ?? 30);
const RETRY_SECONDS = Number(process.env.RETRY_SECONDS ?? 60);

const results = [];
const record = (status, name, detail = "") => {
  results.push({ status, name });
  console.log(`${status.padEnd(4)} ${name}${detail ? ` — ${detail}` : ""}`);
};
const pass = (name, detail) => record("PASS", name, detail);
const fail = (name, detail) => record("FAIL", name, detail);
const warn = (name, detail) => record("WARN", name, detail);
const info = (message) => console.log(`     ${message}`);
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function terraformOutputs() {
  const { stdout } = await run("terraform", [`-chdir=${LAB_DIR}`, "output", "-json"], { maxBuffer: 10 * 1024 * 1024 });
  const raw = JSON.parse(stdout);
  const out = Object.fromEntries(Object.entries(raw).map(([key, value]) => [key, value.value]));
  if (!out.aggregator_name) throw new Error(`No Terraform outputs in ${LAB_DIR}. Has the lab been applied?`);
  return out;
}

async function assumeRole(roleArn, sessionName) {
  const { stdout } = await run("aws", [
    "sts", "assume-role", "--role-arn", roleArn, "--role-session-name", sessionName, "--duration-seconds", "3600", "--output", "json"
  ]);
  const c = JSON.parse(stdout).Credentials;
  return { awsAccessKeyId: c.AccessKeyId, awsSecretAccessKey: c.SecretAccessKey, awsSessionToken: c.SessionToken };
}

async function api(path, options) {
  const response = await fetch(`${API_BASE}${path}`, options);
  const body = await response.json();
  return { status: response.status, body };
}

async function estimate(scope, executionEnv, { timeoutSeconds = 900 } = {}) {
  const created = await api("/estimator/aws/runs", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ scope, executionEnv })
  });
  if (created.status !== 202) throw new Error(`Run not accepted (${created.status}): ${JSON.stringify(created.body)}`);
  if (JSON.stringify(created.body).includes(executionEnv.awsSecretAccessKey)) {
    throw new Error("API echoed the secret access key in its response");
  }
  const id = created.body.id;
  const deadline = Date.now() + timeoutSeconds * 1000;
  while (Date.now() < deadline) {
    const { body } = await api(`/estimator/runs/${id}`);
    if (body.status === "completed" || body.status === "failed") {
      if (body.status === "failed") return { run: body, rows: [] };
      const full = await api(`/estimator/runs/${id}?include=resources`);
      return { run: body, rows: full.body.resources ?? [] };
    }
    await sleep(2000);
  }
  throw new Error(`Run ${id} did not finish within ${timeoutSeconds}s`);
}

function labRows(rows, prefix) {
  return rows.filter((row) => row.resourceId.includes(`${prefix}-tagged-`) || row.resourceId.includes(`${prefix}-untagged-`)
    || row.resourceId.includes(`/${prefix}/tagged-`) || row.resourceId.includes(`/${prefix}/untagged-`));
}
const isUntagged = (row) => row.resourceId.includes("untagged-");

function countByType(rows) {
  const counts = {};
  for (const row of rows) {
    const type = row.sourceResourceType ?? "(no source type)";
    counts[type] ??= { tagged: 0, untagged: 0 };
    counts[type][isUntagged(row) ? "untagged" : "tagged"] += 1;
  }
  return counts;
}

/**
 * Which resource types each region's Config recorder records. An aggregator can only return
 * what the recorders collect, so the answer key has to be narrowed to that.
 */
async function recordersByRegion(regions) {
  const byRegion = {};
  for (const region of regions) {
    const { stdout } = await run("aws", ["configservice", "describe-configuration-recorders", "--region", region, "--output", "json"]);
    const group = JSON.parse(stdout).ConfigurationRecorders?.[0]?.recordingGroup;
    const strategy = group?.recordingStrategy?.useOnly ?? (group?.allSupported ? "ALL_SUPPORTED_RESOURCE_TYPES" : "INCLUSION_BY_RESOURCE_TYPES");
    byRegion[region] = {
      exists: Boolean(group),
      records(type, isGlobalType) {
        if (!group) return false;
        if (strategy === "ALL_SUPPORTED_RESOURCE_TYPES") return isGlobalType ? group.includeGlobalResourceTypes === true : true;
        if (strategy === "EXCLUSION_BY_RESOURCE_TYPES") return !(group.exclusionByResourceTypes?.resourceTypes ?? []).includes(type);
        return (group.resourceTypes ?? []).includes(type);
      }
    };
  }
  return byRegion;
}

/** Totals AWS Config should return per type, given where each type is recorded. */
function expectedFromConfig(expected, regions, recorders) {
  const totals = {};
  for (const [type, e] of Object.entries(expected)) {
    let copies;
    if (e.scope === "regional") copies = regions.filter((region) => recorders[region].records(type, false)).length;
    else if (e.scope === "primary") copies = recorders[regions[0]].records(type, false) ? 1 : 0;
    else copies = regions.some((region) => recorders[region].records(type, true)) ? 1 : 0;
    totals[type] = { tagged: e.tagged * copies, untagged: e.untagged * copies, recorded: copies > 0, scope: e.scope };
  }
  return totals;
}

function compareToExpected(counts, expected) {
  const problems = [];
  for (const [type, want] of Object.entries(expected)) {
    const got = counts[type] ?? { tagged: 0, untagged: 0 };
    if (got.tagged !== want.tagged || got.untagged !== want.untagged) {
      problems.push(`${type}: expected ${want.tagged} tagged + ${want.untagged} untagged, got ${got.tagged} + ${got.untagged}`);
    }
  }
  return problems;
}

async function main() {
  const lab = await terraformOutputs();
  const prefix = lab.name_prefix;
  const aggregator = { name: lab.aggregator_name, region: lab.aggregator_region };
  console.log(`Lab: account ${lab.account_id}, aggregator ${aggregator.name} (${aggregator.region}), regions ${lab.regions.join(", ")}`);
  console.log(`API: ${API_BASE}\n`);

  const recorders = await recordersByRegion(lab.regions);
  const missingRecorder = lab.regions.filter((region) => !recorders[region].exists);
  if (missingRecorder.length > 0) {
    fail("AWS Config recorder exists in every lab region", `none in ${missingRecorder.join(", ")}`);
    return;
  }
  const wanted = expectedFromConfig(lab.expected, lab.regions, recorders);
  const recordedTypes = Object.entries(wanted).filter(([, w]) => w.recorded).map(([type]) => type);
  const unrecordedTypes = Object.entries(wanted).filter(([, w]) => !w.recorded).map(([type]) => type);
  info(`recorded by this account's AWS Config: ${recordedTypes.join(", ") || "none of the lab types"}`);
  if (unrecordedTypes.length > 0) info(`not recorded (AWS Config cannot return these): ${unrecordedTypes.join(", ")}`);
  if (recordedTypes.length === 0) {
    fail("At least one lab resource type is recorded by AWS Config");
    return;
  }

  // Preferred: short-lived credentials for the lab's least-privilege role. Some organizations
  // block role chaining from federated sessions; in that case fall back to the caller's own
  // credentials and skip the checks that depend on the lab roles.
  let readOnly;
  let usingLabRoles = true;
  try {
    readOnly = await assumeRole(lab.estimator_read_only_role_arn, "rum-estimator-validation");
    pass("Estimator runs with the lab's least-privilege role");
  } catch (error) {
    usingLabRoles = false;
    const reason = (error instanceof Error ? error.message : String(error)).match(/not authorized to perform: [\w:]+/)?.[0] ?? "assume-role failed";
    if (!process.env.AWS_ACCESS_KEY_ID || !process.env.AWS_SECRET_ACCESS_KEY) throw error;
    readOnly = {
      awsAccessKeyId: process.env.AWS_ACCESS_KEY_ID,
      awsSecretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
      awsSessionToken: process.env.AWS_SESSION_TOKEN
    };
    warn("Estimator runs with the lab's least-privilege role", `could not assume it (${reason}); using the caller's credentials, so the documented minimum permissions are not verified`);
  }
  const configScope = (extra = {}) => ({ discoverySource: "config-aggregator", configAggregator: { ...aggregator }, ...extra });

  // 1. Aggregator lookup
  const lookup = await api("/estimator/aws/config-aggregators", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ aggregatorRegion: aggregator.region, executionEnv: readOnly })
  });
  const found = (lookup.body.aggregators ?? []).find((a) => a.name === aggregator.name);
  if (found) pass("Aggregator lookup lists the lab aggregator", `type=${found.type}, regions=${found.allRegions ? "all" : found.regions.join(",")}`);
  else fail("Aggregator lookup lists the lab aggregator", JSON.stringify(lookup.body).slice(0, 300));

  // 2. Config discovery finds every lab resource, tagged or not. Retried while Config catches up.
  const deadline = Date.now() + SETTLE_MINUTES * 60_000;
  let config;
  let problems = [];
  for (let attempt = 1; ; attempt += 1) {
    config = await estimate(configScope(), readOnly);
    if (config.run.status === "failed") {
      fail("Config aggregator run completes", config.run.errorMessage);
      return;
    }
    problems = compareToExpected(countByType(labRows(config.rows, prefix)), wanted);
    if (problems.length === 0 || Date.now() > deadline) break;
    info(`attempt ${attempt}: AWS Config has not recorded everything yet (${problems.length} type(s) short); retrying in ${RETRY_SECONDS}s`);
    await sleep(RETRY_SECONDS * 1000);
  }
  pass("Config aggregator run completes", `${config.run.summary.discoveredResources} resources, ${config.run.summary.rumCandidates} candidates in the account`);
  const recordedTotal = Object.values(wanted).reduce((sum, w) => sum + w.tagged + w.untagged, 0);
  if (problems.length === 0) pass("Config discovery finds every recorded lab resource, tagged and untagged", `${recordedTotal} resources across ${recordedTypes.length} types`);
  else fail("Config discovery finds every recorded lab resource, tagged and untagged", problems.join("; "));
  if (unrecordedTypes.length > 0) {
    pass("Resource types the recorder does not record are absent from Config results", `${unrecordedTypes.join(", ")} (expected limit: coverage follows the recorder)`);
  }

  const lab_ = labRows(config.rows, prefix);
  const discovery = config.run.discovery ?? {};

  // 3. Row fields
  const wrongAccount = lab_.filter((row) => row.accountId !== lab.account_id);
  if (wrongAccount.length === 0) pass("Every lab row carries the account ID");
  else fail("Every lab row carries the account ID", `${wrongAccount.length} rows, e.g. ${wrongAccount[0].resourceId} -> ${wrongAccount[0].accountId}`);

  const roles = lab_.filter((row) => row.sourceResourceType === "AWS::IAM::Role");
  const rolesWithRegion = roles.filter((row) => row.region);
  if (!wanted["AWS::IAM::Role"].recorded) warn("IAM roles are reported as global (no region)", "IAM roles are not recorded in this account");
  else if (roles.length > 0 && rolesWithRegion.length === 0) pass("IAM roles are reported as global (no region)");
  else fail("IAM roles are reported as global (no region)", roles.length === 0 ? "no IAM roles returned" : `region=${rolesWithRegion[0].region}`);

  const regional = lab_.filter((row) => wanted[row.sourceResourceType]?.scope === "regional");
  const regionsSeen = [...new Set(regional.map((row) => row.region))].sort();
  if (regional.length === 0) warn("Resources come back from both lab regions", "no regional lab type is recorded in this account");
  else if (lab.regions.every((region) => regionsSeen.includes(region))) pass("Resources come back from both lab regions", regionsSeen.join(", "));
  else fail("Resources come back from both lab regions", `saw ${regionsSeen.join(", ") || "none"}`);

  const unmappedLab = lab_.filter((row) => row.classification !== "rum_candidate");
  if (unmappedLab.length === 0) pass("Every lab resource classifies as a RUM candidate");
  else fail("Every lab resource classifies as a RUM candidate", `${unmappedLab.length} not candidates, e.g. ${unmappedLab[0].resourceId} (${unmappedLab[0].classification})`);

  const byAccountTotal = (config.run.byAccount ?? []).reduce((sum, a) => sum + a.rumCandidates, 0);
  if (byAccountTotal === config.run.summary.rumCandidates) pass("Per-account breakdown adds up to the summary");
  else fail("Per-account breakdown adds up to the summary", `${byAccountTotal} vs ${config.run.summary.rumCandidates}`);

  // 4. Paging and exclusions
  if ((discovery.pagesFetched ?? 0) > 1) pass("Continuation tokens work across calls", `${discovery.pagesFetched} calls`);
  else warn("Continuation tokens work across calls", `only one call was needed for ${discovery.pagesFetched ?? 0 ? config.run.summary.discoveredResources : 0} resources; lower ESTIMATOR_CONFIG_ITEMS_PER_CALL on the API, or wait for a newly created aggregator to finish collecting`);

  if ((discovery.skippedNonResourceItems ?? 0) > 0) pass("Compliance/inventory records are excluded", `${discovery.skippedNonResourceItems} skipped`);
  else warn("Compliance/inventory records are excluded", "none were returned; the Config rule may not have evaluated yet");

  info(`duplicates collapsed: ${discovery.duplicateItems ?? 0}; records with no usable identifier: ${discovery.skippedUnidentifiableItems ?? 0}`);
  const sourceTypes = [...new Set(config.rows.map((row) => row.sourceResourceType))].sort();
  info(`${sourceTypes.length} AWS Config resource types returned for this account`);
  const unmappedTypes = [...new Set(config.rows.filter((row) => row.classification === "unmapped").map((row) => row.sourceResourceType))].sort();
  if (unmappedTypes.length > 0) info(`unmapped types: ${unmappedTypes.slice(0, 15).join(", ")}${unmappedTypes.length > 15 ? ", ..." : ""}`);

  // 5. Filters
  const secondary = lab.regions[1];
  const regionFiltered = await estimate(configScope({ regions: [secondary] }), readOnly);
  const filteredLab = labRows(regionFiltered.rows, prefix);
  const leaked = filteredLab.filter((row) => row.region && row.region !== secondary);
  const filteredRoles = filteredLab.filter((row) => row.sourceResourceType === "AWS::IAM::Role").length;
  if (regionFiltered.run.status === "completed" && leaked.length === 0 && filteredLab.length > 0) {
    pass("Region filter returns only that region", `${filteredLab.length} lab rows in ${secondary}`);
  } else {
    fail("Region filter returns only that region", regionFiltered.run.errorMessage ?? `${leaked.length} rows from other regions, ${filteredLab.length} lab rows`);
  }
  if (!wanted["AWS::IAM::Role"].recorded) warn("Region filter still includes global resources", "IAM roles are not recorded in this account");
  else if (filteredRoles === roles.length && roles.length > 0) pass("Region filter still includes global resources", `${filteredRoles} IAM roles`);
  else fail("Region filter still includes global resources", `${filteredRoles} of ${roles.length} IAM roles returned with a region filter`);

  const otherAccount = await estimate(configScope({ configAggregator: { ...aggregator, accountIds: ["000000000000"] } }), readOnly);
  if (otherAccount.run.status === "completed" && otherAccount.rows.length === 0) pass("Account filter excludes other accounts");
  else fail("Account filter excludes other accounts", otherAccount.run.errorMessage ?? `${otherAccount.rows.length} rows returned for a non-existent account`);

  // 6. Tagging API comparison: the reason the Config path exists.
  const tagging = await estimate({ regions: lab.regions }, readOnly);
  if (tagging.run.status === "failed") {
    fail("Tagging API run completes", tagging.run.errorMessage);
  } else {
    const taggingLab = labRows(tagging.rows, prefix);
    const taggedSeen = taggingLab.filter((row) => !isUntagged(row)).length;
    const untaggedSeen = taggingLab.filter(isUntagged).length;
    const copies = (e) => (e.scope === "regional" ? lab.regions.length : 1);
    const expectedTagged = Object.values(lab.expected).reduce((sum, e) => sum + e.tagged * copies(e), 0);
    const expectedUntagged = Object.values(lab.expected).reduce((sum, e) => sum + e.untagged * copies(e), 0);
    pass("Tagging API run completes", `${tagging.run.summary.discoveredResources} resources`);
    if (untaggedSeen === 0) pass("Tagging API misses never-tagged resources", `0 of ${expectedUntagged} untagged lab resources returned; AWS Config returned every untagged resource of the types it records`);
    else fail("Tagging API misses never-tagged resources", `${untaggedSeen} untagged lab resources were returned; the documented limitation does not hold here`);
    const taggingOnly = taggingLab.filter((row) => !isUntagged(row) && unrecordedTypes.some((type) => row.resourceId.includes(`:${type.split("::")[1].toLowerCase()}:`))).length;
    if (unrecordedTypes.length > 0) info(`${taggingOnly} tagged lab resources of unrecorded types were found only by the Tagging API`);
    if (taggedSeen === expectedTagged) pass("Tagging API finds every tagged lab resource", `${taggedSeen} of ${expectedTagged}`);
    else warn("Tagging API finds every tagged lab resource", `${taggedSeen} of ${expectedTagged} (in live testing the Tagging API did not return tagged IAM roles)`);
  }

  // 6b. Combined method: union of both sources for this account.
  const combined = await estimate({ discoverySource: "combined", configAggregator: { ...aggregator }, regions: lab.regions }, readOnly);
  if (combined.run.status === "failed") {
    fail("Combined run completes", combined.run.errorMessage);
  } else {
    const combinedLab = labRows(combined.rows, prefix);
    const d = combined.run.discovery ?? {};
    pass("Combined run completes", `${combined.run.summary.discoveredResources} resources; both=${d.foundByBoth}, config only=${d.foundByConfigOnly}, tagging only=${d.foundByTaggingOnly}`);

    // Recorded types: everything. Unrecorded types: only the tagged ones (IAM roles are not
    // returned by the Tagging API at all).
    const copies = (e) => (e.scope === "regional" ? lab.regions.length : 1);
    let expectedUnion = 0;
    for (const [type, e] of Object.entries(lab.expected)) {
      if (wanted[type].recorded) expectedUnion += (e.tagged + e.untagged) * copies(e);
      else if (type !== "AWS::IAM::Role") expectedUnion += e.tagged * copies(e);
    }
    const labTotal = Object.values(lab.expected).reduce((sum, e) => sum + (e.tagged + e.untagged) * copies(e), 0);
    if (combinedLab.length === expectedUnion) pass("Combined run returns the union of both sources", `${combinedLab.length} of ${labTotal} lab resources (Config alone: ${lab_.length})`);
    else fail("Combined run returns the union of both sources", `expected ${expectedUnion}, got ${combinedLab.length}`);

    const duplicateIds = combinedLab.length - new Set(combinedLab.map((row) => row.resourceId.replace(/:\*$/, ""))).size;
    if (duplicateIds === 0) pass("Combined run does not double-count resources both sources return");
    else fail("Combined run does not double-count resources both sources return", `${duplicateIds} duplicates`);

    const byBoth = combinedLab.filter((row) => row.discoveredBy === "both");
    const wrongBoth = byBoth.filter(isUntagged);
    const untaggedLabels = combinedLab.filter(isUntagged).filter((row) => row.discoveredBy !== "config");
    if (byBoth.length > 0 && wrongBoth.length === 0 && untaggedLabels.length === 0) {
      pass("Each resource is labelled with the source that found it", `${byBoth.length} by both, ${combinedLab.filter((r) => r.discoveredBy === "config").length} Config only, ${combinedLab.filter((r) => r.discoveredBy === "tagging").length} Tagging API only`);
    } else {
      fail("Each resource is labelled with the source that found it", `both=${byBoth.length}, untagged labelled as tagged=${wrongBoth.length + untaggedLabels.length}`);
    }

    const missed = labTotal - combinedLab.length;
    if (missed > 0) info(`${missed} lab resources are invisible to both sources (never tagged, type not recorded by AWS Config)`);
    if ((d.failedAccounts ?? []).length > 0) fail("Combined run scans the account without errors", JSON.stringify(d.failedAccounts));
  }

  // 7. Permission failure is fast and clear
  if (!usingLabRoles) {
    warn("A role without permissions fails fast with a clear error", "skipped: the lab's no-access role could not be assumed");
  } else {
    const noAccess = await assumeRole(lab.estimator_no_access_role_arn, "rum-estimator-noaccess");
    const started = Date.now();
    const denied = await estimate(configScope(), noAccess, { timeoutSeconds: 120 });
    const seconds = Math.round((Date.now() - started) / 1000);
    const retries = denied.run.progress?.retries ?? 0;
    if (denied.run.status === "failed" && /AccessDenied|not authorized/i.test(denied.run.errorMessage ?? "") && retries === 0) {
      pass("A role without permissions fails fast with a clear error", `${seconds}s, no retries`);
    } else {
      fail("A role without permissions fails fast with a clear error", `status=${denied.run.status}, retries=${retries}, message=${denied.run.errorMessage}`);
    }
  }

  // 8. Nothing sensitive persisted
  const { body: stored } = await api("/estimator/runs");
  const serialized = JSON.stringify(stored);
  if (!serialized.includes(readOnly.awsSecretAccessKey) && !(readOnly.awsSessionToken && serialized.includes(readOnly.awsSessionToken))) pass("Stored runs contain no credentials");
  else fail("Stored runs contain no credentials");
}

try {
  await main();
} catch (error) {
  fail("Validation script ran to completion", error instanceof Error ? error.message : String(error));
}

const failed = results.filter((r) => r.status === "FAIL").length;
const warned = results.filter((r) => r.status === "WARN").length;
console.log(`\n${results.filter((r) => r.status === "PASS").length} passed, ${failed} failed, ${warned} warnings`);
process.exit(failed > 0 ? 1 : 0);
