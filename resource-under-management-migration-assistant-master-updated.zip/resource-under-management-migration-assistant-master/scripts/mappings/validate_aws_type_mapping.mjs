#!/usr/bin/env node
// Validates data/mappings/aws_resource_type_to_tf.json against the real AWS provider and
// the AWS CLI's service model.
//
// Usage: node scripts/mappings/validate_aws_type_mapping.mjs [terraform-dir]
//
// terraform-dir is any directory with the hashicorp/aws provider initialised
// (default: infra/aws-config-lab; run `terraform -chdir=<dir> init` first). No AWS
// credentials are needed.
import { execFileSync } from "node:child_process";
import { readFileSync } from "node:fs";

const terraformDir = process.argv[2] ?? "infra/aws-config-lab";
const mapping = JSON.parse(readFileSync("data/mappings/aws_resource_type_to_tf.json", "utf8"));

const schema = JSON.parse(execFileSync("terraform", [`-chdir=${terraformDir}`, "providers", "schema", "-json"], { maxBuffer: 1024 * 1024 * 1024 }).toString());
const provider = schema.provider_schemas?.["registry.terraform.io/hashicorp/aws"];
if (!provider) {
  console.error(`No hashicorp/aws provider schema in ${terraformDir}. Run terraform init there first.`);
  process.exit(2);
}
const providerTypes = new Set(Object.keys(provider.resource_schemas));

let configTypes;
try {
  const help = execFileSync("aws", ["configservice", "list-discovered-resources", "help"], { env: { ...process.env, AWS_PAGER: "" }, maxBuffer: 64 * 1024 * 1024 }).toString();
  configTypes = new Set(help.replace(/.\x08/g, "").match(/AWS::[A-Za-z0-9]+::[A-Za-z0-9]+/g) ?? []);
} catch {
  console.warn("AWS CLI not available; skipping the AWS Config type-name check.");
}

const problems = [];
for (const [configType, terraformType] of Object.entries(mapping.configTypes ?? {})) {
  if (!providerTypes.has(terraformType)) problems.push(`configTypes ${configType}: ${terraformType} is not an AWS provider resource`);
  if (configTypes && configTypes.size > 0 && !configTypes.has(configType)) problems.push(`configTypes ${configType}: not an AWS Config resource type known to this AWS CLI`);
}
for (const [arnKey, terraformType] of Object.entries(mapping.arnTypes ?? {})) {
  if (!providerTypes.has(terraformType)) problems.push(`arnTypes ${arnKey}: ${terraformType} is not an AWS provider resource`);
}

// likelyAutoCreated: every listed kind must be one the mapping would otherwise count, and
// every pattern must compile.
const autoCreated = mapping.likelyAutoCreated ?? {};
for (const configType of Object.keys(autoCreated.configTypes ?? {})) {
  if (!mapping.configTypes?.[configType]) problems.push(`likelyAutoCreated.configTypes ${configType}: not in configTypes`);
}
for (const entry of autoCreated.arnPatterns ?? []) {
  try {
    new RegExp(entry.pattern);
  } catch (error) {
    problems.push(`likelyAutoCreated.arnPatterns ${entry.pattern}: ${error.message}`);
  }
}
for (const marker of autoCreated.configMarkers ?? []) {
  const type = /^resourceType = '([^']+)'/.exec(marker.where)?.[1];
  if (!type) problems.push(`likelyAutoCreated.configMarkers ${marker.id}: where must start with resourceType = '...'`);
  else if (configTypes && configTypes.size > 0 && !configTypes.has(type)) problems.push(`likelyAutoCreated.configMarkers ${marker.id}: ${type} is not an AWS Config resource type known to this AWS CLI`);
}

console.log(`Checked ${Object.keys(mapping.configTypes ?? {}).length} Config types and ${Object.keys(mapping.arnTypes ?? {}).length} ARN types against ${providerTypes.size} provider resources${configTypes ? ` and ${configTypes.size} AWS Config types` : ""}.`);
if (problems.length > 0) {
  console.error(`${problems.length} problem(s):\n${problems.join("\n")}`);
  process.exit(1);
}
console.log("OK");
