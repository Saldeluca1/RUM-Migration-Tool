terraform {
  required_providers {
    aws = {
      source = "hashicorp/aws"
    }
  }
}

variable "name_prefix" {
  type = string
}

variable "count_each" {
  type = number
}

locals {
  half = var.count_each / 2
  # index -> "tagged" for the first half, "untagged" for the rest
  kind = [for i in range(var.count_each) : i < local.half ? "tagged" : "untagged"]
  tags = [for i in range(var.count_each) : i < local.half ? { Lab = var.name_prefix } : {}]
}

resource "aws_sqs_queue" "lab" {
  count = var.count_each
  name  = "${var.name_prefix}-${local.kind[count.index]}-queue-${count.index}"
  tags  = local.tags[count.index]
}

resource "aws_sns_topic" "lab" {
  count = var.count_each
  name  = "${var.name_prefix}-${local.kind[count.index]}-topic-${count.index}"
  tags  = local.tags[count.index]
}

resource "aws_dynamodb_table" "lab" {
  count        = var.count_each
  name         = "${var.name_prefix}-${local.kind[count.index]}-table-${count.index}"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "id"
  tags         = local.tags[count.index]

  attribute {
    name = "id"
    type = "S"
  }
}

resource "aws_cloudwatch_log_group" "lab" {
  count             = var.count_each
  name              = "/${var.name_prefix}/${local.kind[count.index]}-loggroup-${count.index}"
  retention_in_days = 1
  tags              = local.tags[count.index]
}
