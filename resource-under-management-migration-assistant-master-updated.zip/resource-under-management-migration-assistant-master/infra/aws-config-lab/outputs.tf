output "account_id" {
  value = local.account_id
}

output "name_prefix" {
  value = var.name_prefix
}

output "regions" {
  value = local.regions
}

output "aggregator_name" {
  value = aws_config_configuration_aggregator.lab.name
}

output "aggregator_region" {
  value = var.primary_region
}

output "estimator_read_only_role_arn" {
  value = aws_iam_role.estimator_read_only.arn
}

output "estimator_no_access_role_arn" {
  value = aws_iam_role.estimator_no_access.arn
}

# Answer key for the validation script: lab resources of each AWS Config type, split by
# whether they were ever tagged.
#   scope "regional": that many in each lab region
#   scope "primary":  that many, all in the primary region
#   scope "global":   that many, not tied to a region
# The script works out which of these the account's Config recorders actually record.
output "expected" {
  value = {
    "AWS::SQS::Queue"      = { tagged = local.half, untagged = local.half, scope = "regional" }
    "AWS::SNS::Topic"      = { tagged = local.half, untagged = local.half, scope = "regional" }
    "AWS::DynamoDB::Table" = { tagged = local.half, untagged = local.half, scope = "regional" }
    "AWS::Logs::LogGroup"  = { tagged = local.half, untagged = local.half, scope = "regional" }
    "AWS::S3::Bucket"      = { tagged = local.half, untagged = local.half, scope = "primary" }
    "AWS::IAM::Role"       = { tagged = local.half, untagged = local.half, scope = "global" }
  }
}
