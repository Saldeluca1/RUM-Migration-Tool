# AWS Config lab

A small, disposable AWS environment for validating the unmanaged estimator's AWS Config
aggregator discovery against real AWS. Build it, run the validation script, destroy it.

## What it creates

- AWS Config recorders and delivery channels in two regions, one delivery bucket, and one
  aggregator that collects both regions of this account.
- One managed Config rule, so compliance records exist for the estimator to exclude.
- Lab resources, half tagged and half never tagged, named `<prefix>-tagged-*` and
  `<prefix>-untagged-*`: SQS queues, SNS topics, DynamoDB on-demand tables and CloudWatch
  log groups in each region, plus IAM roles and S3 buckets.
- Two IAM roles for the estimator: a least-privilege read-only role, and a role with no
  permissions for testing the access-denied path.
- Optionally, a cost budget alert (`budget_alert_email`).

With the default `resources_per_type = 4` that is 40 lab resources. Everything is free or
near-free at rest; AWS Config bills per configuration item recorded, so apply, validate and
destroy in one sitting.

## Before you apply

- The credentials need to create IAM roles, S3 buckets, AWS Config recorders and the lab
  resource types above.
- AWS allows one Config recorder per region. If the account already has AWS Config enabled
  in both regions, set `manage_config_recorder = false`. Check with:

  ```bash
  aws configservice describe-configuration-recorders --region us-east-1
  aws configservice describe-configuration-recorders --region us-west-2
  ```

## Run it

```bash
terraform -chdir=infra/aws-config-lab init
terraform -chdir=infra/aws-config-lab apply

# In another terminal, from the repository root:
ENABLE_AWS_UNMANAGED_ESTIMATOR=true ESTIMATOR_CONFIG_ITEMS_PER_CALL=25 npm run dev -w @rum-tool/api

node scripts/tests/aws_config_lab_validation.mjs

terraform -chdir=infra/aws-config-lab destroy
```

`ESTIMATOR_CONFIG_ITEMS_PER_CALL=25` makes the estimator page through results 25 at a time
so a small lab exercises continuation tokens.

AWS Config records new resources asynchronously. The validation script retries for up to
30 minutes (`SETTLE_MINUTES`) while the aggregator catches up, so the first attempts
reporting missing resources is normal.

If the aggregator never returns data, check its source status; if it reports the account
as not authorized, apply again with `-var create_self_authorization=true`:

```bash
aws configservice describe-configuration-aggregator-sources-status \
  --configuration-aggregator-name rumlab-aggregator --region us-east-1
```

## What the validation checks

Every lab resource is found through AWS Config whether tagged or not; the Tagging API
finds only the tagged half; IAM roles come back as global; region and account filters work;
paging works; compliance records are excluded; a role without permissions fails fast; and
no credentials are stored.

It does not cover real API throttling or more than one account.

## Accounts with centrally managed AWS Config

If a security team already runs AWS Config in the account, leave their recorder alone:

```bash
terraform -chdir=infra/aws-config-lab apply -var manage_config_recorder=false -var create_config_rule=false
```

The validation script reads the live recorders and only expects the lab resource types they
record. Types they do not record are reported as an expected coverage limit.

If the organization blocks role chaining from your session (assume-role fails with
`sts:SetSourceIdentity`), the script falls back to your own credentials and skips the two
checks that need the lab roles.
