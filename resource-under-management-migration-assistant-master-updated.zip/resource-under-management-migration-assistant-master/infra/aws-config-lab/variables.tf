variable "name_prefix" {
  description = "Prefix for every lab resource. The validation script uses it to pick lab resources out of whatever else is in the account."
  type        = string
  default     = "rumlab"

  validation {
    condition     = can(regex("^[a-z][a-z0-9]{2,11}$", var.name_prefix))
    error_message = "name_prefix must be 3-12 lowercase letters or digits, starting with a letter."
  }
}

variable "primary_region" {
  description = "Region that hosts the aggregator and records global resources (IAM)."
  type        = string
  default     = "us-east-1"
}

variable "secondary_region" {
  description = "Second region, so the aggregator spans more than one."
  type        = string
  default     = "us-west-2"
}

variable "resources_per_type" {
  description = "Resources of each type per region. Half are tagged, half are never tagged. Must be even."
  type        = number
  default     = 4

  validation {
    condition     = var.resources_per_type >= 2 && var.resources_per_type <= 40 && var.resources_per_type % 2 == 0
    error_message = "resources_per_type must be an even number between 2 and 40."
  }
}

variable "manage_config_recorder" {
  description = "Create AWS Config recorders and delivery channels. Set to false if the account already has AWS Config enabled in both regions (only one recorder is allowed per region)."
  type        = bool
  default     = true
}

variable "create_config_rule" {
  description = "Create one managed Config rule so compliance records exist. Set to false in accounts where Config rules are centrally managed or feed security tooling."
  type        = bool
  default     = true
}

variable "create_self_authorization" {
  description = "Create aggregation authorizations for this account. Not normally needed when the aggregator and source are the same account; enable it if the aggregator reports the source as not authorized."
  type        = bool
  default     = false
}

variable "budget_alert_email" {
  description = "If set, creates a monthly cost budget that emails this address at 80% of budget_limit_usd."
  type        = string
  default     = ""
}

variable "budget_limit_usd" {
  description = "Monthly budget for the alert."
  type        = string
  default     = "5"
}
