data "aws_caller_identity" "current" {}
data "aws_partition" "current" {}

locals {
  account_id = data.aws_caller_identity.current.account_id
  half       = var.resources_per_type / 2
  regions    = [var.primary_region, var.secondary_region]
}

# ---------------------------------------------------------------------------
# AWS Config: recorders in two regions, one delivery bucket, one aggregator
# ---------------------------------------------------------------------------

resource "aws_s3_bucket" "config_delivery" {
  count         = var.manage_config_recorder ? 1 : 0
  bucket        = "${var.name_prefix}-config-delivery-${local.account_id}"
  force_destroy = true
}

resource "aws_s3_bucket_public_access_block" "config_delivery" {
  count                   = var.manage_config_recorder ? 1 : 0
  bucket                  = aws_s3_bucket.config_delivery[0].id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

data "aws_iam_policy_document" "config_assume" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["config.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "config_recorder" {
  count              = var.manage_config_recorder ? 1 : 0
  name               = "${var.name_prefix}-config-recorder"
  assume_role_policy = data.aws_iam_policy_document.config_assume.json
}

resource "aws_iam_role_policy_attachment" "config_recorder" {
  count      = var.manage_config_recorder ? 1 : 0
  role       = aws_iam_role.config_recorder[0].name
  policy_arn = "arn:${data.aws_partition.current.partition}:iam::aws:policy/service-role/AWS_ConfigRole"
}

data "aws_iam_policy_document" "config_delivery" {
  count = var.manage_config_recorder ? 1 : 0

  statement {
    actions   = ["s3:GetBucketAcl", "s3:ListBucket"]
    resources = [aws_s3_bucket.config_delivery[0].arn]
  }

  statement {
    actions   = ["s3:PutObject"]
    resources = ["${aws_s3_bucket.config_delivery[0].arn}/AWSLogs/${local.account_id}/Config/*"]
  }
}

resource "aws_iam_role_policy" "config_delivery" {
  count  = var.manage_config_recorder ? 1 : 0
  name   = "config-delivery"
  role   = aws_iam_role.config_recorder[0].id
  policy = data.aws_iam_policy_document.config_delivery[0].json
}

resource "aws_config_configuration_recorder" "primary" {
  count    = var.manage_config_recorder ? 1 : 0
  name     = "${var.name_prefix}-recorder"
  role_arn = aws_iam_role.config_recorder[0].arn

  recording_group {
    all_supported                 = true
    include_global_resource_types = true
  }
}

resource "aws_config_delivery_channel" "primary" {
  count          = var.manage_config_recorder ? 1 : 0
  name           = "${var.name_prefix}-delivery"
  s3_bucket_name = aws_s3_bucket.config_delivery[0].bucket

  depends_on = [aws_config_configuration_recorder.primary, aws_iam_role_policy.config_delivery]
}

resource "aws_config_configuration_recorder_status" "primary" {
  count      = var.manage_config_recorder ? 1 : 0
  name       = aws_config_configuration_recorder.primary[0].name
  is_enabled = true

  depends_on = [aws_config_delivery_channel.primary]
}

resource "aws_config_configuration_recorder" "secondary" {
  count    = var.manage_config_recorder ? 1 : 0
  provider = aws.secondary
  name     = "${var.name_prefix}-recorder"
  role_arn = aws_iam_role.config_recorder[0].arn

  recording_group {
    all_supported                 = true
    include_global_resource_types = false
  }
}

resource "aws_config_delivery_channel" "secondary" {
  count          = var.manage_config_recorder ? 1 : 0
  provider       = aws.secondary
  name           = "${var.name_prefix}-delivery"
  s3_bucket_name = aws_s3_bucket.config_delivery[0].bucket

  depends_on = [aws_config_configuration_recorder.secondary, aws_iam_role_policy.config_delivery]
}

resource "aws_config_configuration_recorder_status" "secondary" {
  count      = var.manage_config_recorder ? 1 : 0
  provider   = aws.secondary
  name       = aws_config_configuration_recorder.secondary[0].name
  is_enabled = true

  depends_on = [aws_config_delivery_channel.secondary]
}

resource "aws_config_aggregate_authorization" "primary" {
  count      = var.create_self_authorization ? 1 : 0
  account_id = local.account_id
  region     = var.primary_region
}

resource "aws_config_aggregate_authorization" "secondary" {
  count      = var.create_self_authorization ? 1 : 0
  provider   = aws.secondary
  account_id = local.account_id
  region     = var.primary_region
}

resource "aws_config_configuration_aggregator" "lab" {
  name = "${var.name_prefix}-aggregator"

  account_aggregation_source {
    account_ids = [local.account_id]
    regions     = local.regions
  }

  depends_on = [
    aws_config_configuration_recorder_status.primary,
    aws_config_configuration_recorder_status.secondary,
    aws_config_aggregate_authorization.primary,
    aws_config_aggregate_authorization.secondary,
  ]
}

# One managed rule so AWS Config produces compliance records. The estimator must exclude
# those from its counts; without a rule that exclusion is never exercised.
resource "aws_config_config_rule" "s3_versioning" {
  count = var.create_config_rule ? 1 : 0
  name  = "${var.name_prefix}-s3-versioning"

  source {
    owner             = "AWS"
    source_identifier = "S3_BUCKET_VERSIONING_ENABLED"
  }

  depends_on = [aws_config_configuration_recorder_status.primary]
}

# ---------------------------------------------------------------------------
# Lab resources. Names carry "tagged" or "untagged" so results can be checked by name.
# All are free or near-free at rest.
# ---------------------------------------------------------------------------

module "primary" {
  source      = "./modules/regional"
  name_prefix = var.name_prefix
  count_each  = var.resources_per_type

  depends_on = [aws_config_configuration_recorder_status.primary]
}

module "secondary" {
  source      = "./modules/regional"
  name_prefix = var.name_prefix
  count_each  = var.resources_per_type

  providers = {
    aws = aws.secondary
  }

  depends_on = [aws_config_configuration_recorder_status.secondary]
}

data "aws_iam_policy_document" "lab_role_assume" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["ec2.amazonaws.com"]
    }
  }
}

# Global resources: recorded once, with AWS Config's "global" region.
resource "aws_iam_role" "lab" {
  count              = var.resources_per_type
  name               = "${var.name_prefix}-${count.index < local.half ? "tagged" : "untagged"}-role-${count.index}"
  assume_role_policy = data.aws_iam_policy_document.lab_role_assume.json
  tags               = count.index < local.half ? { Lab = var.name_prefix } : {}

  depends_on = [aws_config_configuration_recorder_status.primary]
}

resource "aws_s3_bucket" "lab" {
  count         = var.resources_per_type
  bucket        = "${var.name_prefix}-${count.index < local.half ? "tagged" : "untagged"}-bucket-${local.account_id}-${count.index}"
  force_destroy = true
  tags          = count.index < local.half ? { Lab = var.name_prefix } : {}

  depends_on = [aws_config_configuration_recorder_status.primary]
}

# ---------------------------------------------------------------------------
# Roles the estimator is tested with
# ---------------------------------------------------------------------------

data "aws_iam_policy_document" "tool_assume" {
  statement {
    # SetSourceIdentity and TagSession are needed when the caller's own session carries a
    # source identity or session tags, as federated corporate sessions usually do.
    actions = ["sts:AssumeRole", "sts:SetSourceIdentity", "sts:TagSession"]
    principals {
      type        = "AWS"
      identifiers = ["arn:${data.aws_partition.current.partition}:iam::${local.account_id}:root"]
    }
  }
}

data "aws_iam_policy_document" "tool_read_only" {
  statement {
    sid = "RumEstimatorReadOnly"
    actions = [
      "config:SelectAggregateResourceConfig",
      "config:DescribeConfigurationAggregators",
      "tag:GetResources",
      "servicediscovery:GetNamespace",
    ]
    resources = ["*"]
  }
}

# Least-privilege role: exactly what the estimator documents as required.
resource "aws_iam_role" "estimator_read_only" {
  name               = "${var.name_prefix}-estimator-readonly"
  assume_role_policy = data.aws_iam_policy_document.tool_assume.json
}

resource "aws_iam_role_policy" "estimator_read_only" {
  name   = "rum-estimator-read-only"
  role   = aws_iam_role.estimator_read_only.id
  policy = data.aws_iam_policy_document.tool_read_only.json
}

# No permissions at all: used to check that a denied run fails fast with a clear message.
resource "aws_iam_role" "estimator_no_access" {
  name               = "${var.name_prefix}-estimator-noaccess"
  assume_role_policy = data.aws_iam_policy_document.tool_assume.json
}

# ---------------------------------------------------------------------------
# Optional cost alert
# ---------------------------------------------------------------------------

resource "aws_budgets_budget" "lab" {
  count        = var.budget_alert_email != "" ? 1 : 0
  name         = "${var.name_prefix}-lab-budget"
  budget_type  = "COST"
  limit_amount = var.budget_limit_usd
  limit_unit   = "USD"
  time_unit    = "MONTHLY"

  notification {
    comparison_operator        = "GREATER_THAN"
    threshold                  = 80
    threshold_type             = "PERCENTAGE"
    notification_type          = "ACTUAL"
    subscriber_email_addresses = [var.budget_alert_email]
  }
}
