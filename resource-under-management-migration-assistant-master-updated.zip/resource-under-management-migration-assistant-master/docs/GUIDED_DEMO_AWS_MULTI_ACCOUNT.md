# Guided demo: estimating unmanaged AWS resources across many accounts

This guide takes you from a fresh clone to a completed multi-account estimate. You will:

1. Start the tool, either directly on your machine or in containers.
2. Build a small practice environment in AWS with Terraform.
3. Run the automated tests against it.
4. Run an estimate from the web UI and read the results.
5. Point the tool at your organization's own AWS Config aggregator.
6. Remove the practice environment.

Allow about an hour. Most of that is waiting for AWS Config to record the practice resources.

## What the tool does in this scenario

The **Unmanaged Estimator** finds AWS resources that exist in your accounts and estimates how many of them Terraform could manage. That number is your potential Resources Under Management (RUM) if you bring them under Terraform.

For an estate with many accounts, the tool reads from an **AWS Config aggregator**. An aggregator is an AWS Config feature that collects the resource inventory of many accounts and regions into one place. One query against it covers every account it collects, so the tool does not need to sign in to each account.

The tool offers three discovery methods for AWS:

| Method (button in the UI) | What one run covers | Finds untagged resources | Use it when |
|---|---|---|---|
| **Single account (Tagging API)** | The one account your credentials belong to | No | You want a quick look at one account |
| **Multi-account (AWS Config aggregator)** | Every account and region the aggregator collects | Yes, for the resource types AWS Config records | You have many accounts and AWS Config records most resource types |
| **Multi-account, most complete (Config + Tagging API)** | The aggregator, plus a Tagging API scan of each account, merged | Yes, for recorded types; plus tagged resources of every type | AWS Config records only some resource types in your accounts |

Three limits apply to every estimate:

- The aggregator can only return resource types that the AWS Config recorder in each account is set to record.
- An account or region that is not in the aggregator contributes nothing, and the tool cannot tell you it is missing. Compare the **By Account** table with your own account list.
- The estimate counts every manageable resource it finds. It does not subtract resources that are already in Terraform state.

## Before you start

You need:

| Requirement | Needed for | Check |
|---|---|---|
| Git and a clone of this repository | Everything | `git status` |
| Node.js 20 or later | Local deployment, and the test scripts in either deployment | `node -v` |
| AWS CLI v2 | Local deployment, the practice environment, the test scripts | `aws --version` |
| Terraform 1.5 or later | The practice environment | `terraform version` |
| Docker Desktop, or Rancher Desktop with `nerdctl` | Container deployment only | `docker --version` or `nerdctl --version` |
| An AWS account you may create resources in | The practice environment | `aws sts get-caller-identity` |

Run every command in this guide from the repository root unless a step says otherwise.

## Step 1: Choose how to run the tool

| | Local (Node.js) | Containers (Docker or nerdctl) |
|---|---|---|
| Web UI address | http://localhost:5174 | http://localhost |
| API address | http://localhost:8080 | http://localhost:8080 |
| Installed on your machine | Node.js and the AWS CLI | Only the container runtime |
| How the tool gets AWS credentials | From your shell (`AWS_PROFILE`, SSO login, or environment variables), or typed into the UI | Typed into the UI only |
| The **AWS Profile** field in the UI | Works | Does not work. The container cannot see your `~/.aws` folder |
| Free ports needed | 5174 and 8080 | 80 and 8080 |
| Choose it when | You already use the AWS CLI on this machine, or you want to run every test script | You do not want to install Node.js, or you want the setup closest to a shared deployment |

Both options run the same code and give the same results. Pick one and follow the matching step below.

The AWS estimator is switched off by default. Both options below switch it on with `ENABLE_AWS_UNMANAGED_ESTIMATOR=true`.

### Step 1a: Local deployment

1. Install dependencies:

   ```bash
   npm install
   ```

2. Sign in to AWS in the same terminal, using whichever method you normally use. For example:

   ```bash
   export AWS_PROFILE=my-profile
   aws sso login            # only if your profile uses IAM Identity Center
   aws sts get-caller-identity
   ```

   The last command should print the account you expect.

3. Start the API:

   ```bash
   ENABLE_AWS_UNMANAGED_ESTIMATOR=true ESTIMATOR_CONFIG_ITEMS_PER_CALL=25 npm run dev -w @rum-tool/api
   ```

   `ESTIMATOR_CONFIG_ITEMS_PER_CALL=25` is for the practice environment only. It makes the tool fetch results 25 at a time so that a small environment still exercises paging. Leave it out when you run against your real estate.

4. Leave that terminal running. In a second terminal, from the repository root, confirm the API is up and start the web UI:

   ```bash
   curl http://localhost:8080/health
   npm run dev -w @rum-tool/web
   ```

   The API and the web UI are two separate processes, and each needs its own terminal. The second terminal does not need AWS credentials.

5. Open http://localhost:5174.

To stop the tool, press `Ctrl+C` in both terminals.

### Step 1b: Container deployment

Use `docker compose` with Docker Desktop, or `nerdctl compose` with Rancher Desktop. The commands are otherwise identical.

1. Build and start both containers:

   ```bash
   # Docker
   ENABLE_AWS_UNMANAGED_ESTIMATOR=true docker compose up --build -d

   # Rancher Desktop
   ENABLE_AWS_UNMANAGED_ESTIMATOR=true nerdctl compose up --build -d
   ```

2. Check that both containers are healthy:

   ```bash
   docker compose ps        # or: nerdctl compose ps
   curl http://localhost:8080/health
   ```

3. Open http://localhost.

Things to know about the container deployment:

- The API container includes the AWS CLI but holds no AWS credentials. You enter temporary credentials in the UI for each run (Step 4 shows how to get them).
- Run history is kept in a volume named `api-data`, so it survives a restart.
- `ESTIMATOR_CONFIG_ITEMS_PER_CALL` is not passed to the container. The practice run still works; one test reports a paging warning instead of a pass.

To stop the tool:

```bash
docker compose down          # keeps run history
docker compose down -v       # also deletes run history
```

## Step 2: Build the practice environment with Terraform

The repository includes a small, disposable AWS environment in [`infra/aws-config-lab`](../infra/aws-config-lab). It gives you a known set of resources, so you can see what each discovery method finds and misses.

It creates, in one AWS account and two regions (`us-east-1` and `us-west-2` by default):

- An AWS Config aggregator named `rumlab-aggregator`.
- AWS Config recorders in both regions, and one AWS Config rule.
- 40 practice resources: SQS queues, SNS topics, DynamoDB tables, CloudWatch log groups, S3 buckets and IAM roles. Half are tagged and half have never been tagged. Their names contain `rumlab-tagged-` or `rumlab-untagged-`.
- Two IAM roles for the tool: `rumlab-estimator-readonly`, which holds exactly the permissions the tool needs, and `rumlab-estimator-noaccess`, which holds none.

The practice environment uses one account. It shows how the aggregator method behaves; Step 5 covers running against an aggregator that spans many accounts.

Cost is small. AWS Config charges for each configuration item it records, so build the environment, finish the demo, and remove it in the same sitting.

### 2.1 Check whether AWS Config is already on

AWS allows one Config recorder per region. Check both regions:

```bash
aws configservice describe-configuration-recorders --region us-east-1
aws configservice describe-configuration-recorders --region us-west-2
```

- If both return an empty list, use the standard command in 2.2.
- If either returns a recorder, someone already runs AWS Config in this account. Use the alternative command in 2.2, which leaves their recorder untouched.

### 2.2 Apply

Sign in to AWS in your terminal with credentials that can create IAM roles, S3 buckets, AWS Config resources and the practice resource types listed above. Then:

```bash
terraform -chdir=infra/aws-config-lab init
terraform -chdir=infra/aws-config-lab apply
```

If AWS Config is already on in the account, apply with this instead:

```bash
terraform -chdir=infra/aws-config-lab apply \
  -var manage_config_recorder=false \
  -var create_config_rule=false
```

Review the plan and type `yes`. The apply takes about a minute and ends like this:

```text
Plan: 44 to add, 0 to change, 0 to destroy.
...
Apply complete! Resources: 44 added, 0 changed, 0 destroyed.

Outputs:

account_id = "111122223333"
aggregator_name = "rumlab-aggregator"
aggregator_region = "us-east-1"
estimator_no_access_role_arn = "arn:aws:iam::111122223333:role/rumlab-estimator-noaccess"
estimator_read_only_role_arn = "arn:aws:iam::111122223333:role/rumlab-estimator-readonly"
...
```

This example is from an account where AWS Config was already on, applied with the alternative command. The standard command adds the recorders, delivery channel, bucket and Config rule, so its resource count is higher.

Optional settings, added as `-var name=value`:

| Variable | Default | Purpose |
|---|---|---|
| `name_prefix` | `rumlab` | Prefix for every resource the lab creates |
| `primary_region` | `us-east-1` | Region that holds the aggregator |
| `secondary_region` | `us-west-2` | Second region |
| `resources_per_type` | `4` | Practice resources of each type per region. Must be even |
| `budget_alert_email` | none | Email address for a monthly cost alert |

### 2.3 Note the outputs

```bash
terraform -chdir=infra/aws-config-lab output
```

You will use `aggregator_name`, `aggregator_region`, `account_id` and `estimator_read_only_role_arn` in the next steps.

### 2.4 Wait for AWS Config

AWS Config records new resources in the background, and the aggregator lags behind the recorder. Expect 10 to 30 minutes before every practice resource is visible. The validation script in Step 3 waits for this automatically.

If the aggregator still returns nothing after 30 minutes, check its status:

```bash
aws configservice describe-configuration-aggregator-sources-status \
  --configuration-aggregator-name rumlab-aggregator --region us-east-1
```

If it reports the account as not authorized, apply again and add `-var create_self_authorization=true`.

## Step 3: Run the tests

Run these in order. The first needs no AWS access. The second and third need the tool running (Step 1) and the practice environment applied (Step 2).

### 3.1 Unit tests

These need Node.js and `npm install`, and work without AWS:

```bash
npm run test -w @rum-tool/rum-engine -w @rum-tool/api -w @rum-tool/web
```

Expected result: three test runs, all passing (48, 192 and 19 tests at the time of writing).

### 3.2 Practice environment validation

This script starts real estimator runs against the practice environment and checks the results against what Terraform created. It works with either deployment.

In a terminal signed in to the practice account:

```bash
node scripts/tests/aws_config_lab_validation.mjs
```

The script prints one line per check, marked `PASS`, `WARN` or `FAIL`, and a total at the end. It retries for up to 30 minutes while AWS Config catches up, so early lines that say AWS Config has not recorded everything yet are normal.

Example output from a real run. In this account a security team's AWS Config recorder records three of the six practice resource types, and the organization blocks assuming the lab roles, which explains the warnings:

```text
Lab: account 111122223333, aggregator rumlab-aggregator (us-east-1), regions us-east-1, us-west-2
API: http://localhost:8080

     recorded by this account's AWS Config: AWS::DynamoDB::Table, AWS::IAM::Role, AWS::S3::Bucket
     not recorded (AWS Config cannot return these): AWS::Logs::LogGroup, AWS::SNS::Topic, AWS::SQS::Queue
WARN Estimator runs with the lab's least-privilege role — could not assume it (not authorized to perform: sts:SetSourceIdentity); using the caller's credentials, so the documented minimum permissions are not verified
PASS Aggregator lookup lists the lab aggregator — type=accounts, regions=us-east-1,us-west-2
     attempt 1: AWS Config has not recorded everything yet (3 type(s) short); retrying in 60s
     attempt 2: AWS Config has not recorded everything yet (3 type(s) short); retrying in 60s
PASS Config aggregator run completes — 17 resources, 17 candidates in the account
PASS Config discovery finds every recorded lab resource, tagged and untagged — 16 resources across 3 types
PASS Resource types the recorder does not record are absent from Config results — AWS::Logs::LogGroup, AWS::SNS::Topic, AWS::SQS::Queue (expected limit: coverage follows the recorder)
PASS Every lab row carries the account ID
PASS IAM roles are reported as global (no region)
PASS Resources come back from both lab regions — us-east-1, us-west-2
PASS Every lab resource classifies as a RUM candidate
PASS Per-account breakdown adds up to the summary
PASS Continuation tokens work across calls — 9 calls
WARN Compliance/inventory records are excluded — none were returned; the Config rule may not have evaluated yet
     duplicates collapsed: 0; records with no usable identifier: 0
     3 AWS Config resource types returned for this account
PASS Region filter returns only that region — 8 lab rows in us-west-2
PASS Region filter still includes global resources — 4 IAM roles
PASS Account filter excludes other accounts
PASS Tagging API run completes — 26 resources
PASS Tagging API misses never-tagged resources — 0 of 20 untagged lab resources returned; AWS Config returned every untagged resource of the types it records
     12 tagged lab resources of unrecorded types were found only by the Tagging API
WARN Tagging API finds every tagged lab resource — 18 of 20 (in live testing the Tagging API did not return tagged IAM roles)
PASS Combined run completes — 38 resources; both=6, config only=12, tagging only=20
PASS Combined run returns the union of both sources — 28 of 40 lab resources (Config alone: 16)
PASS Combined run does not double-count resources both sources return
PASS Each resource is labelled with the source that found it — 6 by both, 10 Config only, 12 Tagging API only
     12 lab resources are invisible to both sources (never tagged, type not recorded by AWS Config)
WARN A role without permissions fails fast with a clear error — skipped: the lab's no-access role could not be assumed
PASS Stored runs contain no credentials

20 passed, 0 failed, 4 warnings
```

Read the last few `PASS` lines together: AWS Config alone found 16 of the 40 practice resources, the Tagging API found 18, and the combined method found 28. The remaining 12 were never tagged and are of types this account's recorder does not record, so no method can see them.

What it checks:

| Check | What a pass tells you |
|---|---|
| Aggregator lookup | The tool can list the aggregator |
| Config discovery finds every recorded lab resource | Untagged resources are found, not only tagged ones |
| Account ID, region and global resources | Each row carries the right account; IAM roles are reported with no region |
| Region and account filters | Filters return only what you asked for |
| Paging | Results larger than one call are collected completely |
| Compliance records excluded | AWS Config rule results are not counted as resources |
| Tagging API comparison | The Tagging API misses the never-tagged half, which is why the aggregator method exists |
| Combined method | The union of both sources, with no double counting |
| No-permission role | A run without permissions fails quickly with a clear message |
| Stored runs contain no credentials | Nothing sensitive is saved |

Warnings you may see, and what they mean:

- **Continuation tokens work across calls** shows `WARN` when the tool was started without `ESTIMATOR_CONFIG_ITEMS_PER_CALL=25`, which is always the case in the container deployment.
- **Estimator runs with the lab's least-privilege role** shows `WARN` when your organization blocks assuming a role from your sign-in session. The script then uses your own credentials, which must be present as `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY` and `AWS_SESSION_TOKEN` environment variables, and skips the two checks that need the lab roles.
- If AWS Config in the account records only some resource types, the script lists the lab types it cannot return and reports that as an expected limit.

### 3.3 Aggregator smoke test (local deployment only)

This is a quick end-to-end run against any aggregator. It relies on the credentials in the tool's own environment, so it works with the local deployment and not with the containers.

```bash
scripts/tests/aws_config_aggregator_estimator_smoke.sh rumlab-aggregator us-east-1
```

The arguments are the aggregator name, its region, and an optional comma-separated list of regions to include. A successful run ends with a line starting `PASS config aggregator smoke:` followed by the totals.

## Step 4: Run an estimate from the UI

Open the UI: http://localhost:5174 for the local deployment, http://localhost for containers.

> **About the screenshots.** Sections 4.2 to 4.4 and Step 5 use screenshots taken with the tool connected to a simulated AWS organization of 190 accounts and 8 regions, to show what a multi-account result looks like. Sections 4.5 and 4.6 use screenshots from a real run of the practice environment, with the account ID replaced by `111122223333`. The names and totals on your screen will differ from both.

### 4.1 Get credentials for the run

- **Local deployment:** if the terminal that started the tool is signed in to AWS, you can leave every credential field blank, or type a profile name in **AWS Profile (optional)**.
- **Container deployment:** you must paste temporary credentials. To use the lab's least-privilege role, run:

  ```bash
  aws sts assume-role \
    --role-arn "$(terraform -chdir=infra/aws-config-lab output -raw estimator_read_only_role_arn)" \
    --role-session-name rum-demo
  ```

  Copy `AccessKeyId`, `SecretAccessKey` and `SessionToken` from the output. If your organization blocks that command, print the credentials of your current sign-in instead:

  ```bash
  aws configure export-credentials --format env
  ```

Credentials you enter are used for that run only. They are not written to the run history, and the API does not return them.

### 4.2 Fill in the form

1. Select the **Unmanaged Estimator** tab in the row of buttons under the summary banner.

   ![The Unmanaged Estimator tab selected, with AWS and the Config aggregator discovery method chosen](images/guided-demo/01-unmanaged-estimator-tab.png)

   The **Mapping** banner at the top of the form shows the version and age of the AWS-to-Terraform type mappings. It turns yellow and reads `STALE` when the mappings are older than 30 days. Runs still work; newer AWS resource types may show up as Unmapped.
2. Under the heading **Unmanaged Estimator (Prototype)**, select **AWS**.
3. Under **Discovery method**, select **Multi-account (AWS Config aggregator)**.
4. In **Aggregator region (optional)**, enter `us-east-1`.
5. If you are pasting credentials, fill in **AWS Access Key ID**, **AWS Secret Access Key** and **AWS Session Token** now, at the bottom of the form. The lookup in the next step uses them.
6. Select **Find aggregators**. A button appears for each aggregator your credentials can see. Hover over one to see whether it is organization-wide and which regions it covers. Select `rumlab-aggregator`; its name is copied into **Config aggregator name**. You can also type the name directly.
7. Leave **Regions to include** and **Account IDs to include** blank to include everything the aggregator collects. To narrow a run, enter regions separated by commas, or 12-digit account IDs separated by commas, spaces or new lines.
8. Select **Run Estimator**.

![The form after Find aggregators: one aggregator found and selected, regions and account IDs left blank](images/guided-demo/02-aggregator-form.png)

*The form after **Find aggregators**. The aggregator found is highlighted and its name is filled in.*

### 4.3 Watch the run

A status panel shows where the run is: resources found so far, pages fetched, then classification. It also shows the run ID and elapsed time. If AWS throttles a call, the tool retries it and the panel says how many calls were retried.

![Run in progress: resources found, pages fetched, one retried call, run ID and elapsed time](images/guided-demo/03-run-in-progress.png)

*A run in progress. Here AWS throttled one call and the tool retried it.*

You can leave the page open for long runs. A large estate can take many minutes.

When the run finishes you see **Estimator Complete**, or **Estimator Failed** with the error and a **Retry** button.

### 4.4 Read the results

The page shows these sections from top to bottom.

**Latest Estimator Summary.** Six numbers. Select the small `i` beside each label for its definition.

| Tile | Meaning |
|---|---|
| **Discovered** | Everything found in scope |
| **RUM Candidates** | Resources Terraform can manage. This is the estimate |
| **Likely Auto-Created** | Resources Terraform could manage, but that AWS or another resource normally creates. Not counted as candidates |
| **Non-Manageable** | Resources Terraform cannot manage |
| **Unmapped** | Resources the tool has no Terraform type for yet |
| **Permission Issues** | Resources the tool could not classify fully because a permission was missing |

The **Coverage** tag beside the heading is the share of discovered resources that matched a known Terraform type.

![Latest Estimator Summary with six totals, followed by Discovery Coverage and the By Account table](images/guided-demo/04-summary-coverage-by-account.png)

*Summary, Discovery Coverage and By Account for the simulated organization: 35,530 resources discovered, 12,540 RUM candidates, 21,470 likely auto-created.*

**Likely Auto-Created explained.** Many AWS objects are not written as their own Terraform resource. Examples are the network interface and disk volumes that come with a virtual machine, instances launched by an Auto Scaling group, snapshots, and the default VPC that AWS creates in every account. Counting them would overstate the estimate, so the tool reports them separately. A note under the tiles gives the upper bound (candidates plus likely auto-created) in case you do declare such resources individually.

**Warnings.** Two yellow notices can appear:

- *Tagging API scan failed for N accounts* (combined method only): those accounts are counted from AWS Config data alone.
- *N auto-created resource checks could not run*: the candidate count may include resources those checks would have moved out.

**Discovery Coverage.** How many accounts and regions returned resources, and how many records were excluded as compliance records or duplicates. For the combined method it also shows how many resources each source found.

**By Account.** One row per account with the same counts as the summary. Use it to confirm that every account you expected is present.

**Estimator Run History.** Earlier runs with their status and totals.

**Resource tables.** Four tables: **RUM Candidate Resources**, **Likely Auto-Created Resources**, **Non-Manageable Resources** and **Unmapped Resources**. Each shows the resource ID, account, service, resource type, region and Terraform type. In the Likely Auto-Created table, **Reason Detail** says why each resource is there. Large tables show the first rows only; use **Export CSV** or **Export JSON** on the table for the full list. Scroll a table sideways to see the **Reason** and **Reason Detail** columns.

![RUM Candidate Resources table with resource ID, account, service, resource type, region and Terraform type](images/guided-demo/05-rum-candidates-table.png)

*RUM Candidate Resources, with the export buttons at the top right.*

![Likely Auto-Created Resources table listing an Auto Scaling instance and default VPC resources](images/guided-demo/06-likely-auto-created-table.png)

*Likely Auto-Created Resources: here an instance launched by an Auto Scaling group, and the parts of a default VPC.*

**Diagnostics.** **Top Unmapped Prefixes**, **Top Missing Permissions**, and **IAM Remediation (Suggested)** with an **Export Policy JSON** button for a policy that would grant the missing permissions.

![Top Unmapped Prefixes, Top Missing Permissions and the suggested IAM policy](images/guided-demo/07-diagnostics.png)

*Diagnostics at the bottom of the page.*

### 4.5 What to look for in the practice run

![The form with rumlab-aggregator found and selected](images/guided-demo/11-practice-aggregator-form.png)

*The practice aggregator found by **Find aggregators**.*

![Practice run with the aggregator method: 100 discovered, 66 RUM candidates, 34 likely auto-created, one account](images/guided-demo/12-practice-aggregator-summary.png)

*Aggregator method against the practice account. The totals include everything AWS Config records in the account, and they grow for a while after `terraform apply` as AWS Config catches up; the run history at the bottom shows earlier, smaller runs.*

- In the **RUM Candidate Resources** export, filter for `rumlab-`. You should find both `rumlab-tagged-` and `rumlab-untagged-` resources. The untagged ones are what the single-account method cannot find.
- The **Likely Auto-Created Resources** table lists the account's default VPC parts, if the account has them and AWS Config records them.
- The totals include everything else in the account that AWS Config records, not only the practice resources, so they will differ from account to account.

### 4.6 Compare the other two methods

Run the estimator twice more to see the difference:

1. Select **Single account (Tagging API)**, enter `us-east-1,us-west-2` in **Regions (comma-separated)**, and run. Filter the candidates for `rumlab-`: only the tagged resources appear.

   ![Practice run with the Tagging API method: 26 discovered, 25 RUM candidates](images/guided-demo/13-practice-tagging-summary.png)

   *Tagging API method against the same account: 26 resources, against 100 from AWS Config. The `unknown` row in **By Account** holds resources whose identifier carries no account ID, such as Route 53 hosted zones.*
2. Select **Multi-account, most complete (Config + Tagging API)**, choose `rumlab-aggregator` again, enter `us-east-1,us-west-2` in **Regions to include**, leave **Role to assume in each account** blank, and run. **Discovery Coverage** now shows how many resources were found by both sources, only by AWS Config, and only by the Tagging API.

   ![Practice run with the combined method: 127 discovered, with counts found by both sources, only by AWS Config and only by the Tagging API](images/guided-demo/14-practice-combined-summary.png)

   *Combined method: 8 resources found by both sources, 101 only by AWS Config and 18 only by the Tagging API.*

### 4.7 Other tabs

- **Reporting** charts results from all completed runs. It loads its data when the page opens, so reload the page after a run finishes, then choose the **Unmanaged** source to see the results by classification.
- **Pack Sizing** turns a RUM total into a subscription size with growth and peak allowances.
- **Engineer Guide** explains each feature and how credentials are handled.

## Step 5: Run against your organization's aggregator

The steps in the UI are the same as Step 4. What changes is the aggregator, the credentials and the permissions.

### 5.1 What you need

1. **The aggregator's name, region and owning account.** Organizations that use AWS Control Tower or a central security account usually already have one. To list the aggregators an account owns:

   ```bash
   aws configservice describe-configuration-aggregators --region us-east-1 \
     --query 'ConfigurationAggregators[].ConfigurationAggregatorName'
   ```

2. **Credentials for the account that owns the aggregator**, with this read-only policy:

   ```json
   {
     "Version": "2012-10-17",
     "Statement": [
       {
         "Sid": "RumEstimatorReadOnly",
         "Effect": "Allow",
         "Action": [
           "config:SelectAggregateResourceConfig",
           "config:DescribeConfigurationAggregators",
           "tag:GetResources",
           "servicediscovery:GetNamespace"
         ],
         "Resource": "*"
       }
     ]
   }
   ```

   The tool only reads. It creates and changes nothing in AWS.

3. **For the combined method only:** a role with the same name in every account, for example `RumEstimatorReadOnly`, that allows `tag:GetResources` and trusts the credentials you run the tool with. If you sign in through corporate single sign-on, the role's trust policy must also allow `sts:SetSourceIdentity` and `sts:TagSession`.

### 5.2 Run it

1. Start the tool as in Step 1, without `ESTIMATOR_CONFIG_ITEMS_PER_CALL`.
2. In the UI, select **AWS**, then the discovery method:
   - **Multi-account (AWS Config aggregator)** if AWS Config records all or most resource types in your accounts.
   - **Multi-account, most complete (Config + Tagging API)** if recording is limited to selected types.
3. Enter the aggregator's region, select **Find aggregators**, and choose your aggregator.
4. For a first run, narrow the scope so it finishes quickly: enter one or two regions and a handful of account IDs. Check the results, then clear both fields and run the full estate.
5. For the combined method, enter the role name in **Role to assume in each account (optional)**, and the external ID if the role requires one. Enter every region you want scanned in **Regions to include**; the Tagging API scan uses that list.
6. Select **Run Estimator**.

The screenshots below show the combined method against the simulated organization.

![Combined method form with the role name RumEstimatorReadOnly entered](images/guided-demo/08-combined-form.png)

*The combined method adds the role fields. The role name is the same in every account.*

![Combined run in progress showing Tagging API: 42 of 190 accounts scanned](images/guided-demo/09-combined-in-progress.png)

*After the aggregator query, the tool scans each account with the Tagging API and reports how many accounts are done.*

![Warning that the Tagging API scan failed for 2 accounts, followed by Discovery Coverage with counts per source](images/guided-demo/10-combined-results.png)

*Two accounts did not allow the role to be assumed. The run still completed; the warning names the accounts, and Discovery Coverage shows how many resources each source found.*

### 5.3 Check the result before you rely on it

- **By Account:** is every account you expected listed? A missing account is empty, not recorded, or not in the aggregator.
- **Discovery Coverage:** does the region count match the regions you use?
- **Warnings:** resolve any failed accounts or failed checks and run again.
- **Unmapped:** a large number here means the estimate is low. Export the table and share it with the team that maintains the tool so the mappings can be added.
- **Recorder settings:** if the AWS Config recorders in your accounts record only selected resource types, the aggregator method undercounts. Use the combined method.

Long runs can be tuned with two environment variables set when the tool starts: `ESTIMATOR_CLI_TIMEOUT_MS` (time limit per AWS call, default 120000) and `ESTIMATOR_CLI_MAX_ATTEMPTS` (attempts per call when AWS throttles, default 5).

## Step 6: Clean up

1. Remove the practice environment. Use the same `-var` options you applied with:

   ```bash
   terraform -chdir=infra/aws-config-lab destroy
   ```

2. Stop the tool: `Ctrl+C` for the local deployment, or `docker compose down` (`nerdctl compose down`) for containers.

3. To delete saved run history as well: for containers, `docker compose down -v`. For the local deployment, delete `apps/api/data/estimator-runs.json` while the tool is stopped.

## Troubleshooting

| What you see | Cause | What to do |
|---|---|---|
| `AWS unmanaged estimator is disabled. Set ENABLE_AWS_UNMANAGED_ESTIMATOR=true` | The tool was started without the switch | Stop it and start it again with the variable set, as in Step 1 |
| **Find aggregators** returns none | Wrong region, or the credentials belong to an account that does not own the aggregator | Enter the aggregator's region; use credentials for the owning account |
| Run fails with `AccessDenied` or `not authorized` | The credentials lack one of the permissions in Step 5.1 | Add the policy, or use the suggested policy from **IAM Remediation (Suggested)** |
| Run fails with expired-token wording | Temporary credentials ran out | Get new credentials and select **Retry** |
| The practice resources are missing from the results | AWS Config has not recorded them yet | Wait and run again; allow up to 30 minutes after `terraform apply` |
| Only some practice resource types appear | The account's AWS Config recorder records selected types only | Expected. Run the combined method to add the tagged resources of other types |
| `terraform apply` fails creating the Config recorder | A recorder already exists in that region | Apply with `-var manage_config_recorder=false -var create_config_rule=false` |
| The **AWS Profile** field has no effect | You are using the container deployment | Paste temporary credentials instead |
| The page does not load on http://localhost | Port 80 or 8080 is in use, or a container is unhealthy | Run `docker compose ps` and `docker compose logs api` |
| A UI change or new field does not appear in the local deployment | An old browser tab or stale build | Reload the page; restart the API and web UI processes |
| http://localhost:5174 does not open, but `curl http://localhost:8080/health` works | Only the API is running | Start the web UI in a second terminal: `npm run dev -w @rum-tool/web` |

## Reference

- [README](../README.md): full feature list, API endpoints and environment variables.
- [`infra/aws-config-lab/README.md`](../infra/aws-config-lab/README.md): practice environment details.
- [`data/mappings/aws_resource_type_to_tf.json`](../data/mappings/aws_resource_type_to_tf.json): the AWS-to-Terraform type mappings and the likely auto-created rules.
