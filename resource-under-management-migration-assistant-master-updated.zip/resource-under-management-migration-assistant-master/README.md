# TFC RUM Calculator Tool

A self-service tool for estimating Terraform **Resources Under Management (RUM)** — the billing metric for HCP Terraform Cloud and Terraform Enterprise.

## Quick Start

```bash
# Native development
npm install
npm run dev          # Web UI on :5174, API on :8080

# Container deployment (Rancher Desktop / nerdctl)
nerdctl compose up --build -d   # Web on http://localhost, API on :8080
nerdctl compose down

# Docker deployment
docker compose up --build -d
```

## Architecture

```
apps/web           → React 18 + Carbon Design System + Vite (port 5174 dev / 80 docker)
apps/api           → Express.js API server (port 8080)
apps/cli           → Commander-based CLI tool (rumctl)
packages/rum-engine → Shared RUM calculation engine (zero dependencies)
data/mappings/     → Versioned AWS/Azure/GCP resource→Terraform type mappings
fixtures/          → Test data: synthetic tfstate files, demo states
scripts/tests/     → Shell-based integration/accuracy tests
```

## Features

### Managed State Scanning
Scan cloud storage backends and local directories to calculate RUM from existing Terraform state files.

- **AWS S3** — paginated bucket scanning via AWS CLI
- **Azure Blob Storage** — container scanning via Azure CLI
- **GCP Cloud Storage** — recursive bucket scanning via gsutil
- **Local Directory** — filesystem scanning with configurable patterns and path allowlisting

### Unmanaged Resource Estimator
Discover cloud resources not yet managed by Terraform and estimate potential RUM impact.

- Scope-driven resource discovery across AWS, Azure, and GCP
- Terraform-manageability classification using versioned mapping files. For AWS, the Terraform type is resolved per resource type (from the AWS Config type or the ARN), with a service-level default as fallback
- Estimated candidate RUM summary with per-resource-type breakdown
- Permission diagnostics with suggested IAM remediation policies
- Mapping freshness tracking with configurable staleness threshold
- Live run progress, automatic retry of throttled or timed-out cloud API calls, and a per-account breakdown for AWS

#### AWS discovery methods

| Method | Scope of one run | Sees untagged resources | Requires |
|---|---|---|---|
| **Single account (Tagging API)** — default | The account the credentials belong to, for the regions you list | No. Only resources that are, or once were, tagged | `resourcegroupstaggingapi:GetResources` |
| **Multi-account (AWS Config aggregator)** | Every account and region the aggregator collects, in one run | Yes, for the resource types Config records | An AWS Config aggregator, credentials for the account that owns it, `config:SelectAggregateResourceConfig` and `config:DescribeConfigurationAggregators` |
| **Multi-account, most complete (Config + Tagging API)** | The aggregator query plus a Tagging API scan of each account, merged | Yes, for the resource types Config records; tagged resources of every type | Everything above, plus a role in every account that allows `tag:GetResources` and that the supplied credentials can assume (`sts:AssumeRole`) |

Use the Config aggregator method for estates with many accounts. Things to know before relying on its numbers:

- It only counts resource types that the AWS Config recorders in each account are set to record. If recording is limited to certain types, the estimate is limited the same way.
- An account or region that is not part of the aggregator, or has no recorder, contributes nothing and is not reported as missing. Compare the **By Account** list against your account inventory.
- Compliance and inventory records that Config stores alongside resources are excluded; the run reports how many were skipped.
- All methods count every Terraform-manageable resource discovered. None subtracts resources already in Terraform state.
- Each row's `typeMatch` says how its Terraform type was chosen: `exact` (from the resource's own type) or `service` (the service's default type, used when the resource carries no finer type or is not yet in `data/mappings/aws_resource_type_to_tf.json`). Service-level rows are still counted; only the label is approximate.
- **Likely auto-created resources are counted separately, not as RUM candidates.** Many AWS objects are never declared as their own Terraform resource: AWS or another resource creates them. They are classified `likely_auto_created`, shown in their own category with a reason per row, and left out of `rumCandidates` (`summary.likelyAutoCreated` holds the count, so candidates + likely auto-created is the upper bound). The rules live in the `likelyAutoCreated` section of `data/mappings/aws_resource_type_to_tf.json`:
  - By kind (all discovery methods): network interfaces, EBS volumes, EBS/RDS/Redshift/ElastiCache snapshots, AMIs, service-linked and IAM Identity Center roles, service-linked Config rules, default event bus / Athena workgroup / backup vault, default parameter and option groups, predefined CodeDeploy configurations, AWS Control Tower resources, and all but the newest revision of each ECS task definition family.
  - By tag (all discovery methods): instances launched by Auto Scaling groups, Spot/EC2 Fleets, EMR and Karpenter; the Auto Scaling group, launch template and instances of EKS managed node groups; load balancers, target groups and security groups created by Kubernetes controllers; what an Elastic Beanstalk environment creates. Only tag keys are read; tag values are never stored.
  - By extra AWS Config queries (Config and combined methods only): the default VPC and its subnets, default security group, main route table, default network ACL and internet gateway; AWS managed KMS keys. If one of these checks fails the run still completes and reports it in `discovery.autoCreatedChecksFailed`.
  - Not moved, by design: CloudFormation-managed resources and Lambda log groups (often declared in Terraform or genuine migration candidates).

**Why the combined method exists.** Tested against a real account whose Config recorder was limited to a security team's list of resource types, AWS Config returned only the lab resources of recorded types, and the Tagging API returned only the tagged ones (and no IAM roles). Neither was complete. The combined method takes the union and labels each resource with the source that found it (`discoveredBy`). What still goes uncounted: resources that were never tagged *and* are of a type Config does not record.

Combined-method specifics:

- `scope.tagging.roleName` is the name of a role that exists in every account. It is assumed just before each account is scanned. Without it, only the account the credentials belong to is scanned.
- If your sign-in session carries a source identity or session tags (common with corporate SSO), the role's trust policy must also allow `sts:SetSourceIdentity` and `sts:TagSession`.
- Accounts scanned: `scope.tagging.accountIds`, else `configAggregator.accountIds`, else every account Config returned. An account with nothing recorded in Config will not be scanned unless you list it.
- Regions scanned: `scope.regions`, else the regions Config returned plus `us-east-1`.
- An account whose scan fails is listed in `discovery.failedAccounts` and skipped; the run still completes.

Example request:

```bash
curl -X POST http://localhost:8080/estimator/aws/runs \
  -H 'Content-Type: application/json' \
  -d '{
    "scope": {
      "discoverySource": "config-aggregator",
      "configAggregator": { "name": "aws-controltower-ConfigAggregatorForOrganizations", "region": "us-east-1" },
      "regions": ["us-east-1", "eu-west-1"]
    },
    "executionEnv": { "awsProfile": "audit" }
  }'
```

`regions` and `configAggregator.accountIds` are optional filters; leave them out to include everything in the aggregator. Poll `GET /estimator/runs/:id` for `status` and `progress`.

For the combined method, set `"discoverySource": "combined"` and add `"tagging": { "roleName": "RumEstimatorReadOnly", "concurrency": 10 }` to `scope`.

### TFE / TFC Migration Estimator

Terraform Enterprise is transitioning to the same RUM-based billing model that HCP Terraform Cloud already uses. This tool helps you answer the critical question: **"What will my RUM bill look like after migration?"**

The estimator connects directly to any **Terraform Enterprise** or **HCP Terraform Cloud** instance using the same [TFE API v2](https://developer.hashicorp.com/terraform/cloud-docs/api-docs), making it fully bidirectional:

| Migration Path | Use Case |
|---|---|
| **TFE → TFC** | You're moving from self-hosted TFE to HCP Terraform Cloud — estimate your new RUM-based bill |
| **TFC → TFE** | You're evaluating self-hosted TFE — understand your current RUM footprint before migration |
| **TFE → TFE** | You're on TFE preparing for upcoming RUM billing — preview what your bill will be |
| **TFC audit** | Validate current TFC RUM counts against what the billing portal shows |

#### How It Works

1. **Connect** — Provide the TFE/TFC hostname (e.g., `tfe.example.com` or `app.terraform.io`), an API token with workspace read access, and the organization name
2. **Scope** — Optionally filter by project to estimate a subset of workspaces
3. **Scan** — The tool enumerates all workspaces via the API, downloads the current state version for each, and passes it through the shared RUM calculation engine
4. **Results** — Per-workspace RUM breakdown with Billable RUM, Non-Billable resources, and module-level analysis. Sortable and exportable.

#### Requirements

- A **User**, **Team**, or **Organization** API token with at least read access to workspaces and state versions
- Network connectivity from the tool to the TFE/TFC instance (for on-prem TFE, the tool must be run on a machine that can reach the TFE hostname)
- For self-signed TLS certificates (common with on-prem TFE), the `NODE_EXTRA_CA_CERTS` environment variable can be set

#### Technical Details

- Connects via TFE API v2 with Bearer token authentication
- Enumerates workspaces with optional project-level filtering
- Downloads current state versions and calculates RUM per workspace
- Per-workspace results table sortable by RUM count
- Handles pagination and rate limiting with exponential backoff
- Credential redaction — tokens are never persisted or returned in API responses
- Module-level RUM breakdown per workspace for migration planning

### Pack Sizing
Right-size your HCP Terraform subscription pack based on actual RUM data.

- Auto-populates base RUM from your combined scan total
- Peak multiplier and annual growth buffer inputs
- Monthly RUM profile mode for seasonal workload patterns
- 12-month and 36-month chart views
- RUM forecasting by growth rate or target-RUM goal
- Pack recommendation with billable vs. buffered RUM comparison

### Reporting Dashboard
Cross-source analytics and visualization across all scan modes.

- Filter by source (Managed / Unmanaged / TFE)
- Slice by dimension: provider, bucket, TFE project, workspace, or resource classification
- Top-N filtering (5, 10, 25, or all)
- Bar chart and pie chart views with Carbon-styled data table
- Pulls live data from all completed scan runs

### Combined RUM Summary
Always-visible banner aggregating RUM totals across all three scan modes.

- Total Billable RUM, Non-Billable, and Total Resources
- Color-coded stacked bar visualization by source (managed, unmanaged, TFE)
- Auto-polls and updates as new scans complete

### Module Structure Analysis
Per-module RUM breakdown extracted from Terraform state resource addresses.

- Supports arbitrarily nested modules (e.g., `module.env.module.stack.aws_instance.web`)
- Sorted by RUM count descending for quick identification of high-impact modules
- Available in both managed scan and TFE migration results

## API Endpoints

| Method | Path | Description |
|---|---|---|
| `POST` | `/scans` | Start a managed state scan |
| `GET` | `/scans` | List all scans |
| `GET` | `/scans/:id` | Get scan status and results |
| `GET` | `/scans/:id/resources` | Per-resource breakdown for a scan |
| `POST` | `/estimator/aws/runs` | Start an AWS unmanaged resource estimation |
| `POST` | `/estimator/azure/runs` | Start an Azure unmanaged resource estimation |
| `POST` | `/estimator/gcp/runs` | Start a GCP unmanaged resource estimation |
| `POST` | `/estimator/aws/config-aggregators` | List AWS Config aggregators visible to the supplied credentials |
| `GET` | `/estimator/runs` | List all estimator runs (summaries, no resource rows) |
| `GET` | `/estimator/runs/:id` | Run status, progress, summary and per-account breakdown. Add `?include=resources` for resource rows |
| `GET` | `/estimator/runs/:id/candidates` | Manageable resource candidates (`?format=csv`, `?limit=&offset=`) |
| `GET` | `/estimator/runs/:id/likely-auto-created` | Resources AWS or another resource normally creates; not counted as candidates (`?format=csv`, `?limit=&offset=`) |
| `GET` | `/estimator/runs/:id/non-manageable` | Non-manageable resources (`?format=csv`, `?limit=&offset=`) |
| `GET` | `/estimator/runs/:id/unmapped` | Unmapped resource types (`?format=csv`, `?limit=&offset=`) |
| `GET` | `/estimator/runs/:id/diagnostics` | Mapping coverage diagnostics |
| `GET` | `/estimator/runs/:id/iam-remediation` | Suggested IAM remediation policy |
| `GET` | `/estimator/mapping/:provider` | Mapping freshness metadata |
| `POST` | `/tfe/projects` | List projects on a TFE/TFC instance |
| `POST` | `/tfe/migration/runs` | Start a TFE migration estimate |
| `GET` | `/tfe/migration/runs` | List all migration runs |
| `GET` | `/tfe/migration/runs/:id` | Get migration run results |
| `GET` | `/tfe/migration/runs/:id/workspaces` | Per-workspace RUM breakdown |
| `GET` | `/tfe/migration/runs/:id/export` | Export results (CSV/JSON) |
| `GET` | `/tfe/migration/runs/:id/modules` | Module breakdown for a migration |
| `GET` | `/metrics/summary` | RUM summary across managed scans |
| `GET` | `/metrics/cumulative` | Cumulative RUM over time |
| `GET` | `/metrics/by-bucket` | RUM grouped by bucket |
| `GET` | `/metrics/by-bucket-cumulative` | Cumulative RUM per bucket |
| `GET` | `/metrics/combined-summary` | Aggregated RUM across all sources |
| `GET` | `/health` | Health check |

## Testing

```bash
npm run test         # Run all unit tests (50 tests across rum-engine + API)
npm run build        # Build all workspaces
npm run lint         # Lint all workspaces
```

### Integration / Accuracy Tests

- `scripts/tests/local_scan_accuracy.sh` — Local managed scan accuracy
- `scripts/tests/aws_scan_accuracy.sh` — AWS managed scan accuracy
- `scripts/tests/aws_unmanaged_estimator_smoke.sh` — AWS unmanaged estimator smoke test (Tagging API)
- `scripts/tests/aws_config_aggregator_estimator_smoke.sh` — AWS unmanaged estimator smoke test (Config aggregator)
- `scripts/tests/aws_config_lab_validation.mjs` — Full validation against the Terraform lab in `infra/aws-config-lab`
- `scripts/mappings/validate_aws_type_mapping.mjs` — Checks every name in the AWS resource-type mapping against the real AWS provider schema and the AWS CLI's Config type list

## Environment Variables

| Variable | Default | Description |
|---|---|---|
| `PORT` | `8080` | API server port |
| `NODE_ENV` | — | `production` or `development` |
| `LOG_LEVEL` | `debug` (dev) / `info` (prod) | Pino log level |
| `CORS_ORIGINS` | `http://localhost:5174,http://localhost:80` | Allowed CORS origins |
| `LOCAL_SCAN_ALLOWED_ROOTS` | workspace root | Comma-separated directory allowlist |
| `ESTIMATOR_MAPPING_STALE_DAYS` | `30` | Days before mapping is flagged stale |
| `ESTIMATOR_CLI_TIMEOUT_MS` | `120000` | Time limit for each cloud CLI call made by the estimator |
| `ESTIMATOR_CLI_MAX_ATTEMPTS` | `5` | Attempts per estimator CLI call before the run fails (throttling, timeouts and transient errors only) |
| `ESTIMATOR_CONFIG_ITEMS_PER_CALL` | `1000` | Items fetched per AWS Config query call. Lower it only to exercise paging in a small test environment |
| `ENABLE_AWS_S3_SCAN` | — | Enable live AWS S3 scanning |
| `ENABLE_AZURE_BLOB_SCAN` | — | Enable live Azure Blob scanning |
| `ENABLE_GCP_GCS_SCAN` | — | Enable live GCP GCS scanning |
| `ENABLE_AWS_UNMANAGED_ESTIMATOR` | — | Enable AWS unmanaged estimator |
| `ENABLE_AZURE_UNMANAGED_ESTIMATOR` | — | Enable Azure unmanaged estimator |
| `ENABLE_GCP_UNMANAGED_ESTIMATOR` | — | Enable GCP unmanaged estimator |

See [`.env.example`](.env.example) for the full list including cloud provider credentials.

## Production Hardening

- **Docker**: Non-root containers, health checks, resource limits (see `apps/api/Dockerfile`)
- **Security**: Helmet.js headers, CORS origin restriction, credential redaction
- **Logging**: Pino structured JSON logging with request IDs
- **Persistence**: Atomic file writes (write-to-temp + rename) for crash safety
- **Validation**: Zod schemas on all API inputs

## Mapping Freshness

Resource-to-Terraform type mappings are versioned in `data/mappings/`:
- `aws_resource_to_tf.json`
- `azure_resource_to_tf.json`
- `gcp_resource_to_tf.json`

Refresh with: `scripts/mappings/refresh_aws_mapping.sh ">= 6.0.0"`

## Demo Bucket Workflow

```bash
# Create persistent demo bucket from fixtures
scripts/aws/setup_demo_bucket.sh

# Tear down when finished
scripts/aws/teardown_demo_bucket.sh
```

## Docs

- [Guided Demo: AWS Multi-Account Estimate](docs/GUIDED_DEMO_AWS_MULTI_ACCOUNT.md) ([PDF](docs/GUIDED_DEMO_AWS_MULTI_ACCOUNT.pdf)) — step-by-step deployment, Terraform practice environment, tests and UI walkthrough
- [AWS UI Test Runbook](docs/AWS_UI_TEST_RUNBOOK.md) — validate the managed-state S3 scan against synthetic state files, with teardown

Deployment, API endpoints, environment variables and tests are documented in this README.
